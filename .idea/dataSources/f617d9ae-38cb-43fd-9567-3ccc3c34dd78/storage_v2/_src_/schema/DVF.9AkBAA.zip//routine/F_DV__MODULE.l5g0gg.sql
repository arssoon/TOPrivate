create FUNCTION     "F$DV$_MODULE" RETURN VARCHAR2 AS BEGIN RETURN DVSYS.get_factor(p_factor =>'DV$_Module'); END;
/

