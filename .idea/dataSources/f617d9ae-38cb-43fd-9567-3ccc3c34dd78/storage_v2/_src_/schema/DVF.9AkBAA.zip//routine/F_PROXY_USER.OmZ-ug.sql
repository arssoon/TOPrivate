create FUNCTION     "F$PROXY_USER" RETURN VARCHAR2 AS BEGIN RETURN DVSYS.get_factor(p_factor =>'Proxy_User'); END;
/

