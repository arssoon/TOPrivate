create type ku$_constraint1_t force as object
(
  owner_num     number,                                      /* owner user # */
  name          varchar2(128),                            /* constraint name */
  con_num       number,                                 /* constraint number */
  obj_num       number,                  /* object number of base table/view */
  property      number,                     /* properties of base table/view */
  property2     number,                     /* properties of base table/view */
  property3     number,                     /* properties of base table/view */
  numcols       number,                   /* number of columns in constraint */
  contype       number,                                   /* constraint type */
                               -- table check (condition-no keys) (1),
                               -- primary key (2),
                               -- unique key (3),
                               -- supplemental log groups (w/ keys) (12),
                               -- supplemental log data (no keys) (14,15,16,17)
  enabled       number,           /* is constraint enabled? NULL if disabled */
  condlength    number,                 /* table check condition text length */
  condition     clob,                          /* table check condition text */
  parsed_cond   sys.xmltype,                 /* parsed table check condition */
  intcols       number,              /* #  of internal columns in constraint */
  mtime         varchar2(19), /* date this constraint was last enabled-disabled */
  flags         number,                                             /* flags */
                   /* see ku$_constraint0_t for flag bit definitions */
  oid_or_setid  number,   /* !0 = hidden unique constraint on OID column (1) */
                                  /* or nested tbl column's SETID column (2) */
  col_list      ku$_constraint_col_list_t,                        /* columns */
  ind           ku$_index_t                                /* index metadata */
)
not persistable
/

