create type ku$_analytic_view_hiers_t force as object
(
  av_obj#         number,                       /* obj# of the analytic view */
  dim_obj#        number,                            /* obj# of the hier dim */
  hier_owner      varchar2(128),     /* hier owner (hcs_av_hier$.hier_owner) */
  owner_in_ddl    number(1),                     /* whether owner was in DDL */
  hier_name       varchar2(128),       /* hier name (hcs_av_hier$.hier_name) */
  hier_alias      varchar2(128),    /* hier alias  (hcs_av_hier$.hier_alias) */
  is_default      varchar2(1),                                 /* is default */
  order_num       number                         /* order number of the hier */
)
not persistable
/

