create type ku$_code_base_grant_t force as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(2),                              /* UDT minor version # */
  role          varchar2(128),
  grantee       varchar2(128),          /* Owner of package, procedure, etc. */
  type_name     varchar2(128),         /* Name of code type, ie package name */
  code_type     varchar2(128),      /* Function, Procedure, Package, or Type */
  obj_num       number,                /* Object number of func, proced, etc */
  priv_num      number)                  /* Privilege number, ie role number */

not persistable
/

