create TYPE JSON_Array_T FORCE AUTHID CURRENT_USER
                       UNDER JSON_Element_T(
   dummy NUMBER,
   CONSTRUCTOR FUNCTION JSON_Array_T(self IN OUT JSON_ARRAY_T)
                        RETURN SELF AS RESULT,
   CONSTRUCTOR FUNCTION JSON_Array_T(self IN OUT JSON_ARRAY_T, jsn VARCHAR2)
                        RETURN SELF AS RESULT,
   CONSTRUCTOR FUNCTION JSON_Array_T(self IN OUT JSON_ARRAY_T, jsn JDOM_T)
                        RETURN SELF AS RESULT,
   CONSTRUCTOR FUNCTION JSON_Array_T(self IN OUT JSON_ARRAY_T, jsn CLOB)
                        RETURN SELF AS RESULT,
   CONSTRUCTOR FUNCTION JSON_Array_T(self IN OUT JSON_ARRAY_T, jsn BLOB)
                        RETURN SELF AS RESULT,
   CONSTRUCTOR FUNCTION JSON_Array_T(self IN OUT JSON_ARRAY_T, e JSON_ELEMENT_T)
                        RETURN SELF AS RESULT,

   -- override the 'parse' functions to directly RETURN Json_Array_T
   STATIC      FUNCTION  parse(jsn VARCHAR2) RETURN Json_Array_T,
   STATIC      FUNCTION  parse(jsn CLOB) RETURN Json_Array_T,
   STATIC      FUNCTION  parse(jsn BLOB) RETURN Json_Array_T,

   MEMBER      FUNCTION  clone(self IN JSON_ARRAY_T) RETURN JSON_ARRAY_T,

   MEMBER      FUNCTION  get(self IN JSON_ARRAY_T, pos NUMBER)
                         RETURN JSON_Element_T,
   MEMBER      FUNCTION  get_String(self IN JSON_ARRAY_T, pos NUMBER)
                         RETURN VARCHAR2,
   MEMBER      FUNCTION  get_Number(self IN JSON_ARRAY_T, pos NUMBER)
                         RETURN NUMBER,
   MEMBER      FUNCTION  get_Boolean(self IN JSON_ARRAY_T, pos NUMBER)
                         RETURN BOOLEAN,
   MEMBER      FUNCTION  get_Date(self IN JSON_ARRAY_T, pos NUMBER)
                         RETURN DATE,
   MEMBER      FUNCTION  get_Timestamp(self IN JSON_ARRAY_T, pos NUMBER)
                         RETURN TIMESTAMP,
   MEMBER      FUNCTION  get_Clob(self IN JSON_ARRAY_T, pos NUMBER) RETURN CLOB,
   MEMBER      PROCEDURE get_Clob(self IN OUT NOCOPY JSON_ARRAY_T, pos NUMBER,
                                  c IN OUT NOCOPY CLOB),
   MEMBER      FUNCTION  get_Blob(self IN JSON_ARRAY_T, pos NUMBER) RETURN BLOB,
   MEMBER      PROCEDURE get_Blob(self IN OUT NOCOPY JSON_ARRAY_T, pos NUMBER,
                                  b IN OUT NOCOPY BLOB),

 -- append at the end of array (no position needed)
   MEMBER      PROCEDURE append(self IN OUT NOCOPY JSON_ARRAY_T, val VARCHAR2),
   MEMBER      PROCEDURE append(self IN OUT NOCOPY JSON_ARRAY_T, val NUMBER),
   MEMBER      PROCEDURE append(self IN OUT NOCOPY JSON_ARRAY_T, val BOOLEAN),
   MEMBER      PROCEDURE append(self IN OUT NOCOPY JSON_ARRAY_T, val DATE),
   MEMBER      PROCEDURE append(self IN OUT NOCOPY JSON_ARRAY_T, val TIMESTAMP),
   --MEMBER      PROCEDURE append(val CLOB),
   --MEMBER      PROCEDURE append(val BLOB),
   MEMBER      PROCEDURE append(self IN OUT NOCOPY JSON_ARRAY_T,
                                val JSON_Element_T),
   MEMBER      PROCEDURE append_Null(self IN OUT NOCOPY JSON_ARRAY_T),

   MEMBER      PROCEDURE put(self IN OUT NOCOPY JSON_ARRAY_T, pos NUMBER,
                             val VARCHAR2, overwrite BOOLEAN DEFAULT FALSE),
   MEMBER      PROCEDURE put(self IN OUT NOCOPY JSON_ARRAY_T, pos NUMBER,
                             val NUMBER, overwrite BOOLEAN DEFAULT FALSE),
   MEMBER      PROCEDURE put(self IN OUT NOCOPY JSON_ARRAY_T, pos NUMBER,
                             val BOOLEAN, overwrite BOOLEAN DEFAULT FALSE),
   MEMBER      PROCEDURE put(self IN OUT NOCOPY JSON_ARRAY_T, pos NUMBER,
                             val DATE, overwrite BOOLEAN DEFAULT FALSE),
   MEMBER      PROCEDURE put(self IN OUT NOCOPY JSON_ARRAY_T, pos NUMBER,
                             val TIMESTAMP, overwrite BOOLEAN DEFAULT FALSE),
   --MEMBER      PROCEDURE put(pos NUMBER, val CLOB,
   --                            overwrite BOOLEAN DEFAULT FALSE),
   --MEMBER      PROCEDURE put(pos NUMBER, val BLOB,
   --                           overwrite BOOLEAN DEFAULT FALSE),
   MEMBER      PROCEDURE put(self IN OUT NOCOPY JSON_ARRAY_T, pos NUMBER,
                             val JSON_Element_T,
                             overwrite BOOLEAN DEFAULT FALSE),
   MEMBER      PROCEDURE put_Null(self IN OUT NOCOPY JSON_ARRAY_T, pos NUMBER,
                                  overwrite BOOLEAN DEFAULT FALSE),

   MEMBER      PROCEDURE remove(self IN OUT NOCOPY JSON_ARRAY_T, pos NUMBER),
   MEMBER      FUNCTION  get_Type(self IN JSON_ARRAY_T, pos NUMBER)
                         RETURN VARCHAR2
) FINAL
/

