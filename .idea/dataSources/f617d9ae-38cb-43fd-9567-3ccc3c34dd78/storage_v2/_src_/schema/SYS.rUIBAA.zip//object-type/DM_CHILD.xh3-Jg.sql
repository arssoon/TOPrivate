create type dm_child
                                       as object
  (id                    number)
/

