create type ku$_hcs_av_cache_lvl_t force as object
(
  av_obj#         number,                       /* obj# of the analytic view */
  lvlgrp#         number,                                    /* id of lvlgrp */
  dim_alias       varchar2(128),                    /* name of the dim alias */
  hier_alias      varchar2(128),                   /* name of the hier alias */
  level_name      varchar2(128),                        /* name of the level */
  order_num       number                        /* order number of the level */
)
not persistable
/

