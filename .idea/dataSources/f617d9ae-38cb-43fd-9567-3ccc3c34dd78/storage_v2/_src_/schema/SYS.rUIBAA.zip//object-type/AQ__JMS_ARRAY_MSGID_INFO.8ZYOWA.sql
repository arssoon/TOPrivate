create type aq$_jms_array_msgid_info
                                                                      
as object
(
   msgid    raw(16)
);
/

