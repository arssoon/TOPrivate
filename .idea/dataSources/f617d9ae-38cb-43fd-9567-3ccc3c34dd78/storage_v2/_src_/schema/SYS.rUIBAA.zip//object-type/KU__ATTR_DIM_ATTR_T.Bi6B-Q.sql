create type ku$_attr_dim_attr_t force as object
(
  dim_obj#       number,                             /* obj# of the hier dim */
  attr_id        number,                          /* attr id in the hier dim */
  name           varchar2(128),       /* attr name (hcs_dim_attr$.attr_name) */
  table_alias    varchar2(128),/* owner of column (hcs_src_col$.table_alias) */
  src_col_name   varchar2(128),/* name of column (hcs_src_col$.src_col_name) */
  clsfctn_list   ku$_hcs_clsfctn_list_t,                  /* classifications */
  order_num      number                        /* order number of attributes */
)
not persistable
/

