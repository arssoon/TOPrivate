create type ku$_clst_t force as object
(
  obj_num       number,                            /* object number of table */
  clstfunc      number,              /* Clustering Function                  */
                                     /* 1 - Hilbert                          */
                                     /* 2 - Order                            */
  flags         number,
                                     /* 0x00000001 - Load                    */
                                     /* 0x00000002 - Data Movement           */
  clstcols      ku$_clstcol_list_t,                        /* clustering key */
  clstjoin      ku$_clstjoin_list_t,                         /* cluster join */
  zonemap       ku$_clst_zonemap_t                                /* zonemap */
)
not persistable
/

