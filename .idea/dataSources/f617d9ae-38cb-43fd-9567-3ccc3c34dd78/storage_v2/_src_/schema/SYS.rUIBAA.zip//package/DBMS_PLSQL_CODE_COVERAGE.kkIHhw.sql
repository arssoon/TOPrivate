create package     dbms_plsql_code_coverage
  authid current_user is

  --------------
  --  OVERVIEW
  --
  --  This package provides APIs for collecting code coverage information
  --  at the basic block level of PL/SQL applications. Here basic block
  --  refers to a single entry single exit block of PL/SQL code.
  --  PL/SQL developers want to know how well their test infrastructure
  --  exercised their code. A typical code coverage run in a session
  --  involves calls to :
  --    start_coverage
  --     run pl/sql code
  --    stop_coverage
  --  Stopping coverage flushes the coverage data to a table

  coverage_error exception ;
  pragma exception_init(coverage_error, -8402);

  -- START_COVERAGE
  --
  -- This function starts coverage data collection at the basic block level
  -- in the user's session.
  --
  --
  -- PARAMETERS:
  --   run_comment - Allows the user to uniquely identify the run in a scope
  --                 that includes runs done in several databases.
  -- RETURN
  --               - A unique runid for this particular run.

  function  start_coverage(run_comment IN varchar2) return number;


  -- STOP_COVERAGE
  --
  -- This procedure stops basic block coverage data collection.
  --
  procedure stop_coverage;


  -- CREATE_COVERAGE_TABLES
  -- This procedure creates the coverage tables.
  --
  -- PARAMETERS:
  --  force_it               -If force_it is false and coverage tables are
  --                          present then a coverage error is raised. If
  --                          force_it is true then it silently creates tables.
  --                          If tables already exist then they are dropped and
  --                          new tables are created.
  --
  procedure create_coverage_tables(force_it IN boolean := false);


end dbms_plsql_code_coverage;
/

