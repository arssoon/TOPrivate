create type ku$_hcs_src_t force as object
(
  hcs_obj#       number,            /* obj# of the hier dim or analytic view */
  src_id         number,    /* id of the source in hier dim or analytic view */
  owner          varchar2(128),      /* owner of the source (hcs_src$.owner) */
  owner_in_ddl   number(1),                      /* whether owner was in DDL */
  name           varchar2(128),        /* name of the source (hcs_src$.name) */
  alias          varchar2(128),      /* alias of the source (hcs_src$.alias) */
  order_num      number                        /* order number of the soruce */
)
not persistable
/

