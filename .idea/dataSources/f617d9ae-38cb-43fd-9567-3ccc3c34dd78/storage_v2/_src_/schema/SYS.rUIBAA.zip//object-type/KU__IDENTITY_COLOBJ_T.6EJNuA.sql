create type ku$_identity_colobj_t force as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(2),                              /* UDT minor version # */
  obj_num       number,                      /* object number of base object */
  base_obj      ku$_schemaobj_t,                            /* schema object */
  property      number,                     /* column properties (bit flags) */
  property2     number,                        /*    more column properties  */
  identity_col  ku$_identity_col_t               /* Identity Col information */
)
not persistable
/

