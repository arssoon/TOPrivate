create type dm_glm_coeff
                                       as object
  (class                 varchar2(4000)
  ,attribute_name        VARCHAR2(4000)
  ,attribute_subname    VARCHAR2(4000)
  ,attribute_value       VARCHAR2(4000)
  ,feature_expression    VARCHAR2(4000)
  ,coefficient           NUMBER
  ,std_error             NUMBER
  ,test_statistic        NUMBER
  ,p_value               NUMBER
  ,vif                   NUMBER
  ,std_coefficient       NUMBER
  ,lower_coeff_limit     NUMBER
  ,upper_coeff_limit     NUMBER
  ,exp_coefficient       BINARY_DOUBLE
  ,exp_lower_coeff_limit BINARY_DOUBLE
  ,exp_upper_coeff_limit BINARY_DOUBLE
  )
/

