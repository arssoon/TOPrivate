create TYPE     aq$_agent
                                                                      
AS OBJECT
( name          varchar2(30), -- M_IDEN, name of a message producer or consumer
  address       varchar2(1024),           -- address where message must be sent
  protocol      number)                -- protocol for communication, must be 0
 alter type     aq$_agent modify attribute
           (name varchar2(512)) CASCADE
/

