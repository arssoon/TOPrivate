create type ku$_hcs_av_cache_mlst_t force as object
(
  av_obj#         number,                       /* obj# of the analytic view */
  measlst#        number,                                   /* id of measlst */
  meas_list       ku$_hcs_av_cache_meas_list_t,                  /* measures */
  lvlgrp_list     ku$_hcs_av_cache_lvgp_list_t               /* level groups */
)
not persistable
/

