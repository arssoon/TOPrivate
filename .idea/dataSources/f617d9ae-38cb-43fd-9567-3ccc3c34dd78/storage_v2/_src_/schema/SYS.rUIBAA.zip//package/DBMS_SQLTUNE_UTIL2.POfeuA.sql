create PACKAGE dbms_sqltune_util2 AUTHID CURRENT_USER AS

  --
  -- Database type constants
  -- Describe the type of database that corresponds to the dbid value that
  -- is passed as parameter to resolve_db_type function.
  --
  DB_TYPE_ROOT CONSTANT VARCHAR(4) := 'ROOT';
  DB_TYPE_PDB  CONSTANT VARCHAR(3) := 'PDB';
  DB_TYPE_IMP  CONSTANT VARCHAR(8) := 'IMPORTED';

  -- String constants
  STR_YES   constant varchar2(3) := 'yes';
  STR_NO    constant varchar2(3) := 'no';

  ------------------------------ resolve_username -----------------------------
  -- NAME:
  --     resolve_username
  --
  -- DESCRIPTION:
  --     When passed a NULL username, this function returns the current schema
  --     owner. Otherwise, it validates the username and returns a normalized
  --     one, i.e.:
  --       - if the username is case-sensitive it removes the double quotes
  --       - else it converts it to uppercase.
  --
  -- PARAMETERS:
  --     user_name    (IN) - the name of the schema to resolve
  --     con_id       (IN) - id of container in which to resolve user_name
  --
  -- RETURN:
  --     normalized schema
  --
  -- NOTES
  --     This function is currently used by:
  --       1. SQLset APIs in order to set the sqlset_owner when NULL.
  --       2. Staging table APIs in order to set the staging_schema_owner when
  --          NULL.
  --       3. create_tuning/analysis/diagnosis_task (parsing_schema flavor) in
  --          order to set the parsing_schema when NULL.
  --       4. create_sql_plan_baseline in order to set the parsing_schema when
  --          NULL.
  --     Note that in all cases the returned schema is used for name resolution
  --     NOT for privilege loading. This function should NOT be used when the
  --     returned username will be used later on for loading privileges, for
  --     instance as the owner of an advisor task. This is because the function
  --     will return the CURRENT_SCHEMA instead of the CURRENT_OWNER when the
  --     user_name passed is NULL. CURRENT_SCHEMA is not safe since it can
  --     be modified via 'alter session set current_schema'.
  -----------------------------------------------------------------------------
  FUNCTION resolve_username(user_name IN VARCHAR2,
                            con_id    IN NUMBER := NULL)
  RETURN VARCHAR2;

  -------------------------------- validate_snapshot --------------------------
  -- NAME:
  --     validate_snapshot
  --
  -- DESCRIPTION:
  --     This function checks whether a snapshot id interval is valid.
  --     It raises an error if passed an invalid interval.
  --
  -- PARAMETERS:
  --     begin_snap (IN) - begin snapshot id
  --     end_snap   (IN) - end snapshot id
  --     awr_dbid   (IN) - database id
  --     incl_bid   (IN) - TRUE:  fully-inclusive [begin_snap, end_snap]
  --                       FALSE: half-inclusive  (begin_snap, end_snap]
  --
  -- RETURN:
  --      VOID
  --
  -- NOTE:
  --     This function supports remote execution either via UMF or by task
  --     parameters.
  -----------------------------------------------------------------------------
  PROCEDURE validate_snapshot(
    begin_snap IN NUMBER,
    end_snap   IN NUMBER,
    awr_dbid   IN NUMBER  := NULL,
    incl_bid   IN BOOLEAN := FALSE);

  --------------------------- sql_binds_ntab_to_varray ------------------------
  -- NAME:
  --     sql_binds_ntab_to_varray
  --
  -- DESCRIPTION:
  --     This function converts the sql binds data from the nested table stored
  --     in the staging table on an unpack/pack to the varray type used in the
  --     SQLSET_ROW. It is called by the unpack_stgtab_sqlset function since it
  --     needs to pass binds as a VARRAY to the load_sqlset function
  --
  -- PARAMETERS:
  --     binds_nt      (IN)  - list of binds for a single statement, in the
  --                           sql_binds nested table type
  --
  -- RETURN:
  --     Corresponding varray type (sql_binds_varray) to the input, which is
  --     an ordered list of bind values, of type ANYDATA.
  --     If given null as input this function returns null.
  --
  -----------------------------------------------------------------------------
  FUNCTION sql_binds_ntab_to_varray(binds_ntab IN SQL_BIND_SET)
  RETURN SQL_BINDS;

  ------------------------- sql_binds_varray_to_ntab -------------------------
  -- NAME:
  --     sql_binds_varray_to_ntab
  --
  -- DESCRIPTION:
  --     This function converts the sql binds data from a VARRAY as it exists
  --     in SQLSET_ROW into a nested table that can be stored in the staging
  --     table.
  --     It is called by pack_stgtab_sqlset as it inserts into the staging
  --     table from the output of a call to select_sqlset.
  --
  -- PARAMETERS:
  --     binds_varray      (IN)  - list of binds for a single statement, in the
  --                               sql_binds VARRAY type
  --
  -- RETURN:
  --     Corresponding nested table type (sql_bind_set) to the input, which is
  --     a list of (position, value) pairs for the information in STMT_BINDS.
  --     If given null as input this function returns null.
  --
  -----------------------------------------------------------------------------
  FUNCTION sql_binds_varray_to_ntab(binds_varray IN SQL_BINDS)
  RETURN SQL_BIND_SET;

  ----------------------------------- check_priv ------------------------------
  -- NAME:
  --     check_priv
  --
  -- DESCRIPTION:
  --     This function does a callout into the kernel to check for the given
  --     system privilege.  It returns TRUE or FALSE based on whether the
  --     current user has the privilege enabled.  This replaces the old-style
  --     privilege detection through SQL with the added benefit that it allows
  --     auditing of the privilege.  This function is just a wrapper around
  --     kzpcap.  This is used for the ADVISOR, ADMINISTER SQL TUNING SET,
  --     and ADMINISTER ANY SQL TUNING SET privileges.
  --
  --     NOTE that this function should only be used when checking privileges
  --     from an INVOKER rights package.  In the callout function we do not
  --     switch the user prior to calling kzpcap, so we rely on the proper
  --     security context already being in effect prior to calling this
  --     function.  If you call it after switching into a DEFINER rights
  --     package, it will end up checking if SYS has the priv, not the user.
  --     If you have any questions about its proper use, please consult the
  --     file owner.
  --
  -- PARAMETERS:
  --     priv (IN) - privilege name
  --
  -- RETURN:
  --     TRUE if priv is enabled, FALSE otherwise
  --
  -----------------------------------------------------------------------------
  FUNCTION check_priv(priv IN VARCHAR2)
  RETURN BOOLEAN;

  ------------------------------ get_timing_info ------------------------------
  -- NAME:
  --     get_timing_info
  --
  -- DESCRIPTION:
  --     This function allows one to get elapsed and CPU timing information
  --     for a section of PL/SQL code
  --
  -- PARAMETERS:
  --     phase          (IN)      - When called: 0 for start, 1 for end
  --     elapsed_time  (IN/OUT)  - When "phase" is 0, OUT parameter storing
  --                               current timestamp. When "phase" is 1, used
  --                               both as IN/OUT to return elpased time.
  --     cpu_time      (IN/OUT)  - When "phase" is 0, OUT parameter storing
  --                               current cpu time. When "phase" is 1, used
  --                               both as IN/OUT to return cpu time.
  --
  -- DESCRIPTION
  --   Use this procedure to measure the elapsed/cpu time of a region of
  --   code:
  --     get_timing_info(0, elapsed, cpu_time);
  --     ...
  --     get_timing_info(1, elapsed, cpu_time);
  --
  -- RETURN:
  --     None
  --
  ----------------------------------------------------------------------------
  PROCEDURE get_timing_info(
    phase      IN      BINARY_INTEGER,
    elapsed    IN OUT  NUMBER,
    cpu        IN OUT  NUMBER);

  ------------------------------- is_ras_user --------------------------------
  -- NAME:
  --     is_ras_user
  --
  -- DESCRIPTION:
  --     This utility function returns TRUE or FALSE based on whether the
  --     current user is a Real Application Security User (RAS) user. This
  --     function is used by create_tuning_task, schedule_tuning_task and
  --     create_analysis_task.
  --
  -- PARAMETERS:
  --
  -- RETURN:
  --     TRUE if the current user is a RAS user, FALSE otherwise
  --
  -----------------------------------------------------------------------------
  FUNCTION is_ras_user
  RETURN BOOLEAN;

  ------------------------------- varr_to_hints_xml ---------------------------
  -- NAME:
  --     varr_to_hints_xml
  --
  -- DESCRIPTION:
  --     This function converts sqlprof_attr object type to XML format
  --
  -- PARAMETERS:
  --      sqlprof_attr (IN) - hints in attribute format
  --
  -- RETURN:
  --      hints in their XML format
  --
  -- EXCEPTIONS:
  --      None
  --
  -----------------------------------------------------------------------------
  FUNCTION varr_to_hints_xml(varr IN sqlprof_attr)
  RETURN CLOB;

  ----------------------------- get_sqlset_userbinds --------------------------
  -- NAME:
  --     get_sqlset_userbinds
  --
  -- DESCRIPTION:
  --     This function gets the list of binds of a given SQL statement from
  --     a table and converts the list of binds into a varray as required by
  --     sqlset_row. This function is used in dbms_sqltune.unpack_sqlsets_bulk
  --
  -- PARAMETERS:
  --     sql_id          (IN)  - SQL id
  --     plan_hash_value (IN)  - plan hash value
  --     sqlset_name     (IN)  - SQLset name
  --     sqlset_owner    (IN)  - SQLset owner
  --     table_name      (IN)  - name of the table that contains the binds
  --
  -- RETURN:
  --     Corresponding varray type (sql_binds_varray) to the input, which is
  --     an ordered list of bind values, of type ANYDATA.
  --     This function returns null if there are no binds.
  --
  -----------------------------------------------------------------------------
  FUNCTION get_sqlset_userbinds(sql_id          IN VARCHAR2,
                                plan_hash_value IN NUMBER,
                                sqlset_name     IN VARCHAR2,
                                sqlset_owner    IN VARCHAR2,
                                table_name      IN VARCHAR2)
  RETURN SQL_BINDS;


  -------------------------- resolve_database_type ----------------------------
  -- NAME:
  --     resolve_database_type
  --
  -- DESCRIPTION:
  --     This function resolves the type of database that corresponds to the
  --     dbid given as parameter. It is used by get_awr_view_location function
  --     to determine the location of AWR views.
  --
  -- PARAMETERS:
  --     dbid            (IN)  - database id
  --
  -- RETURN:
  --     Returned type can be 'ROOT', 'PDB' or 'IMPORTED'.
  --
  -----------------------------------------------------------------------------
  FUNCTION resolve_database_type(dbid IN NUMBER)
  RETURN VARCHAR2;

  ---------------------------- is_imported_cdb --------------------------------
  -- NAME: is_imported_cdb
  --
  -- DESCRIPTION: Checks whether the dbid is imported cdb or not
  --
  -- PARAMETERS:
  --   dbid   (IN) - dbid
  --
  -- RETURNS:
  --    boolean true if dbid is imported cdb
  --    boolean false if dbid is not imported cdb
  --
  function is_imported_cdb (
    p_dbid            IN number)
  return varchar2;

  ---------------------------- is_imported_pdb --------------------------------
  -- NAME: is_imported_pdb
  --
  -- DESCRIPTION: Checks whether the dbid is imported cdb or not
  --
  -- PARAMETERS:
  --   dbid   (IN) - dbid
  --
  -- RETURNS:
  --    boolean true if dbid is imported pdb
  --    boolean false if dbid is not imported pdb
  --
  function is_imported_pdb (
    p_dbid            IN number)
  return varchar2;

END dbms_sqltune_util2;
/

