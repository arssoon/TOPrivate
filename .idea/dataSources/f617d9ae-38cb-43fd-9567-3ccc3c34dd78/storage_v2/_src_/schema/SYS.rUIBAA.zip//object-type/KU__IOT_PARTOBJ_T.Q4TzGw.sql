create type ku$_iot_partobj_t force as object
(
  obj_num       number,                                     /* obj# of table */

  tabpartobj    ku$_partobj_t,                       /* table partition info */
  partcols      ku$_part_col_list_t,         /* list of partitioning columns */
  subpartcols   ku$_part_col_list_t,      /* list of subpartitioning columns */



  indpartobj    ku$_partobj_t,                       /* index partition info */
  ovpartobj     ku$_partobj_t,                    /* overflow partition info */
  part_list     ku$_piot_part_list_t,                      /* partition list */
  iov_list      ku$_ov_tabpart_list_t,           /* overflow part table list */
  imap_list     ku$_map_tabpart_list_t            /* mapping part table list */
)
not persistable
/

