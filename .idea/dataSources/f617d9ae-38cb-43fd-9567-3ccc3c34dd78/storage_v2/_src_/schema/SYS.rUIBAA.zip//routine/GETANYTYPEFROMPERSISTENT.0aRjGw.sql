create Function GetAnyTypeFromPersistent
(schema_name IN VARCHAR2, type_name IN VARCHAR2) return AnyType
authid CURRENT_USER
is
LANGUAGE C
NAME "at8"
LIBRARY DBMS_ANYTYPE_LIB
parameters( schema_name STRING, schema_name INDICATOR sb2,
            type_name STRING, type_name INDICATOR sb2,
            RETURN INDICATOR sb2, RETURN);
/

