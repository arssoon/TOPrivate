create Function GetTvoid(type_oid IN RAW, vsn IN PLS_INTEGER) return
                    RAW AS
 tv_oid RAW(16);
begin
 select tvoid into tv_oid from type$ where toid = type_oid and
   version# = vsn;
 return (tv_oid);
end;
/

