create package dbms_java authid current_user as

  type compiler_option_type is record(option_line varchar2(128));

  type compiler_option_type_table is table of compiler_option_type;

  PROCEDURE start_btl;

  PROCEDURE stop_btl;

  PROCEDURE terminate_btl;

  -- compile all methods defined by the class identified by
  -- classname in the current schema.
  -- return the number of methods successfully compiled
  --
  -- If the class does not exist an ORA-29532 (Uncaught Java
  -- exception) will occur.
  FUNCTION compile_class(classname VARCHAR2) return NUMBER;


  -- compile the method specified by name and Java type signature
  -- defined by the class identified by classname in the current
  -- schema.
  -- return the number of methods successfully compiled
  --
  -- If the class does not exist, an ORA-29532 (Uncaught Java
  -- exception) will occur.
  FUNCTION compile_method(classname  VARCHAR2,
                          methodname VARCHAR2,
                          methodsig  VARCHAR2) return NUMBER;


  -- uncompile all methods defined by the class identified by
  -- classname in the current schema.
  --
  -- return the number of methods successfully uncompiled.
  --
  -- If permanentp, then mark these methods as permanently dynamicaly
  -- un-compilable, otherwise, they are eligible for future dynamic
  -- recompilation.
  --
  -- If the class does not exist an ORA-29532 (Uncaught Java
  -- exception) will occur.
  FUNCTION uncompile_class(classname VARCHAR2,
                           permanentp NUMBER default 0) return NUMBER;


  -- uncompile the method specified by the name and Java type
  -- signature defined by the class identified by classname in the
  -- current schema.
  --
  -- return the number of methods successfully uncompiled.
  --
  -- If permanentp, then mark the method as permanently dynamicaly
  -- un-compilable, otherwise, it is eligible for future dynamic
  -- recompilation.
  --
  -- If the class does not exist an ORA-29532 (Uncaught Java
  -- exception) will occur.
  FUNCTION uncompile_method(classname  VARCHAR2,
                            methodname VARCHAR2,
                            methodsig  VARCHAR2,
                            permanentp NUMBER default 0) return NUMBER;

  --
  -- Dump the native code (if available) for the specified method to trace.
  --
  PROCEDURE dump_native_machine_code(classname  VARCHAR2,
                                     methodname VARCHAR2,
                                     methodsig  VARCHAR2);

  FUNCTION native_compiler_options return compiler_option_type_table pipelined;

  -- sets a native-compiler option to the specified value for the
  -- current schema
  PROCEDURE set_native_compiler_option(optionName VARCHAR2,
                                       value      VARCHAR2);

  -- decode, into a user-readable format, a persisted native-compiler
  -- option.  This function is not intended to be used by users
  -- directly
  FUNCTION decode_native_compiler_option(optionName VARCHAR2,
                                         value      VARCHAR2) RETURN VARCHAR2;

  -- unsets a native-compiler option given by the tuple
  --   [optionName, value].
  --
  -- if the option given by optionName is not allowed to have
  -- duplicate values, then the value is ignored.
  PROCEDURE unset_native_compiler_option(optionName VARCHAR2,
                                         value      VARCHAR2);

  FUNCTION init_btl(files_prefix VARCHAR2, type NUMBER,
                    sample_limit NUMBER, exclude_java NUMBER) return NUMBER;
  pragma restrict_references(init_btl, wnds, wnps);

  FUNCTION longname (shortname VARCHAR2) return VARCHAR2;
  pragma restrict_references(longname, wnds, wnps);

  FUNCTION shortname (longname VARCHAR2) RETURN VARCHAR2;
  pragma restrict_references(shortname, wnds, wnps);

  -- functions and procedures to manipulate the compiler option table
  -- what refers to a source name, package or class depending

  -- determine the option value for option optionName applied to
  -- what
  FUNCTION get_compiler_option(what VARCHAR2, optionName VARCHAR2)
    return varchar2 ;
  pragma restrict_references (get_compiler_option, wnds, wnps);

  -- set the option value to value for option optionName applied to
  -- what.  And depending upon the characteristics of optionName
  -- it may apply to "descendants" of what as well.
  PROCEDURE set_compiler_option(what VARCHAR2, optionName VARCHAR2, value VARCHAR2);

  -- reset the option value. That is, undo an action performed by
  -- set_compiler_option
  PROCEDURE reset_compiler_option(what VARCHAR2, optionName VARCHAR2);

  FUNCTION resolver (name VARCHAR2, owner VARCHAR2, type VARCHAR2)
     RETURN VARCHAR2;
  pragma restrict_references(resolver, wnds);

  FUNCTION derivedFrom (name VARCHAR2, owner VARCHAR2, type VARCHAR2)
     RETURN VARCHAR2;
  pragma restrict_references(derivedFrom, wnds);

  FUNCTION fixed_in_instance (name VARCHAR2, owner VARCHAR2, type VARCHAR2)
     RETURN NUMBER;
  pragma restrict_references(fixed_in_instance, wnds);

  PROCEDURE set_fixed_in_instance (name VARCHAR2, owner VARCHAR2,
                                   type VARCHAR2, value NUMBER);

  FUNCTION sharedPrivateClassName (name VARCHAR2)
     RETURN VARCHAR2;
  pragma restrict_references(sharedPrivateClassName, wnds);

  -- RUNJAVA interface.  RUNJAVA is a facility for running
  -- java in the OJVM server resident VM using a command line
  -- interface that emulates the JDK java shell command.  In
  -- particular, this interface allows the use of -classpath
  -- to run classes loaded directly from the file system without
  -- the intervening step of loading these classes into the database
  -- via loadjava or the equivalent.  It also supports use of -D
  -- arguments to set System property values.  There is an
  -- auxiliary facility for establishing System property values
  -- used by default (without requiring -D, in a manner intended
  -- to be analogous to the use of environment variable by the
  -- JDK in setting certain System properties).

  -- runjava:  This function takes a java command line as its
  -- only argument and executes that command in the OJVM.  The
  -- return value is null on successful completion, otherwise
  -- an error message.  The format of the command line is the
  -- same as that taken by the JDK java shell command, ie
  -- [option switches] name_of_class_to_execute [arg1 arg2 ... argn]
  -- The option switches -classpath and -D are supported.  Others
  -- may be supported if they make sense in the OJVM environment.
  -- This function differs from runjava_in_current_session in
  -- that it clears any java state remaining from previous use of
  -- java in the session prior to running the current command.
  -- This is necessary in particular to guarantee that static
  -- variable values derived at class initialization time from
  -- -classpath and -D arguments are reflect the values of those
  -- switches in the current command line.
  FUNCTION runjava(cmdline VARCHAR2) RETURN VARCHAR2;

  -- runjava_in_current_session:  This function is the same as the
  -- runjava function except that it does not clear java state
  -- remaining from previous use of java in the session prior to
  -- executing the current command line.  See the description
  -- of runjava for other details.
  FUNCTION runjava_in_current_session(cmdline VARCHAR2) RETURN VARCHAR2;

  -- endsession:  This function clears any java session state remaining
  -- from previous execution of java in the current RDBMS session.
  -- The return value is a message indicating the action taken.
  FUNCTION endsession RETURN VARCHAR2;

  -- endsession_and_related_state:  This function clears any java
  -- session state remaining from previous execution of java in the
  -- current RDBMS session and all supporting data related to running
  -- java, such as property settings and output specifications.
  -- The return value is a message indicating the action taken.
  FUNCTION endsession_and_related_state RETURN VARCHAR2;

  -- set_property:  This function provides for establishing
  -- a value for a System property which will be used thereafter for the
  -- duration of the current RDBMS session whenever a java session is
  -- initialized.  The first argument is the name of the property
  -- and the second is the value to be established for it.  The return value
  -- from set_property is null unless some error occurred, such as an
  -- attempt to set a value for a prescribed property, in which case
  -- an error message is returned.
  FUNCTION set_property(name VARCHAR2, value VARCHAR2) RETURN VARCHAR2;

  -- get_property:  This function returns any value previously established
  -- by set_property, or null if there is no such value.
  FUNCTION get_property(name VARCHAR2) RETURN VARCHAR2;

  -- remove_property:  This function removes any value previously established
  -- by set_property.  The return value is null unless an error occurred,
  -- in which case an error message is returned.
  FUNCTION remove_property(name VARCHAR2) RETURN VARCHAR2;

  -- show_property.  This function prints a message of the form
  --   name = value for the input name, or for all established property
  -- bindings if name is null.  The return value is null on successful
  -- completion, otherwise it is an error message.  The output is
  -- printed to wherever java output is current directed.
  FUNCTION show_property(name VARCHAR2) RETURN VARCHAR2;

  -- Methods for controlling destination of java output
  PROCEDURE set_output (buffersize NUMBER);

  -- set_output_to_sql defines a named output specification which
  -- constitutes a prescription for executing a sql statement whenever
  -- output to the default System.out and System.err streams occurs.
  -- The specification is defined for the duration of the current
  -- session, or until remove_output_to_sql is called with its id.
  -- The sql actions the specification prescribes will occur whenever
  -- there is java output unless disable_output_to_sql has been called,
  -- in which case the actions will not occur again until
  -- enable_output_to_sql is called.
  --
  -- Arguments are
  --   id       The name of the specification.  Multiple specifications
  --            may exist in the same session, but each must have a distinct
  --            id.  The id is used to identify the specification in the
  --            functions remove, enable, disable and query_output_to_sql.
  --   stmt     The default sql statement to execute when java output occurs.
  --   bindings A string containing tokens from the set
  --            ID, TEXT, LENGTH, LINENO, SEGNO, NL and ERROUT.  This string
  --            defines how the sql statement stmt will be bound.  The
  --            position in the bindings string of a token corresponds to
  --            the bind position in the sql statement.  The meanings of the
  --            tokens are
  --            ID  the id of the specification, bound as a VARCHAR2
  --            TEXT  the text being output, bound as a VARCHAR2
  --            LENGTH the length of the text, bound as a NUMBER
  --            LINENO the line number (since the beginning of session output),
  --                   bound as a NUMBER
  --            SEGNO the segment number within a line that is being output
  --                   in more than one piece, bound as a NUMBER
  --            NL a boolean indicating whether the text is to be regarded
  --               as newline terminated, bound as a NUMBER.  The newline
  --               may or may not actually be included in the text, depending
  --               on the value of the include_newlines argument discussed
  --               below.
  --            ERROUT a boolean indicating whether the output came from
  --               System.out or System.err, bound as a NUMBER.  The value
  --               is 0 iff the output came from System.out.
  --   no_newline_stmt   An optional alternate sql statement to execute
  --                     when the output is not newline terminated.
  --   no_newline_bindings  A string with the same syntax as for the bindings
  --                        argument discussed above, describing how the
  --                        no_newline_stmt is bound.
  --   newline_only_stmt   An optional alternate sql statement to execute
  --                       when the output is a single newline.
  --   newline_only_bindings  A string with the same syntax as for the bindings
  --                          argument discussed above, describing how the
  --                          newline_only_stmt is bound.
  --   maximum_line_segment_length  The maximum number of characters that
  --                                will be bound in a given execution of
  --                                the sql statement.  Longer output
  --                                sequences will be broken up into
  --                                separate calls with distinct SEGNO
  --                                values.  A value of 0 means no maximum.
  --   allow_replace  Controls behavior when a previously defined specification
  --                  with the same id exists.  A value of 1 means replace the
  --                  old specification.  0 means return an error message
  --                  without modifying the old specification.
  --   from_stdout  Controls whether output from System.out causes execution
  --                of the sql statement prescribed by the specification.  A
  --                value of 0 means that if the output came from System.out
  --                the statement is not executed even if the specification is
  --                otherwise enabled.
  --   from_stderr  Controls whether output from System.err causes execution
  --                of the sql statement prescribed by the specification.  A
  --                value of 0 means that if the output came from System.err
  --                the statement is not executed even if the specification is
  --                otherwise enabled.
  --   include_newlines  Controls whether newline characters are left in the
  --                     output when it is bound to text.  A value of 0 means
  --                     newlines are not included (but the presence of the
  --                     newline is still indicated by the NL binding and
  --                     by whether the no_newline_stmt is used).
  --   eager  Controls whether output not terminated by a newline causes
  --          execution of the sql statement every time it is received vs
  --          accumulating such output until a newline is received.  A value
  --          of 0 means that unterminated output is accumulated.
  --
  -- Return value is null on success otherwise an error message.
  FUNCTION set_output_to_sql (id VARCHAR2,
                              stmt VARCHAR2,
                              bindings VARCHAR2,
                              no_newline_stmt VARCHAR2 default null,
                              no_newline_bindings VARCHAR2 default null,
                              newline_only_stmt VARCHAR2 default null,
                              newline_only_bindings VARCHAR2 default null,
                              maximum_line_segment_length NUMBER default 0,
                              allow_replace NUMBER default 1,
                              from_stdout NUMBER default 1,
                              from_stderr NUMBER default 1,
                              include_newlines NUMBER default 0,
                              eager NUMBER default 0) return VARCHAR2;

  -- remove_output_to_sql deletes a specification created by
  -- set_output_to_sql.  If no such specification exists, an error message
  -- is returned
  FUNCTION remove_output_to_sql (id VARCHAR2) return VARCHAR2;

  -- enable_output_to_sql (re)enables a specification created by
  -- set_output_to_sql and subsequently disabled by disable_output_to_sql.
  -- If no such specification exists, an error message is returned.  If
  -- the specification is not currently disabled, there is no change.
  FUNCTION enable_output_to_sql (id VARCHAR2) return VARCHAR2;

  -- disable_output_to_sql disables a specification created by
  -- set_output_to_sql.  The specification may be re-enabled by
  -- enable_output_to_sql.  While disabled, the sql statement prescribed
  -- by the specification is not executed.
  -- If no such specification exists, an error message is returned.  If
  -- the specification is already disabled, there is no change.
  FUNCTION disable_output_to_sql (id VARCHAR2) return VARCHAR2;

  -- query_output_to_sql returns a message describing a specification
  -- created by set_output_to_sql.
  -- If no such specification exists, an error message is returned.
  FUNCTION query_output_to_sql (id VARCHAR2) return VARCHAR2;

  -- set_output_to_java defines a named output specification which
  -- constitutes a prescription for executing a java method whenever
  -- output to the default System.out and System.err streams occurs.
  -- See the comments for set_output_to_sql for discussion of the
  -- common arguments and the duration of the specifications.  The
  -- java method prescribed by the specification is executed in a
  -- separate VM context with separate java session state from the
  -- rest of the session.
  -- Arguments specific to this type of specification are
  --   class_name  The name of the class defining the method(s)
  --   class_schema  The schema in which the class is defined.  A null
  --                 value means the class is defined in the current schema,
  --                 or PUBLIC.
  --   method  The name of the method.
  --   bindings  A string that defines how arguments to the method are bound.
  --             This is a string of tokens with the same syntax as discussed
  --             under set_output_to_sql above.  The position of a token in
  --             the string determines the position of the argument it
  --             describes.  All arguments must be of type int, except for
  --             those corresponding to the tokens ID or TEXT, which must be
  --             of type java.lang.String.
  --   no_newline_method   An optional alternate method to execute
  --                       when the output is not newline terminated.
  --   newline_only_method   An optional alternate method to execute
  --                         when the output is a single newline.
  --   initialization_statement  An optional sql statement that is executed
  --                             once per java session prior to the first
  --                             time the methods that receive output are
  --                             executed.  This statement is executed in
  --                             same java VM context as the output methods
  --                             will be.  Typically such a statement is
  --                             used to run a java stored procedure that
  --                             initializes conditions in the separate VM
  --                             context so that the methods that receive
  --                             output can function as intended.  For
  --                             example such a procedure might open a
  --                             stream which the output methods write to.
  --   finalization_statement  An optional sql statement that is executed
  --                           once when the output specification is
  --                           about to be removed or the session is ending.
  --                           Like the initialization_statement this runs
  --                           in the same java VM context as the methods
  --                           that receive output.  It runs only if the
  --                           initialization method has run, or if there is
  --                           no initialization method.
  FUNCTION set_output_to_java (id VARCHAR2,
                               class_name VARCHAR2,
                               class_schema VARCHAR2,
                               method VARCHAR2,
                               bindings VARCHAR2,
                               no_newline_method VARCHAR2 default null,
                               no_newline_bindings VARCHAR2 default null,
                               newline_only_method VARCHAR2 default null,
                               newline_only_bindings VARCHAR2 default null,
                               maximum_line_segment_length NUMBER default 0,
                               allow_replace NUMBER default 1,
                               from_stdout NUMBER default 1,
                               from_stderr NUMBER default 1,
                               include_newlines NUMBER default 0,
                               eager NUMBER default 0,
                               initialization_statement VARCHAR2 default null,
                               finalization_statement VARCHAR2 default null)
         return VARCHAR2;

  -- remove_output_to_java deletes a specification created by
  -- set_output_to_java.  If no such specification exists, an error message
  -- is returned
  FUNCTION remove_output_to_java (id VARCHAR2) return VARCHAR2;

  -- enable_output_to_java (re)enables a specification created by
  -- set_output_to_java and subsequently disabled by disable_output_to_java.
  -- If no such specification exists, an error message is returned.  If
  -- the specification is not currently disabled, there is no change.
  FUNCTION enable_output_to_java (id VARCHAR2) return VARCHAR2;

  -- disable_output_to_java disables a specification created by
  -- set_output_to_java.  The specification may be re-enabled by
  -- enable_output_to_java.  While disabled, the sql statement prescribed
  -- by the specification is not executed.
  -- If no such specification exists, an error message is returned.  If
  -- the specification is already disabled, there is no change.
  FUNCTION disable_output_to_java (id VARCHAR2) return VARCHAR2;

  -- query_output_to_java returns a message describing a specification
  -- created by set_output_to_java.
  -- If no such specification exists, an error message is returned.
  FUNCTION query_output_to_java (id VARCHAR2) return VARCHAR2;

  -- set_output_to_file defines a named output specification which
  -- constitutes a prescription to capture any output sent to the
  -- default System.out and System.err streams and append it to
  -- a specified file.  This is implemented using a special case
  -- of set_output_to_java.  Arguments are
  --   file_path  The path to the file to which to append the output
  --   allow_replace, from_stdout and from_stderr all analogous to
  --      those of the same name in set_output_to_java
  FUNCTION set_output_to_file (id VARCHAR2,
                               file_path VARCHAR2,
                               allow_replace NUMBER default 1,
                               from_stdout NUMBER default 1,
                               from_stderr NUMBER default 1)
         return VARCHAR2;

  -- The following four functions are analogous to their output_to_java
  -- counterparts
  FUNCTION remove_output_to_file (id VARCHAR2) return VARCHAR2;

  FUNCTION enable_output_to_file (id VARCHAR2) return VARCHAR2;

  FUNCTION disable_output_to_file (id VARCHAR2) return VARCHAR2;

  FUNCTION query_output_to_file (id VARCHAR2) return VARCHAR2;

  -- The following two procedures are for internal use in the
  -- implementation of set_output_to_file
  PROCEDURE initialize_output_to_file (id VARCHAR2, path VARCHAR2);

  PROCEDURE finalize_output_to_file (id VARCHAR2);

  -- The following two procedures and one function control
  -- whether java output is sent to the .trc file (this is the
  -- case by default)
  PROCEDURE enable_output_to_trc;

  PROCEDURE disable_output_to_trc;

  FUNCTION query_output_to_trc return VARCHAR2;

  -- import/export interface --
  function start_export(short_name in varchar2,
                        schema in varchar2,
                        flags in number,
                        type in number,
                        properties out number,
                        raw_chunk_count out number,
                        total_raw_byte_count out number,
                        text_chunk_count out number,
                        total_text_byte_count out number)
         return number;
  pragma restrict_references(start_export, wnds);

  function export_raw_chunk(chunk out raw, length out number)
           return number;
  pragma restrict_references(export_raw_chunk, wnds);

  function export_text_chunk(chunk out varchar2, length out number)
           return number;
  pragma restrict_references(export_text_chunk, wnds);


  function end_export return number;
  pragma restrict_references(end_export, wnds);


  function start_import(long_name in varchar2,
                        flags in number,
                        type in number,
                        properties in number,
                        raw_chunk_count in number,
                        total_raw_byte_count in number,
                        text_chunk_count in number)
         return number;
  pragma restrict_references(start_import, wnds);


  function import_raw_chunk(chunk in raw, length in number)
           return number;
  pragma restrict_references(import_raw_chunk, wnds);


  function import_text_chunk(chunk in varchar2, length in number)
           return number;
  pragma restrict_references(import_text_chunk, wnds);


  function end_import return number;
  pragma restrict_references(end_import, wnds);


  -- grant or revoke execute via Handle methods.  Needed with system class
  -- loading since SQL grant/revoke can't manipulate permanently kept objects
  procedure set_execute_privilege(object_name   varchar2,
                                  object_schema varchar2,
                                  object_type   varchar2,
                                  grantee_name  varchar2,
                                  grant_if_nonzero number)
  as language java name
  'oracle.aurora.rdbms.DbmsJava.setExecutePrivilege(java.lang.String,
                                                    oracle.sql.CHAR,
                                                    java.lang.String,
                                                    oracle.sql.CHAR,
                                                    boolean)';

  -- convenience functions to support development environments --
  -- There procedures allow PL/SQL to get at Java Schem Objects.
  -- There are a lot of them, but they can be understood from the
  -- grammar
  --     export_<what>(name, [schema,] lob)
  --
  -- <what> is either source, class or resource
  -- name a varchar argument that is the name of the java schema object
  -- schema is an optional argument, if it is present it is a varchar that
  --   names a schema, if it ommitted the current schema is used
  -- lob is either a BLOB or CLOB.  The contents of the object are placed
  --   into it. CLOB's are allowed only for source and resource (i.e. not
  --   for class). Note that the internal representation of source uses
  --   UTF8 and that is what is stored into the BLOB
  --
  -- If the java schema object does not exist an ORA-29532 (Uncaught Java
  -- exception) will occur.


  procedure export_source(name varchar2, schema varchar2, src BLOB)
  as language java name
  'oracle.aurora.rdbms.ExportSchemaObjects.exportSource(java.lang.String, java.lang.String, oracle.sql.BLOB)';

  procedure export_source(name varchar2, src BLOB)
  as language java name
  'oracle.aurora.rdbms.ExportSchemaObjects.exportSource(java.lang.String, oracle.sql.BLOB)';

  procedure export_source(name varchar2, schema varchar2, src CLOB)
  as language java name
  'oracle.aurora.rdbms.ExportSchemaObjects.exportSource(java.lang.String, java.lang.String, oracle.sql.CLOB)';

  procedure export_source(name varchar2, src CLOB)
  as language java name
  'oracle.aurora.rdbms.ExportSchemaObjects.exportSource(java.lang.String, oracle.sql.CLOB)';

  procedure export_class(name varchar2, schema varchar2, clz BLOB)
  as language java name
  'oracle.aurora.rdbms.ExportSchemaObjects.exportClass(java.lang.String, java.lang.String, oracle.sql.BLOB)';

  procedure export_class(name varchar2, clz BLOB)
  as language java name
  'oracle.aurora.rdbms.ExportSchemaObjects.exportClass(java.lang.String, oracle.sql.BLOB)';

  procedure export_resource(name varchar2, schema varchar2, res BLOB)
  as language java name
  'oracle.aurora.rdbms.ExportSchemaObjects.exportResource(java.lang.String, java.lang.String, oracle.sql.BLOB)';

  procedure export_resource(name varchar2, res BLOB)
  as language java name
  'oracle.aurora.rdbms.ExportSchemaObjects.exportResource(java.lang.String, oracle.sql.BLOB)';

  procedure export_resource(name varchar2, schema varchar2, res CLOB)
  as language java name
  'oracle.aurora.rdbms.ExportSchemaObjects.exportResource(java.lang.String, java.lang.String, oracle.sql.CLOB)';

  procedure export_resource(name varchar2, res CLOB)
  as language java name
  'oracle.aurora.rdbms.ExportSchemaObjects.exportResource(java.lang.String, oracle.sql.CLOB)';

  procedure loadjava(options varchar2)
  as language java name
  'oracle.aurora.server.tools.loadjava.LoadJavaMain.serverMain(java.lang.String)';

  procedure loadjava(options varchar2, resolver varchar2)
  as language java name
  'oracle.aurora.server.tools.loadjava.LoadJavaMain.serverMain(java.lang.String, java.lang.String)';

  procedure loadjava(options varchar2, resolver varchar2, status OUT number)
  as language java name
  'oracle.aurora.server.tools.loadjava.LoadJavaMain.serverMain(java.lang.String, java.lang.String, int[])';

  procedure dropjava(options varchar2)
  as language java name
  'oracle.aurora.server.tools.loadjava.DropJavaMain.serverMain(java.lang.String)';


  -- Interface to manage Security Policy Table ----------------
  --
  -- Part A: routines populating security table.
  --
  -- All routines in this section add a new row. Use routines from
  -- Part B to reuse existing rows.
  -- Returned 'key' is set to the key of the created row or to -1 if an
  --    error occurs.

  -- PROCEDURE grant_permission: adds a new policy table row
  -- granting the permission as determined by the parameters.
  --
  -- Parameter descriptions:
  --
  --  grantee            is the name of a schema or role
  --  permission_type    is the fully qualified name of a class that extends
  --                     java.lang.security.Permission
  --  permission_name    is the name of the Permission
  --  permission_action  is the action of the Permission
  --  key                is the key of the newly inserted row
  --                     that grants the Permission.
  --                     This value is -1, if an error occurs.
  procedure grant_permission(
        grantee varchar2, permission_type varchar2,
        permission_name varchar2, permission_action varchar2,
        key OUT number)
  as language java name
  'oracle.aurora.rdbms.security.PolicyTableManager.grant(
       java.lang.String, java.lang.String, java.lang.String,
       java.lang.String, long[])';

  -- procedure restrict_permission: adds a new policy table row
  -- restricting the permission as determined by the parameters.
  -- similar to grant except create a restricting row.
  --
  -- Parameter descriptions:
  --
  --  grantee            is the name of a schema or role
  --  permission_type    is the fully qualified name of a class that extends
  --                     java.lang.security.Permission
  --  permission_name    is the name of the Permission
  --  permission_action  is the action of the Permission
  --  key                is the key of the newly inserted row
  --                     that grants the Permission.
  --                     This value is -1, if an error occurs.
  procedure restrict_permission(
        grantee varchar2, permission_type varchar2,
        permission_name varchar2, permission_action varchar2,
        key OUT number)
  as language java name
  'oracle.aurora.rdbms.security.PolicyTableManager.restrict(
       java.lang.String, java.lang.String, java.lang.String,
       java.lang.String, long[])';

  -- grant_policy_permission: special case for granting PolicyTablePermissions.
  --
  -- The name of a PolicyTablePermission allows updates of rows relating to
  -- a particular type (i.e. class that extends Permission) to
  -- specify the class you must specify the schema containing the
  -- class. In the table that is stored as the user number, but this
  -- procedure lets it be specified via a name.
  --
  --  Parameter descriptions:
  --  grantee           is the name of a schema or role
  --  permission_schema is the schema of the permission
  --  permission_type   is the fully qualified name
  --                    of a class that extends java.lang.security.Permission
  --  permission_name   is the name of the Permission which can be a glob '*'
  --  key               is the key of the newly inserted row
  --                    that grants the Permission.
  --                    This value is -1, if an error occurs.
  procedure grant_policy_permission(
        grantee varchar2,
        permission_schema varchar2, permission_type varchar2,
        permission_name varchar2,
        key OUT number)
  as language java name
  'oracle.aurora.rdbms.security.PolicyTableManager.grantPolicyPermission(
       java.lang.String, java.lang.String, java.lang.String,
       java.lang.String, long[])';

  -- Part B: high-level management.
  --
  -- The following versions of grant_permission, restrict_permission
  -- and grant_policy permission do not have the key OUT parameter,
  -- These routines attempt to reuse existing rows in the policy table
  -- that is, do not create a new row if a matching row exists.

  -- grant_permission: create an active row in the policy table granting the Permission
  -- as specified to grantee.  If a row already exists granting the
  -- exact Permission specified then the table is unmodifed.
  -- If a row exists but is disabled then it is enabled.
  -- Finally if no row exists one is inserted.
  --
  -- grantee is the name of a schema
  -- permission_type is the fully qualified name of a class that
  --    extends java.lang.security.Permission.  If the class does
  --    not have a public synonymn then the name should be prefixed
  --    by <schema>:.  For example 'myschema:scott.MyPermission'.
  -- permission_name is the name of the permission
  -- permission_action is the action of the permission
  procedure grant_permission(
        grantee varchar2, permission_type varchar2,
        permission_name varchar2, permission_action varchar2)
  as language java name
  'oracle.aurora.rdbms.security.PolicyTableManager.grant(
       java.lang.String, java.lang.String, java.lang.String,
       java.lang.String)';

  -- restrict_permission: similar to the above except the row is
  -- restricted.
  procedure restrict_permission(
        grantee varchar2, permission_type varchar2,
        permission_name varchar2, permission_action varchar2)
  as language java name
  'oracle.aurora.rdbms.security.PolicyTableManager.restrict(
       java.lang.String, java.lang.String, java.lang.String,
       java.lang.String)';

  -- grant_policy_permission: similar to grant_policy_permission with an
  -- OUT key parameter except avoids creating a new row if a matching row exists.
  procedure grant_policy_permission(
        grantee varchar2,
        permission_schema varchar2, permission_type varchar2,
        permission_name varchar2)
  as language java name
  'oracle.aurora.rdbms.security.PolicyTableManager.grantPolicyPermission(
       java.lang.String, java.lang.String, java.lang.String,
       java.lang.String)';

  -- revoke disables any permissions that might have been granted
  procedure revoke_permission(
        grantee varchar2, permission_type varchar2,
        permission_name varchar2, permission_action varchar2)
  as language java name
  'oracle.aurora.rdbms.security.PolicyTableManager.revoke(
       java.lang.String, java.lang.String, java.lang.String,
       java.lang.String)';

  -- Part C: management using keys.
  -- As a rule, these routines do nothing if key does not identify
  -- a row.

  -- enable_permission: enable the existing row with specified key.
  -- There is no error reported if the key does not identify a row.
  -- enable_permission checks user permissions for policy table access and
  -- may throw a SecurityException.
  procedure enable_permission(key number)
  as language java name
  'oracle.aurora.rdbms.security.PolicyTableManager.enable(long)';

  -- disable_permission: disable the existing row with specified key.
  -- The row remain in the table as INACTIVE row.
  -- There is no error reported if the key does not identify a row.
  -- disable_permission checks user permissions for policy table access and
  -- may throw a SecurityException.
  procedure disable_permission(key number)
  as language java name
  'oracle.aurora.rdbms.security.PolicyTableManager.disable(long)';

  -- delete_permission removes an existing row with specified key
  -- from the policy table.
  -- To be removed, the row must be disabled first, see procedure 'disable_permission'.
  -- If the row is still active  or if 'key' matches nothing,
  -- delete_permission currently issues no errors or assertions and does nothing.
  procedure delete_permission(key number)
  as language java name
  'oracle.aurora.rdbms.security.PolicyTableManager.delete(long)';


  -- set debugging level
  procedure set_permission_debug(level number)
  as language java name
  'oracle.aurora.rdbms.security.PolicyTableManager.setDebugLevel(int)';

  -- turn byte code verifier on or off for current session
  -- 0 is off, 1 is on
  -- you need JServerPermission("Verifier") to do this operation
  procedure set_verifier(flag number)
  as language java name
  'oracle.aurora.rdbms.Compiler.sessionOptionController(int)';

  function option_controller(opt number, action number) return number
  as language java name
  'oracle.aurora.rdbms.Compiler.optionController(int, int) return boolean';

  -- turn system class loading on or off for current session
  -- 0 is off, 1 is on
  -- you need to be running as SYS to do this operation
  procedure set_system_class_loading(flag number);

  -- reset instance duration flag for existence of the system property
  -- definition table java$jvm$system$property$defs
  -- if the table is created while the instance is up this procedure
  -- must be called to allow the table to be used.  The table will be
  -- used in any case after instance restart if the table exists at
  -- that time
  -- you need to be running as SYS to do this operation
  procedure reset_property_defs_table_flag;

  -- start_jmx_agent: Start an agent activating OJVM JMX server and remote listener.
  -- The JMX server starts as a collection of daemon threads in the current session.
  -- The session is expected to run with JMXSERVER role or a superset, otherwise
  -- JMX-related security exceptions will be raised.
  -- Arguments:
  -- port   the port for the JMX listener,
  --        the value for the property com.sun.management.jmxremote.port
  -- ssl    the value for the property com.sun.management.jmxremote.ssl
  -- auth   the value for the property com.sun.management.jmxremote.authenticate
  -- Each argument can be null or omitted, with null as default.
  -- When an argument is null, the corresponding property is not altered,
  -- holding the value, if any, previously present in the session.
  -- These three and other JMX-related properties can be configured in a session prior
  -- to a call to start_jmx_agent by means of dbms_java.set_property.
  -- Examples:
  --   start_jmx_agent('9999', 'false', 'false')
  --      start JMX server and listener on port 9999 with no SSL and no authentication
  --   start_jmx_agent('9999')
  --      start JMX server and listener on port 9999 with the other JMX settings
  --      having the default values or the values set using dbms_java.set_property
  --      earlier in the same session
  --   start_jmx_agent
  --      start JMX server and listener with the JMX settings
  --      having the default values or the values set using dbms_java.set_property
  --      earlier in the same session
  procedure start_jmx_agent(port VARCHAR2 default NULL,
                            ssl  VARCHAR2 default NULL,
                            auth VARCHAR2 default NULL);

  -- Send command chunks to shell
  procedure send_command (chunk long raw);

  -- Get reply chunks  from shell
  function get_reply return long raw;

  -- add a preference to the database
  -- user     user schema name
  -- type     U for user or S for system
  -- abspath  absolute path of the preference
  -- key      key for value lookup
  -- value    value to be stored (string)
  procedure set_preference(user varchar2,type varchar2, abspath varchar2,
                           key varchar2, value varchar2);

  function ncomp_status_msg return VARCHAR2 as language java name
  'oracle.aurora.rdbms.DbmsJava.ncompEnabledMsg() return java.lang.String';

  function full_ncomp_enabled return VARCHAR2;

  function get_ojvm_property(propstring VARCHAR2) return VARCHAR2 as language
  java name 'java.lang.System.getProperty(java.lang.String)
  return java.lang.String';

  function getVersion return VARCHAR2;

  procedure dbms_feature_ojvm(ojvm_boolean    OUT NUMBER,
                              aux_count       OUT NUMBER,
                              ojvm_info       OUT CLOB);

  procedure dbms_feature_system_ojvm(ojvm_boolean    OUT NUMBER,
                                     aux_count       OUT NUMBER,
                                     ojvm_info       OUT CLOB);

  -- Associate the database user/schema name 'dbuser' with the OS
  -- account identified by credential pair 'osuser'/'ospass'. This association is
  -- encrypted and stored in a SYS-owned table. Once the association is
  -- established, a new Operating System process forked by
  -- java.lang.Runtime.exec() will be setuid osuser.
  --
  -- Parameter descriptions:
  --
  --     dbuser is the name of a database user (schema name)
  --
  --     osuser, ospass are OS account credentials
  --
  -- Examples of use:
  --
  --   Bind user/schema  DBUSER to credentials osuser/ospass:
  --
  --     dbms_java.set_runtime_exec_credentials('DBUSER', 'osuser', 'ospass');
  --
  --   Unbind DBUSER's association with credentials osuser/ospass:
  --
  --     dbms_java.set_runtime_exec_credentials('DBUSER', '', '');
  --
  --   or
  --
  --     dbms_java.set_runtime_exec_credentials('DBUSER', null, null);
  --
  --
  procedure set_runtime_exec_credentials(dbuser varchar2,
                                         osuser varchar2,
                                         ospass varchar2);
  -- Associate all database users with the OS account identified by
  -- credential pair 'osuser'/'ospass'. This association is
  -- in effect for any user that does not have credentials set with
  -- set_runtime_exec_credentials(varchar2, varchar2, varchar2).
  --
  -- Parameter descriptions:
  --
  --     osuser, ospass are OS account credentials
  --
  procedure set_runtime_exec_credentials(osuser varchar2,
                                         ospass varchar2);

  function get_jdk_version return VARCHAR2;

end dbms_java;
/

