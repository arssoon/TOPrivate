create type dm_nested_binary_double
                                       as object
  (attribute_name        varchar2(4000)
  ,value                 binary_double)
/

