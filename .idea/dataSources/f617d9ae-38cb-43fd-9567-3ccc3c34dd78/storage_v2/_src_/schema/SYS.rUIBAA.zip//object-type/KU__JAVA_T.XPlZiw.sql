create TYPE     ku$_java_t FORCE AS OBJECT
(
  type_num              number,
  flags                 number,
  properties            number,
  raw_chunk_count       number,
  total_raw_byte_count  number,
  text_chunk_count      number,
  total_text_byte_count number,
  raw_chunk             sys.ku$_chunk_list_t,
  text_chunk            sys.ku$_chunk_list_t
)
NOT PERSISTABLE
/

