create package dbms_objects_utils authid current_user is
procedure upgrade_dict_image;

procedure delete_orphan_typeidcols;

procedure fix_kottd_images;

function persistable_downgrade_check return number;

end;
/

