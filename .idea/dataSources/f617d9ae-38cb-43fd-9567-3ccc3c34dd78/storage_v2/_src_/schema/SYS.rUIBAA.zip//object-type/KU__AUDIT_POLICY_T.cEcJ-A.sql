create type ku$_audit_policy_t force as object (
  policy_num    number,
  schema_obj    ku$_schemaobj_t,                            /* policy object */
  type          number,            /*     0 - Invalid
                                    *  0x01 - System Privilgege options
                                    *  0x02 - System Action options
                                    *  0x04 - Object Action options
                                    *  0x08 - Local Audit Policy in case of
                                    *         Consolidated Database
                                    *  0x10 - Common Audit Policy in case of
                                    *         Consolidated Database
                                    *  0x20 - Role Privilege options
                                    */
  condition         varchar2(4000),
  condition_eval    number,
  privilege_options  ku$_audit_sys_priv_list_t,
  sys_action_options ku$_audit_act_list_t,
  xs_action_options  ku$_audit_act_list_t,
  ols_action_options ku$_audit_act_list_t,
  obj_action_options ku$_auditp_obj_list_t,
  role_options       ku$_audit_pol_role_list_t
  )
not persistable
/

