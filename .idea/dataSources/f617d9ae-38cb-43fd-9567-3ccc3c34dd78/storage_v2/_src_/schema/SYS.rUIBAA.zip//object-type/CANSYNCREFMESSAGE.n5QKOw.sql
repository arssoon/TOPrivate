create TYPE CanSyncRefMessage FORCE IS OBJECT (
          schema_name        VARCHAR2(128),
          table_name         VARCHAR2(128),
          mv_schema_name     VARCHAR2(128),
          mv_name            VARCHAR2(128),
          eligible           VARCHAR2(1),
          seq_num            NUMBER,
          msg_number         NUMBER,
          message            VARCHAR2(4000));
/

