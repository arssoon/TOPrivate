create function dbms_pdb_is_valid_path (path_name varchar2)
  return boolean authid current_user is
begin
  return dbms_pdb.is_valid_path(path_name);
end;
/

