create function dictionary_obj_owner return varchar2 is
begin
return dbms_standard.dictionary_obj_owner;
end;
/

