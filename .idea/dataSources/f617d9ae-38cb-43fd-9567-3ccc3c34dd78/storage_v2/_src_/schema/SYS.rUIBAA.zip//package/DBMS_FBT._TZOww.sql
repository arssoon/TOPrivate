create PACKAGE dbms_fbt AUTHID CURRENT_USER IS

  -- PUBLIC TYPES

  TYPE TMPTBCURTYPE IS REF CURSOR;

  -- PUBLIC PROCEDURES AND FUNCTIONS

  PROCEDURE fbt_analyze(table_name         IN  VARCHAR2,
                        flashback_scn      IN  NUMBER,
                        tmptbcur           OUT TMPTBCURTYPE);
  PROCEDURE fbt_analyze(table_name         IN  VARCHAR2,
                        flashback_time     IN  TIMESTAMP,
                        tmptbcur           OUT TMPTBCURTYPE);
  PROCEDURE fbt_execute(table_names        IN  FLASHBACKTBLIST,
                        flashback_scn      IN  NUMBER);
  PROCEDURE fbt_execute(table_names        IN  FLASHBACKTBLIST,
                        flashback_time     IN  TIMESTAMP);
  PROCEDURE fbt_discard;

END;
/

