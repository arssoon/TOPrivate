create type ku$_callout_t force as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  user_name     varchar2(128),                                  /* user name */
  obj_num       number,                                     /* object number */
  base_obj      ku$_schemaobj_t,                            /* schema object */
  tag           varchar2(128),             /* used for extensibility tracing */
  package       varchar2(128),                         /* procedural package */
  pkg_schema    varchar2(128),                             /* package schema */
  level_num     number,                                             /* level */
  class         number,                                             /* class */
  prepost       number,                         /* 0:preaction, 1:postaction */
  -- for dbms_plugts
  ts_name       varchar2(128),                            /* tablespace name */
  ts_num        number,                                 /* tablespace number */
  incl_const    number,
  incl_trig     number,
  incl_grant    number,
  tts_full_chk  number,
  tts_closure_chk number,
  idx_prop      number               /* index properties - for plugts_tsname */
)
not persistable
/

