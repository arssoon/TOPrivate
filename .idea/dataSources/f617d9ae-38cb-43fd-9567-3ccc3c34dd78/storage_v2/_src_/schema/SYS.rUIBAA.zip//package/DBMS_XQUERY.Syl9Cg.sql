create package dbms_xquery authid current_user is

  FUNCTION eval(xqry varchar2) return xmltype;

end;
/

