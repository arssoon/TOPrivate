create type ku$_defrole_item_t force as object
(
  user_id       number,                                          /* user id  */
  user_name     varchar2(128),                                  /* user name */
  role          varchar2(128),                           /* role source name */
  role_id       number                                            /* role id */
)
not persistable
/

