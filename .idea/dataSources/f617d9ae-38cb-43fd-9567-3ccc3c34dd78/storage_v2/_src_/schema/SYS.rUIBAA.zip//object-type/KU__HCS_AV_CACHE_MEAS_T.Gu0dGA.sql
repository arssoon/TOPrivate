create type ku$_hcs_av_cache_meas_t force as object
(
  av_obj#         number,                       /* obj# of the analytic view */
  measlst#        number,                                   /* id of measlst */
  meas_name       varchar2(128),                      /* name of the measure */
  order_num       number                      /* order number of the measure */
)
not persistable
/

