create type AWRRPT_TEXT_TYPE
  as object (output varchar2(80 CHAR))
/

