create function JSON_HIERDATAGUIDE(input AnyData)
return CLOB aggregate using JsonHDgImp;
/

