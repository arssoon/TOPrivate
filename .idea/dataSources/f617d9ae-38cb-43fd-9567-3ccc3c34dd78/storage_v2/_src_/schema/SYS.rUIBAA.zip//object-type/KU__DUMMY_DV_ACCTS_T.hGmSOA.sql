create type ku$_dummy_dv_accts_t force as object
(
  vers_major               char(1),                  /* UDT major version # */
  vers_minor               char(1),                  /* UDT minor version # */
  state                    varchar2(128)                           /* state */
)
not persistable
/

