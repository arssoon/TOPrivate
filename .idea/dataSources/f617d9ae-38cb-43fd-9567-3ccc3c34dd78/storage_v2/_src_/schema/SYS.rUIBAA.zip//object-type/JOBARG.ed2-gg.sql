create TYPE JOBARG FORCE AS OBJECT
(
  arg_position          NUMBER,
  arg_text_value        VARCHAR2(4000),
  arg_anydata_value     SYS.ANYDATA,
  arg_operation         VARCHAR2(5),
  -- Set text argument
  CONSTRUCTOR FUNCTION jobarg
  (
    arg_position        IN     POSITIVEN,
    arg_value           IN     VARCHAR2
  )
  RETURN SELF AS RESULT,
  -- Set anydata argument
  CONSTRUCTOR FUNCTION jobarg
  (
    arg_position        IN     POSITIVEN,
    arg_value           IN     SYS.ANYDATA
  )
  RETURN SELF AS RESULT,
  -- If arg_reset is TRUE then the argument at that position is reset,
  -- otherwise it is set to a NULL value.
  CONSTRUCTOR FUNCTION jobarg
  (
    arg_position        IN     POSITIVEN,
    arg_reset           IN     BOOLEAN DEFAULT FALSE
  )
  RETURN SELF AS RESULT
);
/

