create type ku$_fga_rel_col_t force as object
(
    audit_column varchar2(128)
)
not persistable
/

