create FUNCTION dbj_short_name (longname VARCHAR2)
  return VARCHAR2 as
begin
  return dbms_java.shortname(longname);
end dbj_short_name;
/

