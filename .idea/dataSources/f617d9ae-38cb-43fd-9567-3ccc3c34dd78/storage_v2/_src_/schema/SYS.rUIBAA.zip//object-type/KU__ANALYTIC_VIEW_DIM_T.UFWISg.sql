create type ku$_analytic_view_dim_t force as object
(
  av_obj#         number,                       /* obj# of the analytic view */
  dim_obj#        number,                            /* obj# of the hier dim */
  dim_owner       varchar2(128),         /* dim owner (hcs_av_dim$.dim_owner */
  owner_in_ddl    number(1),                     /* whether owner was in DDL */
  name            varchar2(128),          /* dim name (hcs_av_dim$.dim_name) */
  dim_alias       varchar2(128),            /* alias name (hcs_av_dim$.alias */
  ref_distinct    number(1),                      /* is references distinct? */
  key_list        ku$_analytic_view_keys_list_t,       /* analytic view keys */
  hier_list       ku$_analytic_view_hiers_list_t,                   /* hiers */
  clsfctn_list    ku$_hcs_clsfctn_list_t,                 /* classifications */
  order_num       number                          /* order number of the dim */
)
not persistable
/

