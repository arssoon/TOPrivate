create TYPE GenInterfaceStub wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
66 a2
cEETJgn/YqCD/c7h/6TiKsng3dEwg5n0dLhcuK7XTkfVoWLyDFncstE+Lgm4dCulv5vAMsuz
jwlp58CBgShSAqUd5ABz5nHWjuTmEJBx1vXdwkoicH94gBfqJIAP6gJ8xsoXKMbK77IL78eC
xy7RLvY5pr3S/Yw=
/

