create type ku$_attribute_dimension_t force as object
(
  obj_num            number,           /* object number of the attribute dim */
  schema_obj         ku$_schemaobj_t,                       /* schema object */
  dimension_type     varchar2(8),                          /* dimension type */
  all_member_name    clob,                                /* all member name */
  all_member_caption clob,                             /* all member caption */
  all_member_desc    clob,                         /* all member description */
  src_list           ku$_hcs_src_list_t,                  /* list of sources */
  attr_list          ku$_attr_dim_attr_list_t,        /* dimension attr list */
  lvl_list           ku$_attr_dim_lvl_list_t,        /* dimension level list */
  clsfctn_list       ku$_hcs_clsfctn_list_t,              /* classifications */
  join_path_list     ku$_attr_dim_join_path_list_t             /* join paths */
)
not persistable
/

