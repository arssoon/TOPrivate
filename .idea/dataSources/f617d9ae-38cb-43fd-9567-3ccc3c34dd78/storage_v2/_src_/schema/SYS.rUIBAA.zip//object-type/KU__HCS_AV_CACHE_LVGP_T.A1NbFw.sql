create type ku$_hcs_av_cache_lvgp_t force as object
(
  av_obj#         number,                       /* obj# of the analytic view */
  measlst#        number,                                   /* id of measlst */
  lvlgrp#         number,                                /* id of the lvlgrp */
  cache_type      varchar2(128),                               /* cache type */
  lvl_list        ku$_hcs_av_cache_lvl_list_t,                     /* levels */
  order_num       number                              /* order of the lvlgrp */
)
not persistable
/

