create type ku$_cube_dim_t force as object
(
  obj_num       number,                             /* Parent table object # */
  colname       varchar2(128),               /* Base data column (col$.name) */
  obj           varchar2(512),         /* Mapped AW object (aw_obj$.objname) */
  dimusing      varchar2(512),  /* USING rel for native dt (aw_obj$.objname) */
  gid           ku$_cube_fact_list_t,                                 /* GID */
  pgid          ku$_cube_fact_list_t,                          /* Parent GID */
  attrs         ku$_cube_fact_list_t,                          /* Attributes */
  levels        ku$_cube_fact_list_t,                              /* Levels */
  hiers         ku$_cube_hier_list_t,                         /* Hierarchies */
  flags         number                                              /* Flags */
)
not persistable
/

