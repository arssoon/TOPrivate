create type ku$_clstcol_t force as object
(
  obj_num       number,                            /* object number of table */
  tabobj_num    number,          /* object number of clustering column table */
  schema_obj    ku$_schemaobj_t,                  /* Clustering column table */
  position      number,           /* Position of column in clustering clause */
  groupid       number,                           /* Identifier of the Group */
  col_num       number,                          /* column number as created */
  intcol_num    number,                            /* internal column number */
  segcol_num    number,                          /* column number in segment */
  property      number,                     /* column properties (bit flags) */
  property2     number,                        /*    more column properties  */
  name          varchar2(128),                             /* name of column */
  type_num      number                                /* data type of column */
)
not persistable
/

