create type ku$_clst_zonemap_t force as object
(
  obj_num       number,                       /* object number of base table */
  zmowner       varchar2(128),                              /* zonemap owner */
  zmname        varchar2(128)                                /* zonemap name */
)
not persistable
/

