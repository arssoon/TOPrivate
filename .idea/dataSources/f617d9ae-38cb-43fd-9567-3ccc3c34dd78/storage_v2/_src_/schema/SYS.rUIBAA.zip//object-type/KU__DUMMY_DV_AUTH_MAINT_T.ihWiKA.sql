create type ku$_dummy_dv_auth_maint_t force as object
(
  vers_major               char(1),                  /* UDT major version # */
  vers_minor               char(1),                  /* UDT minor version # */
  grantee_name             varchar2(128)                    /* Grantee Name */
)
not persistable
/

