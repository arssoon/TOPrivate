create type ku$_java_source_t force as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  obj_num       number,                         /* java source object number */
  schema_obj    ku$_schemaobj_t,                /* java source schema object */
  long_name     varchar2(4000),                              /* synlong name */
  source_lines  ku$_source_list_t,                           /* source lines */
  java_resource sys.ku$_java_t                             /* export source  */
)
not persistable
/

