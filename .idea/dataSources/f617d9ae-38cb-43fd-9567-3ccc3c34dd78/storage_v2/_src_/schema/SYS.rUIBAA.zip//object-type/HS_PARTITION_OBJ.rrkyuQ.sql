create TYPE HS_PARTITION_OBJ authid current_user AS OBJECT
 (low_value number,
 high_value number,
 position  number);
/

