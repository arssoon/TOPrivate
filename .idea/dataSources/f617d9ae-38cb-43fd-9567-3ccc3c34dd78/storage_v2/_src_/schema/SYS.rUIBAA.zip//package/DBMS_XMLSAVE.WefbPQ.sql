create PACKAGE DBMS_XMLSAVE AUTHID CURRENT_USER AS

  SUBTYPE ctxType IS NUMBER;                                 /* context type */

  DEFAULT_ROWTAG      CONSTANT VARCHAR2(3) := 'ROW';               /* rowtag */
  DEFAULT_DATE_FORMAT CONSTANT VARCHAR2(21):= 'YYYY-MM-DD HH24:MI:SS';

  MATCH_CASE          CONSTANT NUMBER      := 0;               /* match case */
  IGNORE_CASE         CONSTANT NUMBER      := 1;             /* ignore case */


  -------------------- constructor/destructor functions ---------------------
  FUNCTION newContext(targetTable IN VARCHAR2) RETURN ctxType;
  PROCEDURE closeContext(ctxHdl IN ctxType);

  -------------------- parameters to the save (XMLtoDB) engine ----------------
  PROCEDURE setXSLT(ctxHdl IN ctxType,uri IN VARCHAR2,ref IN VARCHAR2 := null);
  PROCEDURE setXSLT(ctxHdl IN ctxType, stylesheet IN CLOB, ref IN VARCHAR2 := null);
  PROCEDURE setXSLTParam(ctxHdl IN ctxType,name IN VARCHAR2,value IN VARCHAR2);
  PROCEDURE removeXSLTParam(ctxHdl IN ctxType, name IN VARCHAR2);

  PROCEDURE setRowTag(ctxHdl IN ctxType, tag IN VARCHAR2);
  PROCEDURE setSQLToXMLNameEscaping(ctxHdl IN ctxType, flag IN BOOLEAN := true);
  PROCEDURE setPreserveWhitespace(ctxHdl IN ctxType, flag IN BOOLEAN := true);
  PROCEDURE setIgnoreCase(ctxHdl IN ctxType, flag IN NUMBER);

  PROCEDURE setDateFormat(ctxHdl IN ctxType, mask IN VARCHAR2);

  PROCEDURE setBatchSize(ctxHdl IN ctxType, batchSize IN NUMBER);
  PROCEDURE setCommitBatch(ctxHdl IN ctxType, batchSize IN NUMBER);

  -- set the columns to update. Relevant for insert and update routines..
  PROCEDURE setUpdateColumn(ctxHdl IN ctxType, colName IN VARCHAR2);
  PROCEDURE clearUpdateColumnList(ctxHdl IN ctxType);

  -- set the key column name to be used for updates and deletes.
  PROCEDURE setKeyColumn(ctxHdl IN ctxType, colName IN VARCHAR2);
  PROCEDURE clearKeyColumnList(ctxHdl IN ctxType);

  ------------------- save ----------------------------------------------------
  -- insertXML
  FUNCTION  insertXML(ctxHdl IN ctxType, xDoc IN VARCHAR2) RETURN NUMBER;
  FUNCTION  insertXML(ctxHdl IN ctxType, xDoc IN CLOB) RETURN NUMBER;
  -- updateXML
  FUNCTION  updateXML(ctxHdl IN ctxType, xDoc IN VARCHAR2) RETURN NUMBER;
  FUNCTION  updateXML(ctxHdl IN ctxType, xDoc IN CLOB) RETURN NUMBER;
  -- deleteXML
  FUNCTION  deleteXML(ctxHdl IN ctxType, xDoc IN VARCHAR2) RETURN NUMBER;
  FUNCTION  deleteXML(ctxHdl IN ctxType, xDoc IN CLOB) RETURN NUMBER;

  ------------------- misc ----------------------------------------------------
  PROCEDURE propagateOriginalException(ctxHdl IN ctxType, flag IN BOOLEAN);
  PROCEDURE getExceptionContent(ctxHdl IN ctxType, errNo OUT NUMBER, errMsg OUT VARCHAR2);
  PROCEDURE useDBDates(ctxHdl IN ctxType, flag IN BOOLEAN := true);

  -------private method declarations------------------------------------------
  -- we must do this as a bug workaround; otherwise we get ora-600 [kgmexchi11]
  PROCEDURE p_useDBDates(ctxHdl IN ctxType, flag IN NUMBER);
  PROCEDURE p_setXSLT(ctxHdl IN ctxType, uri IN VARCHAR2, ref IN VARCHAR2);
  PROCEDURE p_setXSLT(ctxHdl IN ctxType, stylesheet CLOB, ref IN VARCHAR2);
  PROCEDURE p_propagateOriginalException(ctxHdl IN ctxType, flag IN NUMBER);
  PROCEDURE p_setSQLToXMLNameEsc(ctxHdl IN ctxType, flag IN NUMBER);
  PROCEDURE p_setPreserveWhitespace(ctxHdl IN ctxType, flag IN NUMBER);

END dbms_xmlsave;
/

