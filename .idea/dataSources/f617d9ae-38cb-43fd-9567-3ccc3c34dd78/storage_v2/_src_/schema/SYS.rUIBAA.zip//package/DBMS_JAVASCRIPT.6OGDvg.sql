create package dbms_javascript authid current_user as
  procedure run(script_name varchar2);
end;
/

