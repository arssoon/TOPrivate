create TYPE JSON_Scalar_T AUTHID CURRENT_USER UNDER JSON_Element_T(
   dummy NUMBER,

   CONSTRUCTOR FUNCTION JSON_Scalar_T(self IN OUT JSON_SCALAR_T,
                                      jsn JDOM_T)  RETURN SELF AS RESULT,

   CONSTRUCTOR FUNCTION JSON_Scalar_T(self IN OUT JSON_SCALAR_T,
                                      e JSON_ELEMENT_T) RETURN SELF AS RESULT,

   MEMBER      FUNCTION  clone(self IN JSON_SCALAR_T) RETURN JSON_SCALAR_T

) FINAL
/

