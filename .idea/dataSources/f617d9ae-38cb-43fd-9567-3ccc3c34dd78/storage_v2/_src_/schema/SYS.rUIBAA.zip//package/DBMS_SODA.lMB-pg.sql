create PACKAGE     dbms_soda authid current_user
AS

    -- Content type constants
    DOC_VARCHAR2     CONSTANT PLS_INTEGER := 1;
    DOC_BLOB         CONSTANT PLS_INTEGER := 2;
    DOC_CLOB         CONSTANT PLS_INTEGER := 3;

    -- Collection create mode constants
    CREATE_MODE_DDL  CONSTANT PLS_INTEGER := 1;
    CREATE_MODE_MAP  CONSTANT PLS_INTEGER := 2;

    -- Functions
    FUNCTION create_Collection (collection_Name NVARCHAR2,
                                metadata        VARCHAR2 DEFAULT NULL,
                                create_mode     PLS_INTEGER DEFAULT CREATE_MODE_DDL)
    RETURN SODA_Collection_T;

    FUNCTION drop_Collection (collection_Name NVARCHAR2)
    RETURN NUMBER;

    FUNCTION list_Collection_Names
    RETURN SODA_CollName_List_T;

    FUNCTION open_Collection (collection_Name NVARCHAR2)
    RETURN SODA_Collection_T;

END dbms_soda;
/

