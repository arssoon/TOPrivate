create type ku$_clstjoin_t force as object
(
  obj_num       number,                                          /* object # */
  tab1obj_num   number,                                /* table 1 obj number */
  int1col_num   number,                /* internal column number for table 1 */
  tab2obj_num   number,                                /* table 2 obj number */
  int2col_num   number,                /* internal column number for table 2 */
  tab1          ku$_schemaobj_t,
  tab2          ku$_schemaobj_t,
  tab1col       ku$_simple_col_t,                          /* table 1 column */
  tab2col       ku$_simple_col_t                           /* table 2 column */
)
not persistable
/

