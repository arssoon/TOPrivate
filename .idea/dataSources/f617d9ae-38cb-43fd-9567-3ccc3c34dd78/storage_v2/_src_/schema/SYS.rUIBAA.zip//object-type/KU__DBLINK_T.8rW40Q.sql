create type ku$_dblink_t force as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  owner_name    varchar2(128),
  owner_num     number,
  name          varchar2(128),
  ctime         varchar2(19),
  host          varchar2(2000),
  userid        varchar2(128),
  password      varchar2(128),
  flag          number,
  authusr       varchar2(128),
  authpwd       varchar2(128),
  passwordx     raw(128),
  authpwdx      raw(128)
)
not persistable
/

