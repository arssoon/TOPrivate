create type ku$_constraint0_t force as object
(
  owner_num     number,                                      /* owner user # */
  name          varchar2(128),                            /* constraint name */
  con_num       number,                                 /* constraint number */
  obj_num       number,                  /* object number of base table/view */
  numcols       number,                   /* number of columns in constraint */
  contype       number,                                   /* constraint type */
                                              /* 5 = view with CHECK OPTION, */
               /* 7 - table check constraint associated with column NOT NULL */
                                  /* 11 - REF/ADT column with NOT NULL const */
  enabled       number,           /* is constraint enabled? NULL if disabled */
  intcols       number,              /* #  of internal columns in constraint */
  mtime         varchar2(19),               /* date this constraint was last
                                                            enabled-disabled */
  flags         number                                              /* flags */
                  /* 0x01 constraint is deferrable */
                  /* 0x02 constraint is deferred */
                  /* 0x04 constraint has been system validated */
                  /* 0x08 constraint name is system generated */
                  /* 0x10 (16) constraint is BAD, depends on current century */
                  /* 0x20 (32) optimizer should RELY on this constraint */
                  /* 0x40 (64) Log Group ALWAYS option */
                  /* 0x80 (128) (view related) constraint is invalid */
                  /* 0x100 (256) constraint depends on a view */
                  /* 0x200 (512) partitioning constraint on FK */
                  /* 0x400 (1024) partitioning constraint on PK/UK */
)
not persistable
/

