create type ku$_10_1_tab_stats_t force as object
(
  vers_major        char(1),                    -- UDT major version #
  vers_minor        char(1),                    -- UDT minor version #
  obj_num           number,                     -- object number for table
  base_obj          ku$_schemaobj_t,            -- table information
  tab_info          ku$_10_1_tab_ptab_stats_t,  -- table statistics
  ptab_info_list    ku$_10_1_ptab_stats_list_t  -- partitioned statistics
)
not persistable
/

