create type ku$_col_stats_t force as object
(
  obj_num           number,             -- table/partition/subpartition objnum
  intcol_num        number,             -- internal column number
  distcnt           number,             -- distinct count
  lowval            raw(32),            -- low value
  lowval_1000       raw(1000),          -- low value - raw 1000 (12g)
  hival             raw(32),            -- high value
  hival_1000        raw(1000),          -- high value - raw 1000 (12g)
  density           number,             -- density
  null_cnt          number,             -- null count
  avgcln            number,             -- average column length
  cflags            number,             -- flags
  eav               number,
  sample_size       number,
  minimum           number,
  maximum           number,
  spare1            number,             -- sample number of distinct values
  hist_gram_list    ku$_histgrm_list_t  -- histogram list
)
not persistable
/

