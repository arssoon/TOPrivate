create PACKAGE dbms_ruleadm_internal AUTHID CURRENT_USER AS

  -----------------
  -- constants

  KGLNRULS  CONSTANT BINARY_INTEGER := 23;
  KGLNRULE  CONSTANT BINARY_INTEGER := 36;
  KGLNREVC  CONSTANT BINARY_INTEGER := 38;

  PROCEDURE i_create_eval_ctx(
                evaluation_context_name IN varchar2,
                table_aliases           IN sys.re$table_alias_list := NULL,
                variable_types          IN sys.re$variable_type_list := NULL,
                evaluation_function     IN varchar2 := NULL,
                evaluation_context_comment IN varchar2 := NULL,
                eval_ctx_properties     IN number := NULL);

  PROCEDURE create_evaluation_context(
                evaluation_context_name IN varchar2,
                table_aliases           IN sys.re$table_alias_list := NULL,
                variable_types          IN sys.re$variable_type_list := NULL,
                evaluation_function     IN varchar2 := NULL,
                evaluation_context_comment IN varchar2 := NULL);
  PRAGMA SUPPLEMENTAL_LOG_DATA(CREATE_EVALUATION_CONTEXT, AUTO);

  PROCEDURE create_rule_set(
                rule_set_name           IN varchar2,
                evaluation_context      IN varchar2 := NULL,
                rule_set_comment        IN varchar2 := NULL,
                result_cache            IN boolean := FALSE);
  PRAGMA SUPPLEMENTAL_LOG_DATA(create_rule_set, AUTO);

  PROCEDURE i_create_rule_set(
		rule_set_name		IN varchar2,
                evaluation_context      IN varchar2 := NULL,
                rule_set_comment        IN varchar2 := NULL,
                rule_set_properties     IN number := NULL,
                result_cache            IN boolean := FALSE);

  PROCEDURE create_rule(
                rule_name               IN varchar2,
                condition               IN varchar2,
                evaluation_context      IN varchar2 := NULL,
                action_context          IN sys.re$nv_list := NULL,
                rule_comment            IN varchar2 := NULL);
  PRAGMA SUPPLEMENTAL_LOG_DATA(create_rule, AUTO);


  PROCEDURE i_create_rule(
		rule_name		IN varchar2,
		condition		IN varchar2,
                evaluation_context      IN varchar2 := NULL,
                action_context          IN sys.re$nv_list := NULL,
                rule_comment            IN varchar2 := NULL,
                rule_properties         IN number := NULL,
                internal_actx_client    IN varchar2 := NULL,
                internal_action_context IN sys.re$nv_list := NULL);

  PROCEDURE i_alter_rule(
                rule_name                 IN varchar2,
                condition                 IN varchar2 := NULL,
                evaluation_context        IN varchar2 := NULL,
                remove_evaluation_context IN boolean := FALSE,
                action_context            IN sys.re$nv_list := NULL,
                remove_action_context     IN boolean := FALSE,
                rule_comment              IN varchar2 := NULL,
                remove_rule_comment       IN boolean := FALSE,
                internal_actx_client      IN varchar2 := NULL,
                internal_action_context   IN sys.re$nv_list := NULL,
                remove_int_actx           IN boolean := FALSE);

  PROCEDURE patch_rule_priv(
                btab_schema             IN varchar2,
                btab_name               IN varchar2,
                condition               IN varchar2);

  PROCEDURE validate_re_object(
                object_name             IN varchar2,
                object_namespace        IN binary_integer);

-- The export function signature should be
-- FUNCTION  <export_function> (
--           rschema                   IN  varchar2,
--           rname                     IN  varchar2,
--           new_block                 OUT PLS_INTEGER) RETURN VARCHAR2;

  PROCEDURE register_internal_actx(
                client_name             IN varchar2,
                export_function         IN varchar2 default NULL,
              client_comment          IN varchar2 default NULL);

  PROCEDURE unregister_internal_actx(
              client_name             IN varchar2);

  PROCEDURE i_evaluation_context_add_var(
              evaluation_context_name IN varchar2,
              variable_types          IN sys.re$variable_type_list default NULL
            );
  PROCEDURE alter_evaluation_context(
              evaluation_context_name     IN varchar2,
              table_aliases               IN sys.re$table_alias_list := NULL,
              remove_table_aliases        IN boolean := FALSE,
              variable_types              IN sys.re$variable_type_list := NULL,
              remove_variable_types       IN boolean := FALSE,
              evaluation_function         IN varchar2 := NULL,
              remove_evaluation_function  IN boolean := FALSE,
              evaluation_context_comment  IN varchar2 := NULL,
              remove_eval_context_comment IN boolean := FALSE);
  PRAGMA SUPPLEMENTAL_LOG_DATA(alter_evaluation_context, AUTO);

  PROCEDURE drop_evaluation_context(
                evaluation_context_name IN varchar2,
                force                   IN boolean := FALSE);
  PRAGMA SUPPLEMENTAL_LOG_DATA(drop_evaluation_context, AUTO);

  PROCEDURE drop_rule_set(
                rule_set_name           IN varchar2,
                delete_rules            IN boolean := FALSE);
  PRAGMA SUPPLEMENTAL_LOG_DATA(drop_rule_set, AUTO);

  PROCEDURE alter_rule(
                rule_name                 IN varchar2,
                condition                 IN varchar2 := NULL,
                evaluation_context        IN varchar2 := NULL,
                remove_evaluation_context IN boolean := FALSE,
                action_context            IN sys.re$nv_list := NULL,
                remove_action_context     IN boolean := FALSE,
                rule_comment              IN varchar2 := NULL,
                remove_rule_comment       IN boolean := FALSE);
  PRAGMA SUPPLEMENTAL_LOG_DATA(alter_rule, AUTO);

  PROCEDURE drop_rule(
                rule_name               IN varchar2,
                force                   IN boolean := FALSE);
  PRAGMA SUPPLEMENTAL_LOG_DATA(drop_rule, AUTO);

  PROCEDURE add_rule(
                rule_name               IN varchar2,
                rule_set_name           IN varchar2,
                evaluation_context      IN varchar2 := NULL,
                rule_comment            IN varchar2 := NULL);
  PRAGMA SUPPLEMENTAL_LOG_DATA(add_rule, AUTO);

  PROCEDURE remove_rule(
                rule_name               IN varchar2,
                rule_set_name           IN varchar2,
                evaluation_context      IN varchar2 := NULL,
                all_evaluation_contexts IN boolean  := FALSE);
  PRAGMA SUPPLEMENTAL_LOG_DATA(remove_rule, AUTO);

END dbms_ruleadm_internal;
/

