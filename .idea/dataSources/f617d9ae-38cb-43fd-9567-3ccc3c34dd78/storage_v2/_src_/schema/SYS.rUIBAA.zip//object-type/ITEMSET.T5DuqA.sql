create TYPE itemset AS OBJECT(
       itemset_id NUMBER,
       support NUMBER,
       length NUMBER,
       total_tranx   NUMBER,
       item  SYS.AnyData);
/

