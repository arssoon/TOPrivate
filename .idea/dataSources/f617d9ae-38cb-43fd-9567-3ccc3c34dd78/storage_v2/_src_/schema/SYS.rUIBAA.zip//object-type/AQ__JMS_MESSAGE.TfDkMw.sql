create type aq$_jms_message
                                      
as object
(
  header        aq$_jms_header,
  senderid      varchar2(100),
  message_type  int,
  text_len      int,
  bytes_len     int,
  text_vc       varchar2(4000),
  bytes_raw     raw(2000),
  text_lob      clob,
  bytes_lob     blob,
  STATIC FUNCTION construct ( mtype IN int ) RETURN aq$_jms_message,

  --*******************************************
  -- Pseudo upcast to aq$_jms_messaeg
  --*******************************************

  STATIC FUNCTION construct( text_msg IN  aq$_jms_text_message)
  RETURN aq$_jms_message,

  STATIC FUNCTION construct( bytes_msg IN  aq$_jms_bytes_message)
  RETURN aq$_jms_message,

  STATIC FUNCTION construct( stream_msg IN  aq$_jms_stream_message)
  RETURN aq$_jms_message,

  STATIC FUNCTION construct( map_msg IN  aq$_jms_map_message)
  RETURN aq$_jms_message,

  STATIC FUNCTION construct( object_msg IN  aq$_jms_object_message)
  RETURN aq$_jms_message,

  -- cast an aq$_jms_message to an aq$_jms_text_message
  --
  -- Return aq$_jms_text_message or NULL if message_type attribute of the aq$_jms_message
  -- is not DBMS_AQ.JMS_TEXT_MESSAGE.

  MEMBER FUNCTION cast_to_text_msg RETURN aq$_jms_text_message,

  --
  -- cast an aq$_jms_message to an aq$_jms_bytes_message
  --
  -- Return aq$_jms_bytes_message or NULL if message_type attribute of the aq$_jms_message
  -- is not DBMS_AQ.JMS_BYTES_MESSAGE.

  MEMBER FUNCTION cast_to_bytes_msg RETURN aq$_jms_bytes_message,
--
  -- cast an aq$_jms_message to an aq$_jms_stream_message
  --
  -- Return aq$_jms_stream_message or NULL if message_type attribute of the aq$_jms_message
  -- is not DBMS_AQ.JMS_STREAM_MESSAGE.

  MEMBER FUNCTION cast_to_stream_msg RETURN aq$_jms_stream_message,

  --
  -- cast an aq$_jms_message to an aq$_jms_map_message
  --
  -- Return aq$_jms_map_message or NULL if message_type attribute of the aq$_jms_message
  -- is not DBMS_AQ.JMS_MAP_MESSAGE.
MEMBER FUNCTION cast_to_map_msg RETURN aq$_jms_map_message,

  --
  -- cast an aq$_jms_message to an aq$_jms_object_message
  --
  -- Return aq$_jms_object_message or NULL if message_type attribute of the aq$_jms_message
  -- is not DBMS_AQ.JMS_OBJECT_MESSAGE.

  MEMBER FUNCTION cast_to_object_msg RETURN aq$_jms_object_message,


  --
  -- set_text sets payload in varchar2 into text_vc if the length of
  -- payload is <= 4000, into text_lob if otherwise.
  --
  -- @param payload (IN)
  --
  MEMBER PROCEDURE set_text ( payload IN VARCHAR2 ),

  --
  -- set_text sets payload in clob in text_lob.
  --
  -- @param payload (IN)
  --
  MEMBER PROCEDURE set_text ( payload IN CLOB ),

  --
  -- get_text puts text_vc into payload if text_vc is not null,
  -- or transfers text_lob in clob into payload in varchar2 if the
  -- length of text_lob is =< 32767 (2**16 -1).
  -- Maximum length of varchar2 in PL/SQL is 32767.
  --
  -- @param payload (OUT)
  --
  -- @throws -24190 if the length of text_lob is > 32767.
  --
  MEMBER PROCEDURE get_text ( payload OUT VARCHAR2 ),

  --
  -- get_text puts text_lob into payload if text_lob is not null,
  -- or transfers text_vc in varchar2 into payload in clob.
--
  -- @param payload (OUT)
  --
  MEMBER PROCEDURE get_text ( payload OUT NOCOPY CLOB ),

  --
  -- set_bytes sets payload in RAW into bytes_raw if the length of
  -- payload is <= 2000, otherwise into bytes_lob.
  --
  -- @param payload (IN)
-- @param payload (IN)
  --
  MEMBER PROCEDURE set_bytes ( payload IN RAW ),

  --
  -- set_bytes sets payload in blob in bytes_lob.
  --
  -- @param payload (IN)
  --
  MEMBER PROCEDURE set_bytes ( payload IN BLOB ),

  --
  -- get_bytes puts bytes_raw into payload if it is not null,
  -- or transfers bytes_lob in blob into payload in RAW if the
  -- length of bytes_lob is =< 32767 (2**16 -1).
  -- Maximum length of raw in PL/SQL is 32767.
  --
  -- @param payload (OUT)
  --
  -- @throws -24190 if bytes_raw is null and
  -- the length of bytes_lob is > 32767.
  --
  MEMBER PROCEDURE get_bytes ( payload OUT RAW ),

  --
  -- get_bytes puts bytes_lob into payload if it is not null,
  -- or transfers bytes_raw in RAW into payload in blob.
  --
  -- @param payload (OUT)
  --
  MEMBER PROCEDURE get_bytes ( payload OUT NOCOPY BLOB ),


  MEMBER PROCEDURE set_replyto (replyto IN      sys.aq$_agent),

  MEMBER PROCEDURE set_type (type       IN      VARCHAR ),

  MEMBER PROCEDURE set_userid (userid   IN      VARCHAR ),

  MEMBER PROCEDURE set_appid (appid     IN      VARCHAR ),

  MEMBER PROCEDURE set_groupid (groupid IN      VARCHAR ),

  MEMBER PROCEDURE set_groupseq (groupseq       IN      int ),
  MEMBER PROCEDURE clear_properties ,

  MEMBER PROCEDURE set_boolean_property (
                property_name   IN      VARCHAR,
                property_value  IN      BOOLEAN ),
MEMBER PROCEDURE set_byte_property (
                property_name   IN      VARCHAR,
                property_value  IN      int ),

  MEMBER PROCEDURE set_short_property (
                property_name   IN      VARCHAR,
                property_value  IN      int ),

  MEMBER PROCEDURE set_int_property (
                property_name   IN      VARCHAR,
                property_value  IN      int ),

  MEMBER PROCEDURE set_long_property (
                property_name   IN      VARCHAR,
                property_value  IN      NUMBER ),

  MEMBER PROCEDURE set_float_property (
                property_name   IN      VARCHAR,
                property_value  IN      FLOAT ),

  MEMBER PROCEDURE set_double_property (
                property_name   IN      VARCHAR,
                property_value  IN      DOUBLE PRECISION ),

  MEMBER PROCEDURE set_string_property (
                property_name   IN      VARCHAR,
                property_value  IN      VARCHAR ),

  MEMBER FUNCTION get_replyto RETURN sys.aq$_agent,

  MEMBER FUNCTION get_type RETURN VARCHAR,

  MEMBER FUNCTION get_userid RETURN VARCHAR,

  MEMBER FUNCTION get_appid RETURN VARCHAR,

  MEMBER FUNCTION get_groupid RETURN VARCHAR,

  MEMBER FUNCTION get_groupseq RETURN int,

  MEMBER FUNCTION get_boolean_property ( property_name   IN      VARCHAR)
  RETURN   BOOLEAN,

  MEMBER FUNCTION get_byte_property ( property_name   IN      VARCHAR)
  RETURN   int,

  MEMBER FUNCTION get_short_property ( property_name   IN      VARCHAR)
RETURN   int,

  MEMBER FUNCTION get_int_property ( property_name   IN      VARCHAR)
  RETURN   int,
MEMBER FUNCTION get_long_property ( property_name   IN      VARCHAR)
  RETURN   NUMBER,

  MEMBER FUNCTION get_float_property ( property_name   IN      VARCHAR)
  RETURN   FLOAT,

  MEMBER FUNCTION get_double_property ( property_name   IN      VARCHAR)
  RETURN   DOUBLE PRECISION,

  MEMBER FUNCTION get_string_property ( property_name   IN      VARCHAR)
  RETURN   VARCHAR

);
/

