create package dbms_part authid current_user as

  procedure cleanup_gidx(schema_name_in varchar2 default null,
                         table_name_in  varchar2 default null,
                         parallel       varchar2 default '0',
                         options        varchar2 default 'CLEANUP_ORPHANS');

  procedure cleanup_gidx_job(parallel       varchar2 default '0',
                             options        varchar2 default 'CLEANUP_ORPHANS');

  procedure cleanup_online_op(
    schema_name    in varchar2 default null,
    table_name     in varchar2 default null,
    partition_name in varchar2 default null);

end dbms_part;
/

