create type ku$_cube_fact_t force as object
(
  obj_num  number,                                  /* Parent table object # */
  colname  varchar2(128),                     /* SQL column name (col$.name) */
  pcolname varchar2(128),              /* Parent SQL column name (col$.name) */
  ccolname varchar2(128),               /* COUNT SQL column name (col$.name) */
  obj      varchar2(512),              /* Mapped AW object (aw_obj$.objname) */
  qdr      varchar2(512),       /* QDRing dimension object (aw_obj$.objname) */
  qdrval   varchar2(100),                                     /* QDRed value */
  flags    number                                                   /* Flags */
)
not persistable
/

