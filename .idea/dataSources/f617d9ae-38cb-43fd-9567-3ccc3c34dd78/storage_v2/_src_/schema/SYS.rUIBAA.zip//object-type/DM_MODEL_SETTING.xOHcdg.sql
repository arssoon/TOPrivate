create type dm_model_setting
                                       as object
  (setting_name          varchar2(30)
  ,setting_value         varchar2(128))
 alter type dm_model_setting
 modify attribute setting_value varchar2(4000) cascade
/

