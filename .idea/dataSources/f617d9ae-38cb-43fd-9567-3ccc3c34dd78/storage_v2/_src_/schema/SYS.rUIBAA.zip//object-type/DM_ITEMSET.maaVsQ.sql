create type dm_itemset
                                       as object
  (itemset_id            integer
  ,items                 dm_items
  ,support               number
  ,number_of_items       number)
/

