create type dm_rule
                                       as object
  (rule_id               integer
  ,antecedent            dm_predicates
  ,consequent            dm_predicates
  ,rule_support          number
  ,rule_confidence       number
  ,rule_lift             number
  ,antecedent_support    number
  ,consequent_support    number
  ,number_of_items       integer)
/

