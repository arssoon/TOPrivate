create PACKAGE dbms_logstdby_context AS
  PROCEDURE set_context(name IN VARCHAR2, value IN VARCHAR2);
  PROCEDURE get_context(name IN VARCHAR2, value OUT VARCHAR2);
  PROCEDURE clear_context(name IN VARCHAR2);
  PROCEDURE clear_all_context;
END dbms_logstdby_context;
/

