create function av_cache_col (
  incol in varchar2, incolpos in number)
return varchar2
is
begin
  return incol;
end;
/

