create type ku$_cube_hier_t force as object
(
  obj_num  number,                                  /* Parent table object # */
  rel      varchar2(512),            /* Mapped AW relation (aw_obj$.objname) */
  qdr      varchar2(512),       /* QDRing dimension object (aw_obj$.objname) */
  qdrval   varchar2(100),                                     /* QDRed value */
  levels   ku$_cube_fact_list_t,                      /* Levels in hierarchy */
  inhier   ku$_cube_fact_list_t,                   /* Mapped AW IN Hierarchy */
  flags    number                                                   /* Flags */
)
not persistable
/

