create TYPE       "DDL_LCR_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","source_database_name" VARCHAR2(128 CHAR),"command_type" VARCHAR2(4000 CHAR),"current_schema" VARCHAR2(128 CHAR),"ddl_text" CLOB,"object_type" VARCHAR2(4000 CHAR),"object_owner" VARCHAR2(128 CHAR),"object_name" VARCHAR2(128 CHAR),"logon_user" VARCHAR2(128 CHAR),"base_table_owner" VARCHAR2(128 CHAR),"base_table_name" VARCHAR2(128 CHAR),"tag" RAW(2000),"transaction_id" VARCHAR2(4000 CHAR),"scn" NUMBER,"extra_attribute_values" "LCR_EXTRA_ATTRIBUTE_VALUES_T")FINAL INSTANTIABLE
/

