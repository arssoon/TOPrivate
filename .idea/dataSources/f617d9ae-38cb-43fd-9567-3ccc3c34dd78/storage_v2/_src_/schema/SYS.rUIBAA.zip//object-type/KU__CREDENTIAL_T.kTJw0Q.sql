create type ku$_credential_t force as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  obj_num       number,                          /* credential object number */
  schema_obj    ku$_schemaobj_t,                 /* credential schema object */
  password      varchar2(255),                                   /* password */
  domain        varchar2(128),                                     /* domain */
  flags         number
)
not persistable
/

