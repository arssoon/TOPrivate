create function KCISYS_CTXAGG(input AnyData) return BLOB
aggregate using CtxAggimp;
/

