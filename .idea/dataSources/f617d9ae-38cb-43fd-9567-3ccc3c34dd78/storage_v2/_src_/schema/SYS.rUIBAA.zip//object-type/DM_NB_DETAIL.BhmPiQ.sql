create type dm_nb_detail
                                       as object
  (target_attribute_name varchar2(30)
  ,target_attribute_str_value varchar2(4000)
  ,target_attribute_num_value number
  ,prior_probability     number
  ,conditionals          dm_conditionals)
 alter type dm_nb_detail
 modify attribute target_attribute_name varchar2(130) cascade
/

