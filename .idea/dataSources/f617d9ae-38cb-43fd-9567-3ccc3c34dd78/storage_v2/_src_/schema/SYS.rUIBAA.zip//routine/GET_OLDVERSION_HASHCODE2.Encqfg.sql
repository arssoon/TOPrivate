create FUNCTION get_oldversion_hashcode2
(toid raw, vsn pls_integer)
return raw is
LANGUAGE C
NAME "GET_OLDVSN_HASHCODE2"
LIBRARY UTL_OBJECTS_LIB
parameters(toid RAW, toid INDICATOR sb4, toid LENGTH sb4, vsn ub2,
vsn indicator sb2, return indicator sb2, return OCIRaw);
/

