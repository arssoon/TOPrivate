create TYPE dbms_lobutil_dedupset_t AS OBJECT
(
    ismem   VARCHAR(1),     -- is this lob a member of a dedup set? (Y/N)
    setid   RAW(10),        -- deduplication setid
    lobid   RAW(10),        -- this lobid
    nmem    NUMBER,         -- number of members in set
    fhash   RAW(80),        -- full hash of set
    phash   RAW(80)         -- prefix hash of set
);
/

