create type dbms_cube_util_ext_md_r
  as object (owner             dbms_id,
             dimension_name    dbms_id,
             hierarchy_name    dbms_id,
             default_member    varchar2(4000),
             depth_count       number,
             depth             number,
             depth_cardinality number)
/

