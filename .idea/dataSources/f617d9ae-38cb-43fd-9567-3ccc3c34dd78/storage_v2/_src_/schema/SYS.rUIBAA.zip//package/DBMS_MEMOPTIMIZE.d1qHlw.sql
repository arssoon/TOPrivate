create package dbms_memoptimize authid current_user as

/*
 *
 * Bugs 25368492 and 25367835: Define Exceptions
 *
 */
          schema_name_invalid         exception;
              pragma  exception_init(schema_name_invalid,
                                     -62135);

          table_name_invalid         exception;
              pragma  exception_init(table_name_invalid,
                                     -62136);



/*********************************************************************
 *                                                                   *
 *           START - APIs for fast lookup project                    *
 *                                                                   *
 ********************************************************************/


/*--------------------------POPULATE----------------------------------
 *
 * Procedure:
 *   DBMS_MEMOPTIMZE.POPULATE()
 *
 * Description:
 *   Used for populating the in-memory hash index with object's data
 *
 * Parameters:
 *   schema_name    --     Name of object owner of the object
 *   table_name     --     Name of table whose data is to be stored
 *                         into in-memory hash index.
 *   partition_name --     Name of the table partition. If not NULL,
 *                         the data from this particular partition
 *                         will be stored in in-memory hash index.
 *
 *------------------------------------------------------------------*/


      PROCEDURE populate(
          schema_name       in      varchar2,
          table_name        in      varchar2,
          partition_name    in      varchar2 DEFAULT NULL
       );


/*--------------------------DROP_OBJECT-------------------------------
 *
 * Procedure:
 *   DBMS_MEMOPTIMZE.DROP_OBJECT()
 *
 * Description:
 *   Used for dropping an object (table, partition, subpartition) from
 *   in-memory hashindex.
 *
 * Parameters:
 *   schema_name    --     Name of object owner of the object
 *   table_name     --     Name of table whose data is to be stored
 *                         into in-memory hash index.
 *   partition_name --     Name of the table partition. If not NULL,
 *                         the data from this particular partition
 *                         will be stored in in-memory hash index.
 *
 *------------------------------------------------------------------*/


      PROCEDURE drop_object(
          schema_name       in      varchar2,
          table_name        in      varchar2,
          partition_name    in      varchar2 DEFAULT NULL
       );



/********************************************************************
 *                                                                  *
 *           END - APIs for fast lookup project                     *
 *                                                                  *
 *******************************************************************/






end dbms_memoptimize;
/

