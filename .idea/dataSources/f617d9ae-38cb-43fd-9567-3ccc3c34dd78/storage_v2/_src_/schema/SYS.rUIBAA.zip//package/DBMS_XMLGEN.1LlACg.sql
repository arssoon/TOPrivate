create PACKAGE dbms_xmlgen AUTHID CURRENT_USER AS

  -- context handle
  SUBTYPE ctxHandle IS NUMBER;
  SUBTYPE ctxType IS NUMBER;
  SUBTYPE conversionType IS NUMBER;

  TYPE PARAM_HASH IS TABLE OF VARCHAR2(100) INDEX BY VARCHAR2(32);

  -- DTD or schema specifications
  NONE CONSTANT NUMBER := 0;
  DTD CONSTANT NUMBER := 1;
  SCHEMA CONSTANT NUMBER := 2;

  -- conversion type
  ENTITY_ENCODE CONSTANT conversionType := 0;
  ENTITY_DECODE CONSTANT conversionType := 1;

  -- constants for null handling
  DROP_NULLS CONSTANT NUMBER := 0;
  NULL_ATTR  CONSTANT NUMBER := 1;
  EMPTY_TAG  CONSTANT NUMBER := 2;

  -- procedure to create the XML document
  FUNCTION newContext(queryString IN varchar2) RETURN ctxHandle;

  FUNCTION newContext(queryString IN SYS_REFCURSOR) RETURN ctxHandle;

  FUNCTION newContextFromHierarchy(queryString IN varchar2) RETURN ctxHandle;

  -- set the row tag name
  PROCEDURE setRowTag(ctx IN ctxHandle, rowTagName IN varchar2);

  -- set the rowset tag name
  PROCEDURE setRowSetTag(ctx IN ctxHandle, rowSetTagName IN varchar2);

  -- XSLT support
  PROCEDURE setXSLT(ctx IN ctxType, stylesheet IN CLOB);
  PROCEDURE setXSLT(ctx IN ctxType, stylesheet IN XMLType);
  PROCEDURE setXSLT(ctx IN ctxType, uri IN VARCHAR2);
  PROCEDURE setXSLTParam(ctx IN ctxType,name IN VARCHAR2,value IN VARCHAR2);
  PROCEDURE removeXSLTParam(ctx IN ctxType, name IN VARCHAR2);

  PROCEDURE getXML(ctx IN ctxHandle, tmpclob IN OUT NOCOPY clob,
                   dtdOrSchema IN number := NONE);

  FUNCTION getXML(ctx IN ctxHandle, dtdOrSchema IN number := NONE)
    RETURN clob;

  FUNCTION getXML(sqlQuery IN VARCHAR2, dtdOrSchema IN NUMBER := NONE)
    RETURN CLOB;

  PROCEDURE getXMLType(ctx IN ctxHandle, tmpxmltype IN OUT NOCOPY xmltype,
                   dtdOrSchema IN number := NONE);

  FUNCTION getXMLType(ctx IN ctxHandle, dtdOrSchema IN number:= NONE)
        RETURN sys.XMLType;

  FUNCTION getXMLType(sqlQuery IN VARCHAR2, dtdOrSchema IN NUMBER := NONE)
        RETURN sys.XMLType;

  -- returns the number of rows processed by the last call to getXML()
  FUNCTION getNumRowsProcessed(ctx IN ctxHandle) RETURN number;

  PROCEDURE setMaxRows(ctx IN ctxHandle, maxRows IN number);
  PROCEDURE setSkipRows(ctx IN ctxHandle, skipRows IN number);

  -- This procedure sets whether you want to replace characters such as
  -- <. > etc.. by their codes. (lt;, gt; etc..)
  PROCEDURE setConvertSpecialChars(ctx IN ctxHandle, replace IN boolean);

  -- This procedure sets whether you want to check for invalid characters
  -- such as the null character.
  PROCEDURE setCheckInvalidChars(ctx IN ctxHandle, chk IN boolean);

  -- This forces the use of the _ITEM for collectionitems. The default is to
  -- set the underlying object type name  for collection base elements.
  PROCEDURE useItemTagsForColl(ctx IN ctxHandle);

  -- reset the query to start fetching from the begining
  PROCEDURE restartQuery(ctx IN ctxHandle);

  PROCEDURE closeContext(ctx IN ctxHandle);

  -- conversion functions
  FUNCTION convert(xmlData IN varchar2, flag IN NUMBER := ENTITY_ENCODE)
           return varchar2;

  FUNCTION convert(xmlData IN CLOB, flag IN NUMBER := ENTITY_ENCODE)
           return CLOB;

  -- This procedure sets how you want nulls handled during generation
  PROCEDURE setNullHandling(ctx IN ctxHandle, flag IN NUMBER);

  PROCEDURE useNullAttributeIndicator(ctx IN ctxHandle,
                                      attrind IN boolean := TRUE);

  PROCEDURE setBindValue(ctx IN ctxHandle, bindName IN VARCHAR2,
    bindValue IN VARCHAR2);

  PROCEDURE clearBindValues(ctx IN ctxHandle);

  -- Procedures for setting pretty print settings
  PROCEDURE setPrettyPrinting(ctx IN ctxHandle, pp IN boolean);
  PROCEDURE setIndentationWidth(ctx IN ctxHandle, width IN NUMBER);

END dbms_xmlgen;
/

