create type dbms_xplan_type FORCE
  as object (plan_table_output varchar2(4000));
/

