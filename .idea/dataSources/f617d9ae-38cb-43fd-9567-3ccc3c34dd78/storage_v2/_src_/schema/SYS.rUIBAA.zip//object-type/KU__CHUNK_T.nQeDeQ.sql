create TYPE     ku$_chunk_t FORCE AS OBJECT
(
  text  varchar2(4000),
  length        number
)
NOT PERSISTABLE
/

