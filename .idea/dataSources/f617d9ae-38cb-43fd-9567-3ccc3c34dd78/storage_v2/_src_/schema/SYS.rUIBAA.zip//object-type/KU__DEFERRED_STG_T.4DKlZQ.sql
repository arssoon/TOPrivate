create type ku$_deferred_stg_t force as object
(
  obj_num       number,                            /* object number */
  pctfree_stg   number,                                  /* PCTFREE */
  pctused_stg   number,                                  /* PCTUSED */
  size_stg      number,                                     /* SIZE */
  initial_stg   number,                                  /* INITIAL */
  next_stg      number,                                     /* NEXT */
  minext_stg    number,                               /* MINEXTENTS */
  maxext_stg    number,                               /* MAXEXTENTS */
  maxsiz_stg    number,                                  /* MAXSIZE */
  lobret_stg    number,                             /* LOBRETENTION */
  mintim_stg    number,                                  /* MIN tim */
  pctinc_stg    number,                              /* PCTINCREASE */
  initra_stg    number,                                 /* INITRANS */
  maxtra_stg    number,                                 /* MAXTRANS */
  optimal_stg   number,                                  /* OPTIMAL */
  maxins_stg    number,                             /* MAXINSTANCES */
  frlins_stg    number,                           /* LISTS/instance */
  flags_stg     number,                                    /* flags */
  bfp_stg       number,                              /* BUFFER_POOL */
  enc_stg       number,                               /* encryption */
  cmpflag_stg   number,                         /* compression type */
  cmplvl_stg    number,                        /* compression level */
  imcflag_stg   number,            /* in-memory columnar (IMC) flag */
  ccflag_stg    number,                 /* columnar cache (CC) flag */
  flags2_stg    number                          /* additional flags */
)
not persistable
/

