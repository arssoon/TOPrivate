create type ku$_hier_hier_attr_t force as object
(
  hier_obj#      number,                                 /* obj# of the hier */
  name           varchar2(128), /* attr name (hcs_hier_attr$.hier_attr_name) */
  expr           clob,             /* expression (NULL for system-generated) */
  clsfctn_list   ku$_hcs_clsfctn_list_t,                  /* classifications */
  order_num      number                          /* order number of the attr */
)
not persistable
/

