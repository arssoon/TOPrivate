create type ku$_domidx_plsql_t force as object
(
  obj_num       number,                 /* object # */
  plsql         ku$_procobj_lines       /* plsql code */
)
not persistable
/

