create type ku$_hierarchy_t force as object
(
  obj_num         number,                       /* object number of the hier */
  schema_obj      ku$_schemaobj_t,                          /* schema object */
  dim_owner       varchar2(128),                          /* dimension owner */
  owner_in_ddl    number(1),                     /* whether owner was in DDL */
  dim_name        varchar2(128),                           /* dimension name */
  lvl_list        ku$_hier_lvl_list_t,           /* list of hierarchy levels */
  clsfctn_list    ku$_hcs_clsfctn_list_t,                 /* classifications */
  join_path_list  ku$_hier_join_path_list_t,                   /* join paths */
  hr_attr_list    ku$_hier_hier_attr_list_t   /* hier attr w/classifications */
)
not persistable
/

