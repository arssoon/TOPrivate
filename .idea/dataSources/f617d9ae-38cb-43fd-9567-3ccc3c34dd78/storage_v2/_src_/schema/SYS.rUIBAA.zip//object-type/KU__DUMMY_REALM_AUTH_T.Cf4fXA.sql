create type ku$_dummy_realm_auth_t force as object
(
  vers_major    char(1),                             /* UDT major version # */
  vers_minor    char(1),                             /* UDT minor version # */
  realm_name    varchar2(128)               /* name of database vault realm */
)
not persistable
/

