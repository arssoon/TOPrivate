create type ku$_hcs_src_col_t force as object
(
  obj#           number,          /* top lvl object id containing the srcCol */
  src_col#       number,                          /* id of the source column */
  obj_type       number,                /* object type containing the srcCol */
  table_alias    varchar2(128),/* owner of column (hcs_src_col$.table_alias) */
  src_col_name   varchar2(128) /* name of column (hcs_src_col$.src_col_name) */
)
not persistable
/

