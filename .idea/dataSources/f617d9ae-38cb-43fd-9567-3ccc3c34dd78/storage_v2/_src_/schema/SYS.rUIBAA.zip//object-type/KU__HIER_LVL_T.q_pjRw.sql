create type ku$_hier_lvl_t force as object
(
  hier_obj#      number,                                 /* obj# of the hier */
  name           varchar2(128),         /* level name (hcs_hr_lvl$.lvl_name) */
  order_num      number                         /* order number of the level */
)
not persistable
/

