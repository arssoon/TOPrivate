create type ku$_audit_act_t force as object (
        ACTION        number,
        NAME          varchar2(128)
  )
not persistable
/

