create type ku$_cube_tab_t force as object
(
  obj_num       number,                             /* Parent table object # */
  awname        varchar2(128),              /* Underlying AW name (aw$.name) */
  flags         number,                                             /* Flags */
  dims          ku$_cube_dim_list_t,                           /* Dimensions */
  facts         ku$_cube_fact_list_t,                            /* Measures */
  cgid          ku$_cube_fact_list_t                             /* Cube GID */
)
not persistable
/

