create type ku$_indexop_t force as object
(
  obj_num       number,                          /* obj# of parent indextype */
  oper_num      number,                 /* obj# of operator for this binding */
  bind_num      number,                            /* number of this binding */
  property      number,                                    /* property flags */
                                          /* 0x01 - INEXACT match use filter */
                        /* 0x02 -  invoke rewrite when indexed join is found */
                                    /* 0x04 - this is an "order-by" operator */
  oper_obj      ku$_schemaobj_t,             /* sch. info. for this operator */
  args          ku$_oparg_list_t           /* arguments for this op. binding */
)
not persistable
/

