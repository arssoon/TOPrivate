create type ku$_hcs_clsfctn_t force as object
(
  obj#            number, /* top lvl object id containing the classification */
  sub_obj#        number,    /*  sub object id containing the classification */
  obj_type        number,                                  /* type of object */
  clsfction_name  varchar2(128),  /* classification name (from hcs_clsfctn$) */
  clsfction_lang  varchar2(64),          /* optional classification language */
  clsfction_value clob,                              /* classification value */
  order_num       number                   /* order number of classification */
)
not persistable
/

