create type ku$_fga_policy_t force as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(1),                              /* UDT minor version # */
  obj_num       number,                              /* parent object number */
  name          varchar2(128),                             /* name of policy */
  ptxt          clob,                                    /* policy predicate */
  pfschema      varchar2(128),                    /* schema of event handler */
  ppname        varchar2(128),                         /* event package name */
  pfname        varchar2(128),                        /* event funciton name */
  pcol          ku$_fga_rel_col_list_t,              /* relevent column List */
  enable_flag   number,                         /* 0 = disabled, 1 = enabled */
  stmt_type     number,              /* statement type default is 1 = select */
  audit_trail   number,              /* audit trail 0 = DB_EXTENDED, 64 = DB */
  pcol_opt      number,           /* audit_column_options 0 = any, 128 = all */
  base_obj      ku$_schemaobj_t,                       /* base Schema object */
  powner        varchar2(128)                             /* owner of policy */
)
not persistable
/

