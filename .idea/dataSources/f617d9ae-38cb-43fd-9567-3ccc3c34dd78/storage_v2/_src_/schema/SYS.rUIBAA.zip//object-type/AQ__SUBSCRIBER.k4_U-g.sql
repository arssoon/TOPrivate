create TYPE     aq$_subscriber
AS OBJECT (
  name          VARCHAR2(30), -- M_IDEN, name of a message producer or consumer
  address       VARCHAR2(1024),           -- address where message must be sent
  protocol      NUMBER,                -- protocol for communication, must be 0
  trans_name    VARCHAR2(61),                             -- tranformation name
  sub_type      NUMBER,                                      -- subscriber type
  rule_name     VARCHAR2(30),                                       --rule name
  subscriber_id NUMBER,                                        -- subscriber id
  pos_bitmap    NUMBER          -- subscriber position in bitmap for 12c queues
 )
 alter type     aq$_subscriber modify attribute
           (name varchar2(512),
            trans_name varchar2(261),
            rule_name varchar2(128)) CASCADE
/

