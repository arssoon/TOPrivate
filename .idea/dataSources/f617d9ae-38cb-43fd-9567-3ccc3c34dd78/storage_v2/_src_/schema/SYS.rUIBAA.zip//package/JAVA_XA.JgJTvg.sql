create package JAVA_XA authid current_user as
-- create or replace package JAVA_XA as

   function xa_start (xid_bytes IN RAW, timeout IN NUMBER,
                      flag IN NUMBER, status OUT NUMBER)
   return RAW;

   function xa_start_new (formatId IN NUMBER, gtrid IN RAW, bqual  IN RAW,
                          timeout IN NUMBER, flag IN NUMBER)
   return number;

   function xa_end (xid_bytes IN RAW, flag IN NUMBER)
   return number;

   function xa_end_new (formatId IN NUMBER, gtrid IN RAW, bqual  IN RAW,
                        flag IN NUMBER)
   return number;

   function xa_commit (xid_bytes IN RAW, commit IN NUMBER, stateout OUT NUMBER)
   return number;

   function xa_commit_new (formatId IN NUMBER, gtrid IN RAW, bqual  IN RAW,
                           commit IN NUMBER)
   return number;

   function xa_rollback (xid_bytes IN RAW, stateout OUT NUMBER)
   return number;

   function xa_rollback_new (formatId IN NUMBER, gtrid IN RAW, bqual  IN RAW)
   return number;

   function xa_forget (xid_bytes IN RAW, stateout OUT NUMBER)
   return number;

   function xa_forget_new (formatId IN NUMBER, gtrid IN RAW, bqual  IN RAW)
   return number;

   function xa_prepare (xid_bytes IN RAW, stateout OUT NUMBER)
   return number;

   function xa_prepare_new (formatId IN NUMBER, gtrid IN RAW, bqual  IN RAW)
   return number;

   function xa_doTwophase (isFinal IN NUMBER, inBytes IN long RAW)
   return number;

   function xa_thinTwophase (inBytes IN long RAW)
   return number;

   pragma restrict_references(default, RNPS, WNPS, RNDS, WNDS, trust);

end;
/

