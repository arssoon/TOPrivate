create type ku$_attr_dim_join_path_t force as object
(
  dim_obj#       number,                             /* obj# of the hier dim */
  join_path_id   number,                     /* join path id in the hier dim */
  name           varchar2(128),  /* name (hcs_dim_join_path$.join_path_name) */
  on_condition   varchar2(4000),      /* condition of the hier dim join path */
  order_num      number                        /* order number of attributes */
)
not persistable
/

