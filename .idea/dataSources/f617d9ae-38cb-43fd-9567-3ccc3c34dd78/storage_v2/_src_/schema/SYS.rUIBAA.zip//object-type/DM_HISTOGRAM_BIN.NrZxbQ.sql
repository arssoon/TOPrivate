create type dm_histogram_bin
                                       as object
  (attribute_name        varchar2(4000)
  ,attribute_subname     varchar2(4000)
  ,bin_id                number
  ,lower_bound           number
  ,upper_bound           number
  ,label                 varchar2(4000)
  ,count                 number)
/

