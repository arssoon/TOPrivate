create type ku$_identity_col_t force as object
(
  vers_major    char(1),                              /* UDT major version # */
  vers_minor    char(2),                              /* UDT minor version # */
  obj_num       number,                           /* obj# of identity column */
  name          varchar(128),                     /* Name of Identity column */
  property2     number,                    /* identity column property flags */
  intcol_num    number,
  seqobj_num    number,
  start_with    number,
  sequence      ku$_sequence_t
)
not persistable
/

