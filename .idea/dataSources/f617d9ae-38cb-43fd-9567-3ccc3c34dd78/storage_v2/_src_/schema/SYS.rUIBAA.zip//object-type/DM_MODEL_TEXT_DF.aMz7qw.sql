create type DM_MODEL_TEXT_DF
                                       as object
  (attribute_name      varchar2(30)
  ,feature_name        varchar2(4000)
  ,frequency           number)
 alter type DM_MODEL_TEXT_DF
 modify attribute attribute_name varchar2(130) cascade
/

