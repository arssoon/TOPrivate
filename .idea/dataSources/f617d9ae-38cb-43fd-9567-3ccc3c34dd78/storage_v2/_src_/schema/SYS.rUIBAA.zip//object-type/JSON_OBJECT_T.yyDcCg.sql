create TYPE JSON_Object_T AUTHID CURRENT_USER UNDER JSON_Element_T(
   dummy NUMBER,
   CONSTRUCTOR FUNCTION JSON_Object_T(self IN OUT JSON_OBJECT_T)
                        RETURN SELF AS RESULT,
   CONSTRUCTOR FUNCTION JSON_Object_T(self IN OUT JSON_OBJECT_T, jsn JDOM_T)
                        RETURN SELF AS RESULT,
   CONSTRUCTOR FUNCTION JSON_Object_T(self IN OUT JSON_OBJECT_T, jsn VARCHAR2)
                        RETURN SELF AS RESULT,
   CONSTRUCTOR FUNCTION JSON_Object_T(self IN OUT JSON_OBJECT_T, jsn CLOB)
                        RETURN SELF AS RESULT,
   CONSTRUCTOR FUNCTION JSON_Object_T(self IN OUT JSON_OBJECT_T, jsn BLOB)
                        RETURN SELF AS RESULT,
   CONSTRUCTOR FUNCTION JSON_Object_T(self IN OUT JSON_OBJECT_T,
                                      e JSON_ELEMENT_T) RETURN SELF AS RESULT,

   -- override the 'parse' functions to directly RETURN Json_Object_T
   STATIC      FUNCTION  parse(jsn VARCHAR2) RETURN Json_Object_T,
   STATIC      FUNCTION  parse(jsn CLOB) RETURN Json_Object_T,
   STATIC      FUNCTION  parse(jsn BLOB) RETURN Json_Object_T,

   MEMBER      FUNCTION  clone RETURN JSON_OBJECT_T,

   MEMBER      FUNCTION  get(self IN JSON_OBJECT_T, key VARCHAR2)
                         RETURN JSON_Element_T,
   MEMBER      FUNCTION  get_Object(self IN JSON_OBJECT_T, key VARCHAR2)
                         RETURN JSON_OBJECT_T,
   MEMBER      FUNCTION  get_Array(self IN JSON_OBJECT_T, key VARCHAR2)
                         RETURN JSON_ARRAY_T,
   MEMBER      FUNCTION  get_String(self IN JSON_OBJECT_T, key VARCHAR2)
                         RETURN VARCHAR2,
   MEMBER      FUNCTION  get_Number(self IN JSON_OBJECT_T, key VARCHAR2)
                         RETURN NUMBER,
   MEMBER      FUNCTION  get_Boolean(self IN JSON_OBJECT_T, key VARCHAR2)
                         RETURN BOOLEAN,
   MEMBER      FUNCTION  get_Date(self IN JSON_OBJECT_T, key VARCHAR2)
                         RETURN DATE,
   MEMBER      FUNCTION  get_Timestamp(self IN JSON_OBJECT_T, key VARCHAR2)
                         RETURN TIMESTAMP,
   MEMBER      FUNCTION  get_Clob(self IN JSON_OBJECT_T, key VARCHAR2)
                         RETURN CLOB,
   MEMBER      PROCEDURE get_Clob(self IN OUT NOCOPY JSON_OBJECT_T,
                                  key VARCHAR2, c IN OUT NOCOPY CLOB),
   MEMBER      FUNCTION  get_Blob(self IN JSON_OBJECT_T, key VARCHAR2)
                         RETURN BLOB,
   MEMBER      PROCEDURE get_Blob(self IN OUT NOCOPY JSON_OBJECT_T,
                                 key VARCHAR2, b IN OUT NOCOPY BLOB),
   MEMBER      PROCEDURE put(self IN OUT NOCOPY JSON_OBJECT_T, key VARCHAR2,
                             val VARCHAR2),
   MEMBER      PROCEDURE put(self IN OUT NOCOPY JSON_OBJECT_T, key VARCHAR2,
                             val NUMBER),
   MEMBER      PROCEDURE put(self IN OUT NOCOPY JSON_OBJECT_T, key VARCHAR2,
                             val BOOLEAN),
   MEMBER      PROCEDURE put(self IN OUT NOCOPY JSON_OBJECT_T, key VARCHAR2,
                             val DATE),
   MEMBER      PROCEDURE put(self IN OUT NOCOPY JSON_OBJECT_T, key VARCHAR2,
                             val TIMESTAMP),
   --MEMBER      PROCEDURE put(key VARCHAR2, val CLOB),
   --MEMBER      PROCEDURE put(key VARCHAR2, val BLOB),
   MEMBER      PROCEDURE put(self IN OUT NOCOPY JSON_OBJECT_T, key VARCHAR2,
                             val JSON_Element_T),
   MEMBER      PROCEDURE put_Null(self IN OUT NOCOPY JSON_OBJECT_T,
                                 key VARCHAR2),
   MEMBER      FUNCTION  has(self IN JSON_OBJECT_T, key VARCHAR2)
                         RETURN BOOLEAN,
   MEMBER      PROCEDURE remove(self IN OUT NOCOPY JSON_OBJECT_T, key VARCHAR2),
   MEMBER      FUNCTION  get_Type(self IN JSON_OBJECT_T, key VARCHAR2)
                         RETURN VARCHAR2,
   MEMBER      FUNCTION  get_Keys(self IN JSON_OBJECT_T) RETURN JSON_KEY_LIST,
   MEMBER      PROCEDURE rename_Key(self IN OUT NOCOPY JSON_OBJECT_T,
                                   keyOld VARCHAR2, keyNew VARCHAR2)
) FINAL
/

