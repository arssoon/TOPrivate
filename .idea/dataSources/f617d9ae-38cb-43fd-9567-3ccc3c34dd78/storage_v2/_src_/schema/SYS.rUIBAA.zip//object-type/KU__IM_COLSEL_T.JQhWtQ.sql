create type ku$_im_colsel_t force as object
(
  obj_num       number,                                     /* object number */
  inst_id       number,                                      /* RAC instance */
  column_name   varchar2(129),                                /* Column name */
  compression   varchar2(26),  /* NO INMEMORY or inmemory memcompress clause */
  con_id        number                           /* multitenent container ID */
)
not persistable
/

