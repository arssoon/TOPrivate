create package dbms_inmemory authid current_user as

  ----------------------------
  --  PROCEDURES AND FUNCTIONS
  --

  -------------------------------------------------------------------------
  -- PROCEDURE repopulate
  -------------------------------------------------------------------------
  -- Description :
  --   Repopulate the in-memory representation of the specified
  --   table/partition if an in-memory representation exists.
  --
  -- Input parameters:
  --   schema_Name    - User owning the object
  --   table_name     - Name of the table whose in-memory representation
  --                    is to be repopulated.
  --   partition_name - If partition name is not null,
  --                    then repopulate the specified partition
  --   force          - Repopulate required with force(TRUE/FALSE).

  procedure repopulate(
        schema_name      in varchar2,
        table_name       in varchar2,
        partition_name   in varchar2 DEFAULT NULL,
        force            in boolean  DEFAULT FALSE);

  -------------------------------------------------------------------------
  -- PROCEDURE populate
  -------------------------------------------------------------------------
  -- Description :
  --   Populate the in-memory representation of the specified
  --   table/partition if an in-memory representation exists.
  --
  -- Input parameters:
  --   schema_Name    - User owning the object
  --   table_name     - Name of the table whose in-memory representation
  --                    is to be populated.
  --   partition_name - If partition name is not null,
  --                    then repopulate the specified partition

  procedure populate(
        schema_name      in varchar2,
        table_name       in varchar2,
        partition_name   in varchar2 DEFAULT NULL);

  -------------------------------------------------------------------------
  -- PROCEDURE segment_deallocate_versions
  -------------------------------------------------------------------------
  -- Description :
  --   Walk through the segment and deallocate in-memory extents for
  --   old SMU and IMCU versions
  --
  -- Input parameters:
  --   schema_Name    - User owning the object
  --   table_name     - Name of the table
  --   partition_name - If partition name is not null,
  --                    then work on  the specified partition
  --   spcpressure    - If TRUE, will break retention of IMCUs

  procedure segment_deallocate_versions(
        schema_name      in varchar2,
        table_name       in varchar2,
        partition_name   in varchar2 DEFAULT NULL,
        spcpressure      in boolean DEFAULT FALSE);

  -------------------------------------------------------------------------
  -- PROCEDURE ime_drop_expressions
  -------------------------------------------------------------------------
  -- Description :
  --   Drop a particular SYS_IME expression or all SYS_IME expressions in
  --   a table
  -- Input parameters:
  --   schema_Name    - Owner of the table
  --   table_name     - Table name
  --   column_name    - If column_name is NULL, then drop all SYS_IMEs in the
  --                    table, else just the requested column

  procedure ime_drop_expressions(
        schema_name      in varchar2,
        table_name       in varchar2,
        column_name      in varchar2 DEFAULT NULL);

end;
/

