create TYPE     aq$_post_info AS OBJECT (
        name             VARCHAR2(128),       -- name of the subscription
        namespace        NUMBER,              -- namespace of the subscription
        payload          RAW(32767))          -- payload
 alter type     aq$_post_info modify attribute
           (name varchar2(512)) CASCADE
/

