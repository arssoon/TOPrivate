create TYPE DBMS_XS_NSATTR FORCE AS OBJECT
(
  --- Member variables
  namespace        varchar2(130),  /* Namespace name, 128 + 2 = 130 char
                                      long to allow case sensitive (double
                                      quoted) 128 char namespace names   */
  attribute        varchar2(4000),                     /* Attribute name */
  attribute_value  varchar2(4000),                    /* Attribute value */

  --- Constructor for DBMS_XS_NSATTR type
  --- Only namespace name is mandatory
  CONSTRUCTOR FUNCTION DBMS_XS_NSATTR(
     namespace         IN VARCHAR2,
     attribute         IN VARCHAR2 DEFAULT NULL,
     attribute_value   IN VARCHAR2 DEFAULT NULL)
  RETURN SELF AS RESULT
);
/

