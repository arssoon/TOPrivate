create function JSON_DATAGUIDE(input AnyData,
                           format NUMBER DEFAULT DBMS_JSON.FORMAT_FLAT,
                           pretty NUMBER DEFAULT 0)
return CLOB aggregate using JsonDgImp;
/

