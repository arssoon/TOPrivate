create function des_encrypted_password (user varchar2 default NULL)
return varchar2 is
begin
return dbms_standard.des_encrypted_password(user);
end;
/

