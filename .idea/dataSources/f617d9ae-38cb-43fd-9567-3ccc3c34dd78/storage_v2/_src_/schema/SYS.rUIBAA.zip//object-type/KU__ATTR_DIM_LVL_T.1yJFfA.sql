create type ku$_attr_dim_lvl_t force as object
(
  dim_obj#       number,                             /* obj# of the attr dim */
  lvl_id         number,                         /* level id in the attr dim */
  name           varchar2(128),        /* level name (hcs_dim_lvl$.lvl_name) */
  member_name    clob,              /* member name (hcs_dim_lvl$.member_name */
  member_caption clob,        /* member caption (hcs_dim_lvl$.member_caption */
  member_desc    clob,/* member description (hcs_dim_lvl$.member_description */
  skip_when_null varchar2(1),                              /* skip when null */
  level_type     varchar2(16),                                 /* level type */
  clsfctn_list   ku$_hcs_clsfctn_list_t,                  /* classifications */
  key_list       ku$_attr_dim_lvl_key_list_t,          /* list of level keys */
  ordby_list     ku$_attr_dim_lvl_ordby_list_t,                 /* order bys */
  dtm_attr_list  ku$_attr_dim_attr_list_t,       /* list of determined attrs */
  order_num      number                         /* order number of the level */
)
not persistable
/

