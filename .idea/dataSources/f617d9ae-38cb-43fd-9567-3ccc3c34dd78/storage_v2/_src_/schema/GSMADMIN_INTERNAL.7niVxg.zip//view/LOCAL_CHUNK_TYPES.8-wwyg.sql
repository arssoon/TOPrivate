create view LOCAL_CHUNK_TYPES
            (TABFAM_ID, TABLE_NAME, SCHEMA_NAME, GROUP_TYPE, GROUP_COL_NUM, SHARD_TYPE, SHARD_COL_NUM, DEF_VERSION,
             SHARDGROUP_NAME)
as
select
  TF.FAMILY_ID, GT.TABLE_NAME, GT.SCHEMA_NAME,
  decode(TF.PARTITION_SET_TYPE, 1, 'RANGE', 2, 'HASH', 4, 'LIST', 'NONE'),
  (select count(1) from SHARDKEY_COLUMNS PK where PK.FAMILY_ID = TF.FAMILY_ID and PK.KEY_LEVEL = 0),
  decode(TF.SHARD_TYPE, 1, 'RANGE', 2, 'HASH', 4, 'LIST', 'NONE'),
  (select count(1) from SHARDKEY_COLUMNS PK where PK.FAMILY_ID = TF.FAMILY_ID and PK.KEY_LEVEL = 1),
  D.ddlid, dbms_gsm_common.getParam_shardgroup_name
from
  GLOBAL_TABLE GT, TABLE_FAMILY TF, DDLID$ D
where GT.REF_TABLE_FLAG = 'R' AND
  TF.FAMILY_ID = GT.FAMILY_ID
with read only
/

