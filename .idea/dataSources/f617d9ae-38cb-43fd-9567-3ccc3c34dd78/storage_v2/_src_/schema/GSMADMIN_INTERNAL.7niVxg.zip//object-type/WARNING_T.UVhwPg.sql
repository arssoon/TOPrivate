create type warning_t force as object (
  code int,
  message varchar2(1024)
);
/

