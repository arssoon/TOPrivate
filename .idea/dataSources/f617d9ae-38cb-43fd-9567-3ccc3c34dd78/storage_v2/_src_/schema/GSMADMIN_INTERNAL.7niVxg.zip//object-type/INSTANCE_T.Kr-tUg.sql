create TYPE instance_t FORCE IS OBJECT (
                        virt_name      varchar2(128),
                        instance_name  varchar2(128) );
/

