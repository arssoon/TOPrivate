create FUNCTION         oid_enabled wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
9c be
kl7DqpXHhHQJewO1XFGKBy/EVlUwg1xf2svWfC+iXviOEuE2DdWqOVT6oxQFjsMrZhbIUV35
TLgOWuiI1+t9gQNTR7dQEg/ZM0UkQQXlZpt2AlRlOaIGGlY5b+miaF5L1GNsKg1tgkiigi2W
LwsdeswcCO0cvqKQ4v2o7k/ESR+qEQ3lc+8lxCg7BBsT
/

