create view CTX_TRACE_VALUES as
select trc.trc_id, trc.trc_value
  from TABLE(ctxsys.drvparx.TraceGetTrace) trc
/

