create view CTX_SQES as
select u.name     sqe_owner,
       sqe_name,
       sqe_query
  from dr$sqe sqe, sys."_BASE_USER" u
 where sqe_owner# = u.user#
/

