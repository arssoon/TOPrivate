create PACKAGE ORDX_DEFAULT_DOC
authid current_user
AS

  PROCEDURE setProperties(ctx IN OUT RAW, obj IN OUT NOCOPY ORDSYS.ORDDoc,
			setComments IN NUMBER := 0);

END;
/

