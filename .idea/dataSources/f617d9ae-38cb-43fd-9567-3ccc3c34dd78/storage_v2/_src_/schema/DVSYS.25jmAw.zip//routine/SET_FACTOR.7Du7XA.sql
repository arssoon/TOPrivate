create PROCEDURE       set_factor(p_factor IN VARCHAR2,
                                       p_value  IN VARCHAR2)
IS
BEGIN
  dvsys.dbms_macsec.set_factor(p_factor => p_factor,
                         p_value  => p_value);
END;
/

