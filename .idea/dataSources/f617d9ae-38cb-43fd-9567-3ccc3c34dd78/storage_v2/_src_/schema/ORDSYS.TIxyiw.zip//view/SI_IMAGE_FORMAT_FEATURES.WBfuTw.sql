create view SI_IMAGE_FORMAT_FEATURES as
SELECT a.si_format, b.si_feature_name
  from ORDSYS.si_image_formats_tab a, ORDSYS.si_features_tab b
  where a.read_flg = 'Y'
/

