create view SI_IMAGE_FORMAT_CONVERSIONS as
SELECT a.SI_format SI_source_format, b.si_format SI_target_format
  FROM ORDSYS.SI_image_formats_tab a , ORDSYS.SI_image_formats_tab b
  where a.read_flg = 'Y'
  and b.write_flg = 'Y'
  and a.si_format <> b.si_format
/

