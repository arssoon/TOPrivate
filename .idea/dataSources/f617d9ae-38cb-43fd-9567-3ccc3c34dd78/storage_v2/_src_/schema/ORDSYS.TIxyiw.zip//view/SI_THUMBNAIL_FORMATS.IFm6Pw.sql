create view SI_THUMBNAIL_FORMATS as
SELECT a.SI_format
  from ORDSYS.si_image_formats_tab a
  where a.write_flg = 'Y'
/

