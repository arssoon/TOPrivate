create FUNCTION
  SI_findTexture wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
b5 ce
HOZP7ytZTkmTfjOyVufvy9gokVEwgy7wNZ4VZ3TpTHI+wqAXfeX/5DxnE+YbNb9VVK/wmcyl
zkrW5r/u7XIMu9PwF2tH2YGfnbSSP7wcHiJy4vN6Mh3jCtfUhlQ1tuOOi6O+7nHcjjy+pK3M
9VzjYkFrAhsE9eDu0+PbrXZ8S44IIMiPoL15D3h5qRpkipMlIFC5IpFKZec=
/

