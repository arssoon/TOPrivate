create FUNCTION
  SI_getPstnlClrFtrW wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
115 103
mM3IGhO4TNu8LgC6z8kL5YGW96Awg1xKLcvWfHSi2k6UHNklLHCs2/sMJjVK72Do5Zn8Zzqq
PZFNcANyu7l2Zdpj96izmz/N67+12EhVFbzX/qk7ya9aoTeeUgn8nmdQ3zkki9FmWaxK8QEx
Y9d7yFuc6cgy+r2Vw9AYmxTf2q0OwzK06zcdRFM8bI92C7J7cPuPmp99Lvd8GzQZ3PMoEr/y
l7PpvcXHJBFSqBL21QsyR0CBTRfCvnOmFk5aTQ==
/

