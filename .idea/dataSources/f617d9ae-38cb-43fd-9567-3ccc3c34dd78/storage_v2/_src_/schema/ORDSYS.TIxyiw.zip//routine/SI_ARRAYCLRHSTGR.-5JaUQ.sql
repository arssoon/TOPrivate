create FUNCTION
  SI_arrayClrHstgr wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
103 f3
CHiYSPP00ncpzRqejv6ddSASFxcwgwFKLcvWfHSi2k6UiG3bLHxjry8Mr8x5gFxJ23djXoNj
qppnzALbeSKdA2SuXY7viK/e/0L5UxczZP7vT0x095XY5mWdfw4RXliMI0D24cDnm7C/GfEK
DEo1tmRyKxUf2st+xsLCoQCf1GzJypDxph/EHUQc957j/w7DHwTIpzkFPoS42hkFg3iYnjK6
+zKZJ1jNVUQzUR3EsJZjBqIJ
/

