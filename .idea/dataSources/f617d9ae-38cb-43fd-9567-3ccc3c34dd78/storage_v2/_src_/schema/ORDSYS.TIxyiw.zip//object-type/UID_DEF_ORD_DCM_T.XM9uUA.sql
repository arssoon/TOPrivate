create TYPE          "UID_DEF_ORD_DCM_T" UNDER "UID_ENTRY_ORD_DCM_T"("classification" "XDB"."XDB$ENUM_T","isLE" RAW(1),"isEVR" RAW(1),"isCompressed" RAW(1),"retired" RAW(1),"contentType" "XDB"."XDB$ENUM_T")FINAL INSTANTIABLE
/

