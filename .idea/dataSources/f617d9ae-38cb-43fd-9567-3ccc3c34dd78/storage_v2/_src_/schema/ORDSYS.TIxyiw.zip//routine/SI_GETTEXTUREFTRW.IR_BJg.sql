create FUNCTION
  SI_getTextureFtrW wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
112 ff
ixNN3B6KHqlcKuoPQtwokA0E2w4wg1xKLcvWfHSi2k6UHNklLH02+kRWY2vAdrPwvTKAw/zB
ePppr8lPmlUxY3CJsGf3nP5FHpJVJAX8M3m8e/XsNkGM0+qPDqCy98ogN4qJIygjnnTGdo2W
TCX3YlgUrA4MGMjYoxZdr6gFMS/G6MbdREmf9eJtjvH+YinjnlCdO33+xa+AbiAH47o/6gjF
Cl5YB8wKva+LwnvfAf93pgCp/tkoaaiAQw==
/

