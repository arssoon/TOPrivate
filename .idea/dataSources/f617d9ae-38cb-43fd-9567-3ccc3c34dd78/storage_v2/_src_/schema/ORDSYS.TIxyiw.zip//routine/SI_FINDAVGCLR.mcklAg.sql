create FUNCTION
  SI_findAvgClr wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
bc d2
mxspSby5tY134HvSJYQfeCWuPW4wg0xKf57hfy/pO8cYibmIYRi3MVfIkN2RyWLE8+nIYlZ6
nTGpymG7EByqZTljFbwlIxJ+saW8ak4y2JU2yIvIUF6cXD7ByznB7Q7s9RxviTlrXWYuNuuC
6SgbrNgKXGjeoulY9CZc3V4ySVnbLs+EX5y1tLsHOPWFUg9Z239WvcJfByg3WIIr
/

