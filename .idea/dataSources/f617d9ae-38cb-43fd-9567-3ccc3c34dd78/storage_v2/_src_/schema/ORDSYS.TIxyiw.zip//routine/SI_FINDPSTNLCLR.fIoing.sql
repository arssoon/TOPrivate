create FUNCTION
  SI_findPstnlClr wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
c7 db
dZODta6347ZkMk/PzEB4CsuhbBMwg3lKf55qfHTp2sGOqxOCkcABbJRXwveRe8k+AuaFyDP5
Ib2Oe/UQu07OEJT1/+HU64a+aNke7UdXZBfZXPcwdB37LINuXntnBaYWQj3WnH40SeYVbsJI
0cOdwDbY5RQiXIyQYMAl9wLEL+G6x2s3Abaab+dV+TaqZKBMhNP+zHLTbb4UWYOQIiqfeMU=

/

