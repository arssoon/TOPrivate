create view SI_VALUES as
select SI_value, SI_supported_Value
  from ordsys.SI_Values_tab
/

