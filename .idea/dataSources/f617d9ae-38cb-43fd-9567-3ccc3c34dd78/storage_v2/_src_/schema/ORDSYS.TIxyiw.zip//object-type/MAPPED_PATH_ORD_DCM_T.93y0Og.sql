create TYPE          "MAPPED_PATH_ORD_DCM_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","occurs" RAW(1),"notEmpty" RAW(1),"writeTag" RAW(1),"writeDefiner" RAW(1),"writeName" RAW(1),"writeRawValue" RAW(1),"ATTRIBUTE_TAG" VARCHAR2(1999 CHAR),"PATH" VARCHAR2(1999 CHAR))FINAL INSTANTIABLE
/

