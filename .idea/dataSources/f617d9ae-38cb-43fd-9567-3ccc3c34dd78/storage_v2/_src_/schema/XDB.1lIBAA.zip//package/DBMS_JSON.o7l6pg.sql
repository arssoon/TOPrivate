create PACKAGE     dbms_json AUTHID CURRENT_USER IS

---------------------------------------
-- JSON field types
---------------------------------------
TYPE_NULL    CONSTANT NUMBER(2)  := 1;
TYPE_BOOLEAN CONSTANT NUMBER(2)  := 2;
TYPE_NUMBER  CONSTANT NUMBER(2)  := 3;
TYPE_STRING  CONSTANT NUMBER(2)  := 4;
TYPE_OBJECT  CONSTANT NUMBER(2)  := 5;
TYPE_ARRAY   CONSTANT NUMBER(2)  := 6;

-----------------------------------------------
-- JSON Data guide formatting
-----------------------------------------------
FUNCTION FORMAT_HIERARCHICAL return NUMBER PARALLEL_ENABLE;
FUNCTION FORMAT_FLAT return NUMBER PARALLEL_ENABLE;
FUNCTION PRETTY return NUMBER PARALLEL_ENABLE;

-------------------------------------------
-- Data guide related procedures/functions
-------------------------------------------

---------------------------------------------
-- PROCEDURE rename_column(VARCHAR2, VARCHAR2, VARCHAR2, VARCHAR2)
--     The procedures allows a user to provide his preferred name for a JSON
--     field. Internally, it updates the viewColName column in the $dg table.
-- Parameters -
--  tableName
--     The name of the table that contains the JSON column
--  jcolName
--     The name of the JSON column which has data guide enabled context index.
--     If the JSON column does not have a data guide enabled context index,
--     an error will be raised.
--  path
--     A JSON path referring to a JSON field, e.g. $.purchaseOrder.items.name.
--  type
--     The type of the JSON field. Two JSON fields may have the same path, but
--     different types. One of the following values:
--       TYPE_NULL
--       TYPE_STRING
--       TYPE_NUMBER
--       TYPE_BOOLEAN
--       TYPE_OBJECT
--       TYPE_ARRAY
--  preferred_name
--     The preferred name for the JSON field specified in path. If there is a
--     name conflict, it will use a system generated name.
---------------------------------------------
PROCEDURE rename_column(tableName VARCHAR2,
                        jcolName VARCHAR2,
                        path VARCHAR2,
                        type NUMBER,
                        preferred_name VARCHAR2);

---------------------------------------------
-- FUNCTION get_index_dataguide(VARCHAR2, VARCHAR2, VARCHAR2, NUMBER, NUMBER)
--     This function reads from the underlying $dg table and generates data
--     guide in JSON format. If the underlying $dg table has statistic
--     information, the generated data guide will include them.
-- Parameters -
--  owner
--     The owner of the table
--  tableName
--     The name of the table that contains the JSON column
--  jcolName
--     The name of the JSON column which has data guide enabled context index.
--     If the JSON columns does not have a data guide enabled context index,
--     an error will be raised.
--  format
--     The format in which the data guide will be displayed, two options:
--     .  FORMAT_HIERARCHICAL - hierarchical format
--     .  FORMAT_FLAT - flat format
--  pretty
--     If dbms_json.PRETTY, the returned data guide will have appropriate
--     indention to improve readability.
---------------------------------------------
FUNCTION get_index_dataguide(owner VARCHAR2,
                             tableName VARCHAR2,
                             jcolName VARCHAR2,
                             format NUMBER,
                             pretty NUMBER DEFAULT 0) RETURN CLOB;


FUNCTION get_index_dataguide(tableName VARCHAR2,
                             jcolName VARCHAR2,
                             format NUMBER,
                             pretty NUMBER DEFAULT 0) RETURN CLOB;

---------------------------------------------
-- PROCEDURE create_view(VARCHAR2, VARCHAR2, VARCHAR2, CLOB)
--     The procedure will create a view with relational columns, and scalar
--     JSON fields (could be under an array) specified in the annotated data
--     guide. It does not require the JSON column to have data guide enabled
--     context index.
-- Parameters -
--  viewName
--     The name of the customized view
--  tableName
--     The name of the table containing the JSON column
--  jcolName
--     The name of the JSON column to create a view on.
--  dataguide
--     The annotated data guide
--  resourcePath
--     The resourcePath will be used to register the create view ddl statement
--     as resource by calling dbms_xdb.createresource(resourcePath, <ddl>);
---------------------------------------------
PROCEDURE create_view(viewName VARCHAR2,
                      tableName VARCHAR2,
                      jcolName VARCHAR2,
                      dataguide CLOB,
                      resourcePath VARCHAR2 DEFAULT NULL);

---------------------------------------------
-- PROCEDURE create_view_on_path(VARCHAR2, VARCHAR2, VARCHAR2, VARCHAR2, NUMBER)
--     This procedure will create a view with relational columns, top-level
--     scalar types, and fully expands sub-tree under the path. The view column
--     names are get from column viewColName in $dg table.
-- Parameters -
--  viewName
--     The name of the customized view
--  tableName
--     The name of the table containing the JSON column
--  jcolName
--     The name of the JSON column which has data guide enabled context index.
--     If the JSON columns does not have a data guide enabled context index,
--     an error will be raised.
--  path
--     The path of the JSON field to be expanded. It uses JSON path expression
--     syntax, e.g. $ will create a view starting from the JSON document root;
--     $.purchaseOrder will create a view starting from purchaseOrder. It
--     expands the children/descendants under purchaseOrder, and create view
--     columns for every scalar values.
--  frequency
--     The view will only display the JSON fields with frequency greater than
--     the given frequency. It will NOT display JSON fields added after
--     dbms_json.gatherStats if the given frequency is greater than 0, as their
--     statistic columns are NULL.
--     If the frequency value is 0, it will display all JSON fields including
--     those added after dbms_json.gatherStat call.
--     If user never invokes dbms_json.gatherStats, i.e. there is no statistic
--     information in the data guide, this argument will be ignored and all
--     JSON fields will be displayed in the view.
--  resourcePath
--     The resourcePath will be used to register the create view ddl statement
--     as resource by calling dbms_xdb.createresource(resourcePath, <ddl>);
--  materialize
--     The materialize argument will be a boolean that will tell us whether the
--     view will be materialized or not.
---------------------------------------------
PROCEDURE create_view_on_path(viewName VARCHAR2,
                           tableName VARCHAR2,
                           jcolName VARCHAR2,
                           path VARCHAR2,
                           frequency NUMBER DEFAULT 0,
                           resourcePath VARCHAR2 DEFAULT NULL,
                           materialize BOOLEAN DEFAULT FALSE);

---------------------------------------------
-- PROCEDURE add_virtual_columns(VARCHAR2, VARCHAR2, CLOB)
--     The procedure adds one virtual column for each scalar JSON field not
--     under an array. The virtual column name
--     is the value of o:preferred_column_name in the annotated data guide. It
--     ignores JSON objects, arrays, and fields under arrays in the annotated
--      data guide.
--     It does not require the JSON column to have data guide enabled context
--     index.
--     It there already exist virtual columns added from this JSON column, the
--     old virtual columns will be removed. Internally, we comment each virtual
--     column with the JSON column name to track who adds them.
-- Parameters -
--  tableName
--     The name of the table containing the JSON column
--  jcolName
--     The name of the JSON column to create virtual columns from
--  dataguide
--     The annotated data guide. When o:hidden in the annotated data guide
--     for a particular JSON field is set to TRUE, the corresponding virtual
--     column is added as hidden. The default value of o:hiddend is FALSE.
---------------------------------------------
PROCEDURE add_virtual_columns(tableName VARCHAR2,
                              jcolName VARCHAR2,
                              dataguide CLOB);

---------------------------------------------
-- PROCEDURE add_virtual_columns(VARCHAR2, VARCHAR2, NUMBER, BOOLEAN)
--     The procedure looks up the $dg table and adds one virtual column for
--     every scalar field not under an array with frequency greater than the
--     given value. The virtual column name is got
--     from column viewColName in $dg table. It ignores JSON objects, arrays,
--     and fields under arrays.
-- Parameters -
--  tableName
--     The name of the table containing the JSON column
--  jcolName
--     The name of the JSON column which has data guide enabled context index.
--     If the JSON columns does not have a data guide enabled context index,
--     an error will be raised.
--  frequency
--     Only display the JSON fields with frequency greater than the given
--     frequency. It will NOT display JSON fields added after
--     dbms_json.gatherStats if the given frequency is greater than 0, as
--     their statistic columns are NULL.
--     If the frequency value is 0, it will display all JSON fields including
--     those added after dbms_json.gatherStat call.
--     If user never invokes dbms_json.gatherStats, i.e. there is no statistic
--     information in the data guide, this argument will be ignored and all
--     JSON fields will be displayed in the view.
--  hidden
--     Whether the virtual columns will be added as hidden.
--     The default is FALSE.
---------------------------------------------
PROCEDURE add_virtual_columns(tableName VARCHAR2,
                              jcolName VARCHAR2,
                              frequency NUMBER DEFAULT 0,
                               hidden BOOLEAN DEFAULT FALSE);

---------------------------------------------
-- PROCEDURE drop_virtual_columns(VARCHAR2, VARCHAR2)
--     The procedure drops the virtual columns created by the data guide,
--     either through the previous addVC call or the pre-implmeneted trigger
--     add_vc.
-- Parameters -
--  tableName
--     The name of the table containing the JSON column
--  jcolName
--     The name of the JSON column which has data guide enabled context index.
--     If the JSON columns does not have a data guide enabled context index,
--     an error will be raised.
---------------------------------------------
PROCEDURE drop_virtual_columns(tableName VARCHAR2,
                               jcolName VARCHAR2);

---------------------------------------------
-- PROCEDURE generateDataGuide(VARCHAR2, VARCHAR2, VARCHAR2, NUMBER)
--     The procedure scans the given JSON collection, builds data guide on
--     the fly, then creates a table to store the data guide information.
-- Parameters -
--  dgTabName
--     The name of the table to store data guide information
--  tabViewName
--     The name of the table or view containing the JSON column
--  jcolName
--     The name of the JSON column to create data guide on
--  estimate_percent
--     Percentage of JSON rows to sample. The valid range is [0.000001,100].
--     Similar to the argument in dbms_stats.gather_table_stats.
---------------------------------------------
/*
PROCEDURE generateDataGuide(dgTabName VARCHAR2,
                            tabViewName VARCHAR2,
                            jcolName VARCHAR2,
                            estimate_percent NUMBER DEFAULT 2);
*/

--------------------------------------------------
-- End of data guide related procedures/functions
--------------------------------------------------

-------------------------------------------
-- JSON inmemory related procedures/functions
-------------------------------------------
---------------------------------------------
-- PROCEDURE prepJColInM(VARCHAR2, VARCHAR2)
--  For this json column (IS JSON check constraint) that is created prior to
--  12.2 release, this procedure upgrades such json column to prepare to
--  take advantage of in memory json processing that is new in 12.2 release.
-- Parameters -
--  tabName
--     The table name of the table to which this json column belongs.
--  jcolName
--     The column name of the json column
-- Note the database server must set compatible=12.2.0.0
-- max_string_size=extended in order to run this procedure.
---------------------------------------------
PROCEDURE prepJColInM(tabName VARCHAR2, jcolName VARCHAR2);
---------------------------------------------
-- PROCEDURE prepTabJColInM(VARCHAR2)
--  For table containing json columns (IS JSON check constraint) that are
--  created prior to
--  12.2 release, this procedure upgrades all of these json columns in this
--  table  to parepare to take advantage of in memory json processing that is
--  new in 12.2 release.
-- Parameters -
--  tabName
--     The table name of the table.
-- Note the database server must set compatible=12.2.0.0
-- max_string_size=extended in order to run this procedure.
---------------------------------------------
PROCEDURE prepTabJColInM(tabName VARCHAR2);

-- PROCEDURE  prepAllJColInM
--  For all the tables containing json columns (IS JSON check constraint) that
--  are  created prior to
--  12.2 release, this procedure upgrades all of these json columns
--  in all these tables  to prepare to take advantage of in memory json
--  processing that is new in 12.2 release.
--  All of these tables are owned by current user.
-- Parameters -
--     NONE
-- Note the database server must set compatible=12.2.0.0
-- max_string_size=extended in order to run this procedure.
PROCEDURE prepAllJColInM;
--------------------------------------------------
-- End of JSON inemmory related procedures/functions
--------------------------------------------------
end dbms_json;
/

