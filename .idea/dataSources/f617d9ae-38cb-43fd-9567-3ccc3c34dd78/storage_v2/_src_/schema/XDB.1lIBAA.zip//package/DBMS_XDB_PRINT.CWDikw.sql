create package     dbms_xdb_print wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
240 158
UgJszPEeHlHDDqGcJZP9CBL7gScwg/BQNQyEf3RbuHK7Xl1NjwHFhDO0qGTXyZMPuiWOiyZ8
nwgO4yOlhgWN7jkQthJWnV1PFA6Dj+xwnRJzR5r4TD+1MEL44VmbkSFN21ncwBjbcOCx+zbf
Q4TrnreNdrRb4EI5Q0yO9eHR8ISvbWxHkg8cdZHTVZBfTusnLc9XDlN/qILpT1TMYAG6/rRF
4BpWUKN117oQVAPijgWs+APMs9wach51Q3wxVwCQk7pfU+3K/LMYJmRfa1pJG+MUKp/S7OJq
lwarX9qnaNK1jcS4dO1pClaotVjr9+sOB3+LOxzAY3M9KNmpWKU=
/

