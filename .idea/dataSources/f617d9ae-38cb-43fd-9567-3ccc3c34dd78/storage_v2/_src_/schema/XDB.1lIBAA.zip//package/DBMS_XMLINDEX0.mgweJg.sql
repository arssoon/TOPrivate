create PACKAGE     dbms_xmlindex0 wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
3ad 164
SIbv3UxGB48nLG2hjdSTiRxDl38wg2PxrydqfHRAv/9efbSvywGxbsO6eUd+bIWbhdxAs6Q5
eZaY0gjBQDWIkwzxvXSnUHJJtSsHi0S/Nvj+huoiLChPsHPGQrJ1oFJvWdOoPG5mvXDYe96y
MRQ2YOeNVwKy9AsMc+UoIijEdi6E+69/NFF1OUM6JqzaUlxlOcUC+pcVtcQlMFZyEyo7vDLS
HW5qITuuN05Pl8YjkeJiwUANXljvF7Celorp/0pok2du/u/v6iCDxV26oK0z0RIVzQbw7cRk
RFfb3y3MsWWKWtqJJbAUnDM9yOmND+VlExu+b/wYtKxVRnWZeak7Hgcg4EX/mg==
/

