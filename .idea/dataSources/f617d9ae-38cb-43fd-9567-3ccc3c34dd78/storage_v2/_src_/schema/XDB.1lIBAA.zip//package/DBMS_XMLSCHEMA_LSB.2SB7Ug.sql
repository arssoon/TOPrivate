create package     dbms_xmlschema_lsb authid current_user is

  procedure registerSchema_Str(schemaurl IN varchar2,
                           schemadoc IN varchar2,
                           local IN number,
                           gentypes IN number,
                           genbean IN number,
                           gentables IN number,
                           force IN number,
                           owner IN varchar2,
                           enablehierarchy IN number,
                           options IN number,
                           schemaoid IN RAW,
                           tabmd IN xdb.DBMS_XMLSCHEMA_TABMDARR,
                           resmd IN xdb.DBMS_XMLSCHEMA_RESMDARR);
  pragma supplemental_log_data (registerSchema_Str, AUTO);

  procedure registerSchema_Clob(schemaurl IN varchar2,
                           schemadoc IN CLOB,
                           local IN number,
                           gentypes IN number,
                           genbean IN number,
                           gentables IN number,
                           force IN number,
                           owner IN varchar2,
                           enableHierarchy IN number,
                           options IN number,
                           schemaoid IN RAW,
                           tabmd IN xdb.DBMS_XMLSCHEMA_TABMDARR,
                           resmd IN xdb.DBMS_XMLSCHEMA_RESMDARR);

  procedure registerSchema_Blob(schemaurl IN varchar2,
                           schemadoc IN BLOB,
                           local IN number,
                           gentypes IN number,
                           genbean IN number,
                           gentables IN number,
                           force IN number,
                           owner IN varchar2,
                           csid IN NUMBER,
                           enablehierarchy IN number,
                           options IN number,
                           schemaoid IN RAW,
                           tabmd IN xdb.DBMS_XMLSCHEMA_TABMDARR,
                           resmd IN xdb.DBMS_XMLSCHEMA_RESMDARR);
  pragma supplemental_log_data (registerSchema_Blob, AUTO);

  procedure registerSchema_XML(schemaurl IN varchar2,
                           schemadoc IN sys.xmltype,
                           local IN number,
                           gentypes IN number,
                           genbean IN number,
                           gentables IN number,
                           force IN number,
                           owner IN varchar2,
                           enablehierarchy IN number,
                           options IN number,
                           schemaoid IN RAW,
                           tabmd IN xdb.DBMS_XMLSCHEMA_TABMDARR,
                           resmd IN xdb.DBMS_XMLSCHEMA_RESMDARR);
  pragma supplemental_log_data (registerSchema_XML, AUTO);

  procedure registerSchema_OID(schemaurl IN varchar2,
                           schemadoc IN CLOB,
                           local IN number,
                           gentypes IN number,
                           genbean IN number,
                           gentables IN number,
                           force IN number,
                           owner IN varchar2,
                           enablehierarchy IN number,
                           options IN number,
                           schemaoid IN RAW,
                           elname IN varchar2,
                           elnum IN number,
                           import_options IN number,
                           tabmd IN xdb.DBMS_XMLSCHEMA_TABMDARR,
                           resmd IN xdb.DBMS_XMLSCHEMA_RESMDARR);
  pragma supplemental_log_data (registerSchema_OID, AUTO);

  procedure CopyEvolve(schemaurls         IN XDB$STRING_LIST_T,
                       newSchemas         IN XMLSequenceType,
                       transforms         IN XMLSequenceType,
                       preserveolddocs    IN NUMBER,
                       maptabname         IN VARCHAR2,
                       generatetables     IN NUMBER,
                       force              IN NUMBER,
                       schemaowners       IN XDB$STRING_LIST_T,
                       paralleldegree     IN NUMBER,
                       options            IN NUMBER,
                       tabmd IN xdb.DBMS_XMLSCHEMA_TABMDARR,
                       resmd IN xdb.DBMS_XMLSCHEMA_RESMDARR);
  pragma supplemental_log_data (CopyEvolve, AUTO);

  procedure compileSchema(schemaURL IN varchar2,
                          schemaoid IN RAW,
                          tabmd        IN xdb.DBMS_XMLSCHEMA_TABMDARR);

end dbms_xmlschema_lsb;
/

