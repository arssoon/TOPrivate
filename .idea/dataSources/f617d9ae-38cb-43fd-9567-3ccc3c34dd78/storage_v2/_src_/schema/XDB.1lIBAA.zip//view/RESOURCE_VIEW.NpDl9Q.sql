create view RESOURCE_VIEW as
select value(p) res, abspath(8888) any_path, sys_nc_oid$ resid
  from xdb.xdb$resource p
  where under_path(value(p), '/', 8888) = 1
/

