create view USER_WM_POLICIES as
select object_name, policy_group, policy_name, pf_owner, package, function, sel, ins, upd, del, idx,
       chk_option, enable, static_policy, policy_type, long_predicate
from wmsys.all_wm_policies
where object_owner = sys_context('userenv', 'current_user')
WITH READ ONLY
/

