create view ALL_VERSION_HVIEW as
select vht.version, vht.parent_version, wt.workspace, vht.workspace# workspace_id
from wmsys.wm$version_hierarchy_table$ vht, wmsys.wm$workspaces_table$i wt
where vht.workspace# = wt.workspace_lock_id
WITH READ ONLY
/

