create view USER_WM_MODIFIED_TABLES as
select table_name, workspace, savepoint
from (select o.table_name, o.workspace,
             nvl(s.savepoint, 'LATEST') savepoint,
             s.is_implicit imp,
             count(*) over (partition by o.table_name, o.workspace, s.version) counter
      from wmsys.wm$modified_tables o, wmsys.wm$workspace_savepoints_table s
      where substr(o.table_name, 1, instr(o.table_name, '.')-1) = sys_context('userenv', 'current_user') and
            o.version = s.version (+))
where (imp = 0 or imp is null or counter = 1)
WITH READ ONLY
/

