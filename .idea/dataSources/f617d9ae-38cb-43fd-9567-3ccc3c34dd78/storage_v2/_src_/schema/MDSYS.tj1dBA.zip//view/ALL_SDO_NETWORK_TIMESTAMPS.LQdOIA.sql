create view ALL_SDO_NETWORK_TIMESTAMPS as
SELECT  "OWNER","NETWORK","TABLE_NAME","LAST_DML_TIME"
    FROM  mdsys.sdo_network_timestamps
/

