create view ALL_SDO_NFE_MODEL_WORKSPACE as
SELECT SDO_OWNER OWNER,
         id,
         model_id,
         workspace,
         mbr_ind,
         lower_x,
         upper_x,
         lower_y,
         upper_y,
         lock_ind
  FROM MDSYS.SDO_NFE_MODEL_WORKSPACE
/

