create package       SDO_AGGR wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
111 df
Iaekbg7juCjkWkUcBP/SPFgS/MIwg43wf8vhf3Q2Jk6enMqQzt1cGwhDZuPWfrBTxbW1RNz7
skRR0v8w/vQISlhnXv11A6afBQystOnjefVsciFGO8egJc4Ly2zGirOt3dJrV3r153k/3rdE
dlQSWd3tGVrRNYVFfHddizIrASeNWUqBwdsFbjKatR3ppVT5VEaiYAmZHw3TEE9XO7AfjRah
WA==
package       SDO_AGGR wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
9
111 df
Iaekbg7juCjkWkUcBP/SPFgS/MIwg43wf8vhf3Q2Jk6enMqQzt1cGwhDZuPWfrBTxbW1RNz7
skRR0v8w/vQISlhnXv11A6afBQystOnjefVsciFGO8egJc4Ly2zGirOt3dJrV3r153k/3rdE
dlQSWd3tGVrRNYVFfHddizIrASeNWUqBwdsFbjKatR3ppVT5VEaiYAmZHw3TEE9XO7AfjRah
WA==
/

