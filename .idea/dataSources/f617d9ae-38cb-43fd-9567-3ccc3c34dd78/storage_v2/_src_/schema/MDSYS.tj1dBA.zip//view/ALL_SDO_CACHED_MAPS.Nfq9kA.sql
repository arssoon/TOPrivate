create view ALL_SDO_CACHED_MAPS as
SELECT SDO_OWNER OWNER, NAME, DESCRIPTION, tiles_table, is_online, is_internal, DEFINITION, base_map, map_adapter
FROM mdsys.SDO_CACHED_MAPS_TABLE
/

