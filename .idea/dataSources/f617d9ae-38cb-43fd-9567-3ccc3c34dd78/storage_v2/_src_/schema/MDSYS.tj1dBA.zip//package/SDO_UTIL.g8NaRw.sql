create PACKAGE       sdo_util AUTHID current_user AS
PACKAGE       sdo_util AUTHID current_user AS


-- CONSTANT DECLARATION
-- CONSTANT DECLARATION
  SDO_GTYPE_CURVE         CONSTANT  NUMBER := 2;
  SDO_GTYPE_CURVE         CONSTANT  NUMBER := 2;
  SDO_GTYPE_POLYGON       CONSTANT  NUMBER := 3;
  SDO_GTYPE_POLYGON       CONSTANT  NUMBER := 3;
  SDO_GTYPE_COLLECTION    CONSTANT  NUMBER := 4;
  SDO_GTYPE_COLLECTION    CONSTANT  NUMBER := 4;
  SDO_GTYPE_MULTICURVE    CONSTANT  NUMBER := 6;
  SDO_GTYPE_MULTICURVE    CONSTANT  NUMBER := 6;
  SDO_GTYPE_MULTIPOLYGON  CONSTANT  NUMBER := 7;
  SDO_GTYPE_MULTIPOLYGON  CONSTANT  NUMBER := 7;




  -- Invalidate the GTT "bulk load" cache (flush contents to disk)
  -- Invalidate the GTT "bulk load" cache (flush contents to disk)
  PROCEDURE invalidate_gtt_cache;
  PROCEDURE invalidate_gtt_cache;


  FUNCTION check_endian(index_owner IN VARCHAR2,
  FUNCTION check_endian(index_owner IN VARCHAR2,
                        index_table IN VARCHAR2,
                        index_table IN VARCHAR2,
                        root_addr IN VARCHAR2)
                        root_addr IN VARCHAR2)
  return NUMBER;
  return NUMBER;


  -- Update the "endian-ness" of the index table
  -- Update the "endian-ness" of the index table
  PROCEDURE update_endian(index_owner IN VARCHAR2,
  PROCEDURE update_endian(index_owner IN VARCHAR2,
                          index_table IN VARCHAR2,
                          index_table IN VARCHAR2,
                          index_fanout IN PLS_INTEGER,
                          index_fanout IN PLS_INTEGER,
                          index_dims IN PLS_INTEGER);
                          index_dims IN PLS_INTEGER);


  -- Copy <USER>.SDO_INDEX_TTS_METADATA$ to MDSYS.SDO_TTS_METADATA_TABLE
  -- Copy <USER>.SDO_INDEX_TTS_METADATA$ to MDSYS.SDO_TTS_METADATA_TABLE
  PROCEDURE copy_pre11gR2_metadata(index_owner IN VARCHAR2,
  PROCEDURE copy_pre11gR2_metadata(index_owner IN VARCHAR2,
                                   index_name IN VARCHAR2,
                                   index_name IN VARCHAR2,
                                   index_partition IN VARCHAR2);
                                   index_partition IN VARCHAR2);


  -- Is this an internal "rename table" operation as a result of a
  -- Is this an internal "rename table" operation as a result of a
  -- user-initiated DROP TABLE operation? (0=no, 1=yes)
  -- user-initiated DROP TABLE operation? (0=no, 1=yes)
  FUNCTION is_internal_rename
  FUNCTION is_internal_rename
  return number;
  return number;


  -- Determine if a "table name" is really a deleted table
  -- Determine if a "table name" is really a deleted table
  -- "internal" name...
  -- "internal" name...
  FUNCTION is_deleted(int_name IN varchar)
  FUNCTION is_deleted(int_name IN varchar)
  return boolean;
  return boolean;


  -- Normalize quoted name for bumpy-case usage
  -- Normalize quoted name for bumpy-case usage
  FUNCTION get_quoted_name(objname IN VARCHAR2)
  FUNCTION get_quoted_name(objname IN VARCHAR2)
  RETURN varchar2 DETERMINISTIC;
  RETURN varchar2 DETERMINISTIC;


  -- Generate quoted name for bump-case usage
  -- Generate quoted name for bump-case usage
  FUNCTION set_quoted_name(objname IN VARCHAR2)
  FUNCTION set_quoted_name(objname IN VARCHAR2)
  RETURN varchar2 DETERMINISTIC;
  RETURN varchar2 DETERMINISTIC;


  -- Is "spatial" license option enabled?
  -- Is "spatial" license option enabled?
  FUNCTION is_spatial_enabled
  FUNCTION is_spatial_enabled
  RETURN boolean;
  RETURN boolean;


  Function expand_multi_point (geometry IN mdsys.sdo_geometry)
  Function expand_multi_point (geometry IN mdsys.sdo_geometry)
  RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
  RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


  FUNCTION expand_geom (geometry IN mdsys.sdo_geometry)
  FUNCTION expand_geom (geometry IN mdsys.sdo_geometry)
  RETURN mdsys.sdo_geometry DETERMINISTIC PARALLEL_ENABLE;
  RETURN mdsys.sdo_geometry DETERMINISTIC PARALLEL_ENABLE;


  FUNCTION extract(geometry IN mdsys.sdo_geometry,
  FUNCTION extract(geometry IN mdsys.sdo_geometry,
                   element  IN NUMBER,
                   element  IN NUMBER,
                   ring     IN NUMBER DEFAULT 0)
                   ring     IN NUMBER DEFAULT 0)
    RETURN mdsys.sdo_geometry DETERMINISTIC PARALLEL_ENABLE;
    RETURN mdsys.sdo_geometry DETERMINISTIC PARALLEL_ENABLE;
    PRAGMA restrict_references(extract, wnds, rnps, wnps, trust);
    PRAGMA restrict_references(extract, wnds, rnps, wnps, trust);


  FUNCTION extract_all(geometry IN mdsys.sdo_geometry,
  FUNCTION extract_all(geometry IN mdsys.sdo_geometry,
                       flatten  IN NUMBER DEFAULT 1,
                       flatten  IN NUMBER DEFAULT 1,
                       exclude  IN MDSYS.SDO_NUMBER_ARRAY DEFAULT NULL)
                       exclude  IN MDSYS.SDO_NUMBER_ARRAY DEFAULT NULL)
    RETURN mdsys.sdo_geometry_array DETERMINISTIC PARALLEL_ENABLE;
    RETURN mdsys.sdo_geometry_array DETERMINISTIC PARALLEL_ENABLE;
    PRAGMA restrict_references(extract_all, wnds, rnps, wnps, trust);
    PRAGMA restrict_references(extract_all, wnds, rnps, wnps, trust);


  FUNCTION from_json(geometry IN CLOB, crs IN VARCHAR2 DEFAULT NULL,
  FUNCTION from_json(geometry IN CLOB, crs IN VARCHAR2 DEFAULT NULL,
                       srid IN NUMBER DEFAULT -1)
                       srid IN NUMBER DEFAULT -1)
    RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
    RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


  FUNCTION to_json(geometry IN MDSYS.SDO_GEOMETRY)
  FUNCTION to_json(geometry IN MDSYS.SDO_GEOMETRY)
    RETURN CLOB DETERMINISTIC PARALLEL_ENABLE;
    RETURN CLOB DETERMINISTIC PARALLEL_ENABLE;
    PRAGMA restrict_references(to_json, wnds, rnps, wnps, trust);
    PRAGMA restrict_references(to_json, wnds, rnps, wnps, trust);


  FUNCTION to_json_varchar(geometry IN MDSYS.SDO_GEOMETRY)
  FUNCTION to_json_varchar(geometry IN MDSYS.SDO_GEOMETRY)
    RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;
    RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;
    PRAGMA restrict_references(to_json_varchar, wnds, rnps, wnps, trust);
    PRAGMA restrict_references(to_json_varchar, wnds, rnps, wnps, trust);


  FUNCTION to_wkbgeometry(geometry IN mdsys.sdo_geometry)
  FUNCTION to_wkbgeometry(geometry IN mdsys.sdo_geometry)
    RETURN BLOB DETERMINISTIC PARALLEL_ENABLE;
    RETURN BLOB DETERMINISTIC PARALLEL_ENABLE;
    PRAGMA restrict_references(to_wkbgeometry, wnds, rnps, wnps, trust);
    PRAGMA restrict_references(to_wkbgeometry, wnds, rnps, wnps, trust);


  FUNCTION to_wktgeometry(geometry IN mdsys.sdo_geometry)
  FUNCTION to_wktgeometry(geometry IN mdsys.sdo_geometry)
    RETURN CLOB DETERMINISTIC PARALLEL_ENABLE;
    RETURN CLOB DETERMINISTIC PARALLEL_ENABLE;
    PRAGMA restrict_references(to_wktgeometry, wnds, rnps, wnps, trust);
    PRAGMA restrict_references(to_wktgeometry, wnds, rnps, wnps, trust);


  FUNCTION to_wktgeometry_varchar(geometry IN mdsys.sdo_geometry)
  FUNCTION to_wktgeometry_varchar(geometry IN mdsys.sdo_geometry)
    RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;
    RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;
    PRAGMA restrict_references(to_wktgeometry_varchar, wnds, rnps, wnps, trust);
    PRAGMA restrict_references(to_wktgeometry_varchar, wnds, rnps, wnps, trust);


  FUNCTION append(geometry1 IN MDSYS.sdo_geometry,
  FUNCTION append(geometry1 IN MDSYS.sdo_geometry,
                  geometry2 IN MDSYS.sdo_geometry)
                  geometry2 IN MDSYS.sdo_geometry)
    RETURN mdsys.sdo_geometry DETERMINISTIC PARALLEL_ENABLE;
    RETURN mdsys.sdo_geometry DETERMINISTIC PARALLEL_ENABLE;
    PRAGMA restrict_references(append, wnds, wnps);
    PRAGMA restrict_references(append, wnds, wnps);


  FUNCTION ExtractVoids(geometry IN mdsys.sdo_geometry,
  FUNCTION ExtractVoids(geometry IN mdsys.sdo_geometry,
                        dim      IN mdsys.sdo_dim_array)
                        dim      IN mdsys.sdo_dim_array)
    RETURN mdsys.sdo_geometry DETERMINISTIC PARALLEL_ENABLE;
    RETURN mdsys.sdo_geometry DETERMINISTIC PARALLEL_ENABLE;
    PRAGMA restrict_references(ExtractVoids, rnds, wnds, rnps, wnps, trust);
    PRAGMA restrict_references(ExtractVoids, rnds, wnds, rnps, wnps, trust);


 FUNCTION GetVertices(
 FUNCTION GetVertices(
   geometry IN mdsys.sdo_geometry,
   geometry IN mdsys.sdo_geometry,
   include_oriented_pt IN number default 0)
   include_oriented_pt IN number default 0)
 RETURN mdsys.vertex_set_type;
 RETURN mdsys.vertex_set_type;
-- PRAGMA restrict_references(GetVertices, wnds, rnps, wnps);
-- PRAGMA restrict_references(GetVertices, wnds, rnps, wnps);


 FUNCTION GetFirstVertex(
 FUNCTION GetFirstVertex(
   geometry IN mdsys.sdo_geometry,
   geometry IN mdsys.sdo_geometry,
   include_oriented_pt IN number default 0)
   include_oriented_pt IN number default 0)
 RETURN mdsys.vertex_type;
 RETURN mdsys.vertex_type;
-- PRAGMA restrict_references(GetVertices, wnds, rnps, wnps);
-- PRAGMA restrict_references(GetVertices, wnds, rnps, wnps);


 FUNCTION GetLastVertex(
 FUNCTION GetLastVertex(
   geometry IN mdsys.sdo_geometry,
   geometry IN mdsys.sdo_geometry,
   include_oriented_pt IN number default 0)
   include_oriented_pt IN number default 0)
 RETURN mdsys.vertex_type;
 RETURN mdsys.vertex_type;
-- PRAGMA restrict_references(GetVertices, wnds, rnps, wnps);
-- PRAGMA restrict_references(GetVertices, wnds, rnps, wnps);


  FUNCTION GetNumElem(geometry IN mdsys.sdo_geometry)
  FUNCTION GetNumElem(geometry IN mdsys.sdo_geometry)
    RETURN NUMBER DETERMINISTIC PARALLEL_ENABLE;
    RETURN NUMBER DETERMINISTIC PARALLEL_ENABLE;
    PRAGMA restrict_references(GetNumElem, rnds, wnds, rnps, wnps, trust);
    PRAGMA restrict_references(GetNumElem, rnds, wnds, rnps, wnps, trust);


  FUNCTION GetNumRings(
  FUNCTION GetNumRings(
    geom IN MDSYS.SDO_GEOMETRY)
    geom IN MDSYS.SDO_GEOMETRY)
      RETURN NUMBER DETERMINISTIC PARALLEL_ENABLE;
      RETURN NUMBER DETERMINISTIC PARALLEL_ENABLE;
  PRAGMA restrict_references(GetNumRings, rnds, wnds, rnps, wnps, trust);
  PRAGMA restrict_references(GetNumRings, rnds, wnds, rnps, wnps, trust);


  FUNCTION GetNumVertices(geometry IN mdsys.sdo_geometry)
  FUNCTION GetNumVertices(geometry IN mdsys.sdo_geometry)
    RETURN NUMBER DETERMINISTIC PARALLEL_ENABLE;
    RETURN NUMBER DETERMINISTIC PARALLEL_ENABLE;
    PRAGMA restrict_references(GetNumVertices, rnds, wnds, rnps, wnps, trust);
    PRAGMA restrict_references(GetNumVertices, rnds, wnds, rnps, wnps, trust);


  FUNCTION OuterLn(geometry IN mdsys.sdo_geometry,
  FUNCTION OuterLn(geometry IN mdsys.sdo_geometry,
                   dim      IN mdsys.sdo_dim_array)
                   dim      IN mdsys.sdo_dim_array)
    RETURN mdsys.sdo_geometry DETERMINISTIC PARALLEL_ENABLE;
    RETURN mdsys.sdo_geometry DETERMINISTIC PARALLEL_ENABLE;
    PRAGMA restrict_references(OuterLn,rnds,wnds,rnps,wnps,trust);
    PRAGMA restrict_references(OuterLn,rnds,wnds,rnps,wnps,trust);


  FUNCTION RefineMGon(mgon IN mdsys.sdo_geometry,
  FUNCTION RefineMGon(mgon IN mdsys.sdo_geometry,
                      gon  IN mdsys.sdo_geometry,
                      gon  IN mdsys.sdo_geometry,
                      dim  IN mdsys.sdo_dim_array)
                      dim  IN mdsys.sdo_dim_array)
    RETURN mdsys.sdo_geometry;
    RETURN mdsys.sdo_geometry;
    PRAGMA restrict_references(RefineMGon,rnds,wnds,rnps,wnps,trust);
    PRAGMA restrict_references(RefineMGon,rnds,wnds,rnps,wnps,trust);


 -- Determine whether or not a string contains a valid numeric value.
 -- Determine whether or not a string contains a valid numeric value.
 FUNCTION mdutl_is_numeric(instr varchar2,
 FUNCTION mdutl_is_numeric(instr varchar2,
                           format_mask varchar2)
                           format_mask varchar2)
 RETURN number DETERMINISTIC PARALLEL_ENABLE;
 RETURN number DETERMINISTIC PARALLEL_ENABLE;
 PRAGMA restrict_references(mdutl_is_numeric, wnds, rnps, wnps, trust);
 PRAGMA restrict_references(mdutl_is_numeric, wnds, rnps, wnps, trust);


 -- Safely convert "number" to corresponding "character" representation
 -- Safely convert "number" to corresponding "character" representation
 -- For more information on this function, please refer to the PL/SQL
 -- For more information on this function, please refer to the PL/SQL
 -- documentation for the TO_CHAR() function.
 -- documentation for the TO_CHAR() function.
 FUNCTION number_to_char(value IN NUMBER,
 FUNCTION number_to_char(value IN NUMBER,
                         format_mask IN VARCHAR2 DEFAULT NULL,
                         format_mask IN VARCHAR2 DEFAULT NULL,
                         nls_language IN VARCHAR2 DEFAULT NULL)
                         nls_language IN VARCHAR2 DEFAULT NULL)
    RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;
    RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;
 PRAGMA restrict_references(number_to_char, wnds, rnps, wnps, trust);
 PRAGMA restrict_references(number_to_char, wnds, rnps, wnps, trust);


 FUNCTION number_to_char(value IN VARCHAR2,
 FUNCTION number_to_char(value IN VARCHAR2,
                         format_mask IN VARCHAR2 DEFAULT NULL,
                         format_mask IN VARCHAR2 DEFAULT NULL,
                         nls_language IN VARCHAR2 DEFAULT NULL)
                         nls_language IN VARCHAR2 DEFAULT NULL)
    RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;
    RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;
 PRAGMA restrict_references(number_to_char, wnds, rnps, wnps, trust);
 PRAGMA restrict_references(number_to_char, wnds, rnps, wnps, trust);


 FUNCTION number_to_char(value IN DATE,
 FUNCTION number_to_char(value IN DATE,
                         format_mask IN VARCHAR2 DEFAULT NULL,
                         format_mask IN VARCHAR2 DEFAULT NULL,
                         option_setting IN VARCHAR2 DEFAULT NULL)
                         option_setting IN VARCHAR2 DEFAULT NULL)
    RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;
    RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;
 PRAGMA restrict_references(number_to_char, wnds, rnps, wnps, trust);
 PRAGMA restrict_references(number_to_char, wnds, rnps, wnps, trust);


 FUNCTION number_to_char(value IN TIMESTAMP,
 FUNCTION number_to_char(value IN TIMESTAMP,
                         format_mask IN VARCHAR2 DEFAULT NULL,
                         format_mask IN VARCHAR2 DEFAULT NULL,
                         option_setting IN VARCHAR2 DEFAULT NULL)
                         option_setting IN VARCHAR2 DEFAULT NULL)
    RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;
    RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;
 PRAGMA restrict_references(number_to_char, wnds, rnps, wnps, trust);
 PRAGMA restrict_references(number_to_char, wnds, rnps, wnps, trust);


 FUNCTION number_to_char(value IN RAW)
 FUNCTION number_to_char(value IN RAW)
    RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;
    RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;
 PRAGMA restrict_references(number_to_char, wnds, rnps, wnps, trust);
 PRAGMA restrict_references(number_to_char, wnds, rnps, wnps, trust);


 FUNCTION number_to_char(value IN CLOB) -- NTEXT
 FUNCTION number_to_char(value IN CLOB) -- NTEXT
    RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;
    RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;
 PRAGMA restrict_references(number_to_char, wnds, rnps, wnps, trust);
 PRAGMA restrict_references(number_to_char, wnds, rnps, wnps, trust);


 -- truncate the original number up to no_of_digits
 -- truncate the original number up to no_of_digits
 -- no_of_digits positive:  truncate the number to no_of_digits AFTER the decimal point
 -- no_of_digits positive:  truncate the number to no_of_digits AFTER the decimal point
 -- ex: truncate_number(1.123456789,5) returns 1.12345
 -- ex: truncate_number(1.123456789,5) returns 1.12345
 -- no_of_digits negative:  truncate the number up to no_of_digits BEFORE the decimal point
 -- no_of_digits negative:  truncate the number up to no_of_digits BEFORE the decimal point
 -- ex: truncate_number(987654321.123456789,-5) returns 987600000.0
 -- ex: truncate_number(987654321.123456789,-5) returns 987600000.0


 FUNCTION truncate_number(value NUMBER, no_of_digits NUMBER)
 FUNCTION truncate_number(value NUMBER, no_of_digits NUMBER)
    RETURN NUMBER PARALLEL_ENABLE;
    RETURN NUMBER PARALLEL_ENABLE;
 PRAGMA restrict_references(truncate_number, wnds, rnps, wnps);
 PRAGMA restrict_references(truncate_number, wnds, rnps, wnps);


 FUNCTION rectify_geometry(
 FUNCTION rectify_geometry(
    geometry     IN MDSYS.SDO_GEOMETRY,
    geometry     IN MDSYS.SDO_GEOMETRY,
    tolerance    IN NUMBER)
    tolerance    IN NUMBER)
   RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
   RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
   PRAGMA RESTRICT_REFERENCES(rectify_geometry, rnds, wnds, rnps, wnps, trust);
   PRAGMA RESTRICT_REFERENCES(rectify_geometry, rnds, wnds, rnps, wnps, trust);


  /* simplify a geometry */
  /* simplify a geometry */
  FUNCTION simplify(
  FUNCTION simplify(
   geometry       IN mdsys.sdo_geometry,
   geometry       IN mdsys.sdo_geometry,
   threshold      IN NUMBER,
   threshold      IN NUMBER,
   tolerance      IN NUMBER := 0.0000005,
   tolerance      IN NUMBER := 0.0000005,
   remove_loops   IN NUMBER := 0)
   remove_loops   IN NUMBER := 0)
    RETURN mdsys.sdo_geometry DETERMINISTIC PARALLEL_ENABLE;
    RETURN mdsys.sdo_geometry DETERMINISTIC PARALLEL_ENABLE;
    PRAGMA restrict_references(simplify, rnds, wnds, rnps, wnps, trust);
    PRAGMA restrict_references(simplify, rnds, wnds, rnps, wnps, trust);


  FUNCTION simplifyVW(
  FUNCTION simplifyVW(
   geometry       IN mdsys.sdo_geometry,
   geometry       IN mdsys.sdo_geometry,
   vertex_threshold  IN NUMBER,
   vertex_threshold  IN NUMBER,
   tolerance      IN NUMBER := 0.0000005,
   tolerance      IN NUMBER := 0.0000005,
   remove_loops   IN NUMBER := 0)
   remove_loops   IN NUMBER := 0)
    RETURN mdsys.sdo_geometry DETERMINISTIC PARALLEL_ENABLE;
    RETURN mdsys.sdo_geometry DETERMINISTIC PARALLEL_ENABLE;
    PRAGMA restrict_references(simplifyVW, rnds, wnds, rnps, wnps, trust);
    PRAGMA restrict_references(simplifyVW, rnds, wnds, rnps, wnps, trust);




 FUNCTION polygontoline(geometry IN mdsys.sdo_geometry)
 FUNCTION polygontoline(geometry IN mdsys.sdo_geometry)
    return MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
    return MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION point_to_line(
 FUNCTION point_to_line(
   geom1 IN mdsys.sdo_geometry,
   geom1 IN mdsys.sdo_geometry,
   geom2 IN mdsys.sdo_geometry,
   geom2 IN mdsys.sdo_geometry,
   tol   IN number := 10e-16)
   tol   IN number := 10e-16)
   RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
   RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION remove_duplicates(geometry IN mdsys.sdo_geometry, dim in mdsys.sdo_dim_array)
 FUNCTION remove_duplicates(geometry IN mdsys.sdo_geometry, dim in mdsys.sdo_dim_array)
    return MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
    return MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION remove_duplicate_vertices(geometry IN mdsys.sdo_geometry,
 FUNCTION remove_duplicate_vertices(geometry IN mdsys.sdo_geometry,
                                                tolerance in NUMBER)
                                                tolerance in NUMBER)
    return MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
    return MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION circle_polygon (point                           MDSYS.SDO_GEOMETRY,
 FUNCTION circle_polygon (point                           MDSYS.SDO_GEOMETRY,
                          radius                          number,
                          radius                          number,
                          arc_tolerance                   number,
                          arc_tolerance                   number,
                          start_azimuth                   number default NULL,
                          start_azimuth                   number default NULL,
                          end_azimuth                     number default NULL,
                          end_azimuth                     number default NULL,
                          orientation                     number default NULL,
                          orientation                     number default NULL,
                          arc                             number default NULL)
                          arc                             number default NULL)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION circle_polygon (center_longitude     number,
 FUNCTION circle_polygon (center_longitude     number,
                          center_latitude      number,
                          center_latitude      number,
                          radius               number,
                          radius               number,
                          arc_tolerance            number)
                          arc_tolerance            number)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION circle_polygon (center_longitude     number,
 FUNCTION circle_polygon (center_longitude     number,
                          center_latitude      number,
                          center_latitude      number,
                          radius               number,
                          radius               number,
                          start_azimuth        number,
                          start_azimuth        number,
                          end_azimuth          number,
                          end_azimuth          number,
                          arc_tolerance            number)
                          arc_tolerance            number)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION ellipse_polygon (center_longitude                number,
 FUNCTION ellipse_polygon (center_longitude                number,
                           center_latitude                 number,
                           center_latitude                 number,
                           semi_major_axis                 number,
                           semi_major_axis                 number,
                           semi_minor_axis                 number,
                           semi_minor_axis                 number,
                           azimuth                         number,
                           azimuth                         number,
                           arc_tolerance                       number)
                           arc_tolerance                       number)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION point_at_bearing(start_point mdsys.sdo_geometry,
 FUNCTION point_at_bearing(start_point mdsys.sdo_geometry,
                   bearing number,
                   bearing number,
                   distance number)
                   distance number)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 PROCEDURE bearing_tilt_for_points(
 PROCEDURE bearing_tilt_for_points(
                   start_point mdsys.sdo_geometry,
                   start_point mdsys.sdo_geometry,
                   end_point mdsys.sdo_geometry,
                   end_point mdsys.sdo_geometry,
                   tol number,
                   tol number,
                   bearing OUT number,
                   bearing OUT number,
                   tilt OUT number) ;
                   tilt OUT number) ;


 FUNCTION convert_unit(value NUMBER, in_unit varchar2, out_unit varchar2)
 FUNCTION convert_unit(value NUMBER, in_unit varchar2, out_unit varchar2)
 RETURN number PARALLEL_ENABLE;
 RETURN number PARALLEL_ENABLE;


 FUNCTION convert_distance(srid  number, distance NUMBER, unit_spec  varchar2)
 FUNCTION convert_distance(srid  number, distance NUMBER, unit_spec  varchar2)
 RETURN number PARALLEL_ENABLE;
 RETURN number PARALLEL_ENABLE;


 PROCEDURE Prepare_For_TTS (table_space IN VARCHAR2);
 PROCEDURE Prepare_For_TTS (table_space IN VARCHAR2);


 PROCEDURE Initialize_Indexes_For_TTS ;
 PROCEDURE Initialize_Indexes_For_TTS ;


 FUNCTION to_clob(Geometry IN MDSYS.SDO_GEOMETRY)
 FUNCTION to_clob(Geometry IN MDSYS.SDO_GEOMETRY)
  RETURN CLOB DETERMINISTIC PARALLEL_ENABLE;
  RETURN CLOB DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION from_clob(ClobGeom IN CLOB)
 FUNCTION from_clob(ClobGeom IN CLOB)
  RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
  RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION to_gmlgeometry(Geometry IN MDSYS.SDO_GEOMETRY)
 FUNCTION to_gmlgeometry(Geometry IN MDSYS.SDO_GEOMETRY)
 RETURN CLOB DETERMINISTIC  PARALLEL_ENABLE;
 RETURN CLOB DETERMINISTIC  PARALLEL_ENABLE;


 FUNCTION to_gmlgeometry(Geometry IN MDSYS.SDO_GEOMETRY,
 FUNCTION to_gmlgeometry(Geometry IN MDSYS.SDO_GEOMETRY,
                            srsNameSpace IN varchar2, srsNSAlias IN varchar2)
                            srsNameSpace IN varchar2, srsNSAlias IN varchar2)
 RETURN CLOB DETERMINISTIC  PARALLEL_ENABLE;
 RETURN CLOB DETERMINISTIC  PARALLEL_ENABLE;


 FUNCTION to_gmlgeometry(Geometry IN MDSYS.SDO_GEOMETRY,
 FUNCTION to_gmlgeometry(Geometry IN MDSYS.SDO_GEOMETRY,
                         coordOrder IN number)
                         coordOrder IN number)
 RETURN CLOB DETERMINISTIC  PARALLEL_ENABLE;
 RETURN CLOB DETERMINISTIC  PARALLEL_ENABLE;


 FUNCTION to_gmlgeometry(Geometry IN MDSYS.SDO_GEOMETRY,
 FUNCTION to_gmlgeometry(Geometry IN MDSYS.SDO_GEOMETRY,
                         srsNameSpace IN varchar2, srsNSAlias IN varchar2,
                         srsNameSpace IN varchar2, srsNSAlias IN varchar2,
                         coordOrder IN number)
                         coordOrder IN number)
 RETURN CLOB DETERMINISTIC  PARALLEL_ENABLE;
 RETURN CLOB DETERMINISTIC  PARALLEL_ENABLE;


 FUNCTION to_gml311geometry(Geometry IN MDSYS.SDO_GEOMETRY)
 FUNCTION to_gml311geometry(Geometry IN MDSYS.SDO_GEOMETRY)
 RETURN CLOB DETERMINISTIC  PARALLEL_ENABLE;
 RETURN CLOB DETERMINISTIC  PARALLEL_ENABLE;


 FUNCTION to_gml311geometry(Geometry IN MDSYS.SDO_GEOMETRY,
 FUNCTION to_gml311geometry(Geometry IN MDSYS.SDO_GEOMETRY,
                            srsNameSpace IN varchar2, srsNSAlias IN varchar2)
                            srsNameSpace IN varchar2, srsNSAlias IN varchar2)
 RETURN CLOB DETERMINISTIC  PARALLEL_ENABLE;
 RETURN CLOB DETERMINISTIC  PARALLEL_ENABLE;


 FUNCTION to_gml311geometry(Geometry IN MDSYS.SDO_GEOMETRY,
 FUNCTION to_gml311geometry(Geometry IN MDSYS.SDO_GEOMETRY,
                            coordOrder IN number)
                            coordOrder IN number)
 RETURN CLOB DETERMINISTIC  PARALLEL_ENABLE;
 RETURN CLOB DETERMINISTIC  PARALLEL_ENABLE;


 FUNCTION to_gml311geometry(Geometry IN MDSYS.SDO_GEOMETRY,
 FUNCTION to_gml311geometry(Geometry IN MDSYS.SDO_GEOMETRY,
                            srsNameSpace IN varchar2, srsNSAlias IN varchar2,
                            srsNameSpace IN varchar2, srsNSAlias IN varchar2,
                            coordOrder IN number)
                            coordOrder IN number)
 RETURN CLOB DETERMINISTIC  PARALLEL_ENABLE;
 RETURN CLOB DETERMINISTIC  PARALLEL_ENABLE;


 FUNCTION to_gml321geometry(Geometry IN MDSYS.SDO_GEOMETRY)
 FUNCTION to_gml321geometry(Geometry IN MDSYS.SDO_GEOMETRY)
 RETURN CLOB DETERMINISTIC  PARALLEL_ENABLE;
 RETURN CLOB DETERMINISTIC  PARALLEL_ENABLE;


 FUNCTION to_gml321geometry(Geometry IN MDSYS.SDO_GEOMETRY,
 FUNCTION to_gml321geometry(Geometry IN MDSYS.SDO_GEOMETRY,
                            srsNameSpace IN varchar2, srsNSAlias IN varchar2)
                            srsNameSpace IN varchar2, srsNSAlias IN varchar2)
 RETURN CLOB DETERMINISTIC  PARALLEL_ENABLE;
 RETURN CLOB DETERMINISTIC  PARALLEL_ENABLE;


 FUNCTION to_gml321geometry(Geometry IN MDSYS.SDO_GEOMETRY,
 FUNCTION to_gml321geometry(Geometry IN MDSYS.SDO_GEOMETRY,
                            coordOrder IN number)
                            coordOrder IN number)
 RETURN CLOB DETERMINISTIC  PARALLEL_ENABLE;
 RETURN CLOB DETERMINISTIC  PARALLEL_ENABLE;


 FUNCTION to_gml321geometry(Geometry IN MDSYS.SDO_GEOMETRY,
 FUNCTION to_gml321geometry(Geometry IN MDSYS.SDO_GEOMETRY,
                            srsNameSpace IN varchar2, srsNSAlias IN varchar2,
                            srsNameSpace IN varchar2, srsNSAlias IN varchar2,
                            coordOrder IN number)
                            coordOrder IN number)
 RETURN CLOB DETERMINISTIC  PARALLEL_ENABLE;
 RETURN CLOB DETERMINISTIC  PARALLEL_ENABLE;


 FUNCTION to_kmlgeometry(Geometry IN MDSYS.SDO_GEOMETRY)
 FUNCTION to_kmlgeometry(Geometry IN MDSYS.SDO_GEOMETRY)
 RETURN CLOB DETERMINISTIC  PARALLEL_ENABLE;
 RETURN CLOB DETERMINISTIC  PARALLEL_ENABLE;


 FUNCTION to_wkbgeometry_j(geometry IN MDSYS.SDO_GEOMETRY)
 FUNCTION to_wkbgeometry_j(geometry IN MDSYS.SDO_GEOMETRY)
 RETURN BLOB DETERMINISTIC PARALLEL_ENABLE;
 RETURN BLOB DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION to_wktgeometry_j(geometry IN MDSYS.SDO_GEOMETRY)
 FUNCTION to_wktgeometry_j(geometry IN MDSYS.SDO_GEOMETRY)
 RETURN CLOB DETERMINISTIC PARALLEL_ENABLE;
 RETURN CLOB DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION to_wktgeometry_j_varchar(geometry IN MDSYS.SDO_GEOMETRY)
 FUNCTION to_wktgeometry_j_varchar(geometry IN MDSYS.SDO_GEOMETRY)
 RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;
 RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION from_wkbgeometry(geometry IN BLOB)
 FUNCTION from_wkbgeometry(geometry IN BLOB)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION from_wktgeometry(geometry IN CLOB)
 FUNCTION from_wktgeometry(geometry IN CLOB)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION from_wktgeometry(geometry IN VARCHAR2)
 FUNCTION from_wktgeometry(geometry IN VARCHAR2)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION from_GMLgeometry(geometry IN CLOB)
 FUNCTION from_GMLgeometry(geometry IN CLOB)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION from_GMLgeometry(geometry IN CLOB, srsNameSpace IN varchar2)
 FUNCTION from_GMLgeometry(geometry IN CLOB, srsNameSpace IN varchar2)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION from_GMLgeometry(geometry IN VARCHAR2)
 FUNCTION from_GMLgeometry(geometry IN VARCHAR2)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION from_GMLgeometry(geometry IN VARCHAR2, srsNameSpace IN varchar2)
 FUNCTION from_GMLgeometry(geometry IN VARCHAR2, srsNameSpace IN varchar2)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION from_GMLgeometry(geometry IN CLOB,
 FUNCTION from_GMLgeometry(geometry IN CLOB,
                           coordOrder IN number)
                           coordOrder IN number)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION from_GMLgeometry(geometry IN CLOB, srsNameSpace IN varchar2,
 FUNCTION from_GMLgeometry(geometry IN CLOB, srsNameSpace IN varchar2,
                           coordOrder IN number)
                           coordOrder IN number)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION from_GMLgeometry(geometry IN VARCHAR2,
 FUNCTION from_GMLgeometry(geometry IN VARCHAR2,
                           coordOrder IN number)
                           coordOrder IN number)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION from_GMLgeometry(geometry IN VARCHAR2, srsNameSpace IN varchar2,
 FUNCTION from_GMLgeometry(geometry IN VARCHAR2, srsNameSpace IN varchar2,
                           coordOrder IN number)
                           coordOrder IN number)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION from_GML311geometry(geometry IN CLOB)
 FUNCTION from_GML311geometry(geometry IN CLOB)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION from_GML311geometry(geometry IN CLOB, srsNameSpace IN varchar2)
 FUNCTION from_GML311geometry(geometry IN CLOB, srsNameSpace IN varchar2)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION from_GML311geometry(geometry IN VARCHAR2)
 FUNCTION from_GML311geometry(geometry IN VARCHAR2)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION from_GML311geometry(geometry IN VARCHAR2, srsNameSpace IN varchar2)
 FUNCTION from_GML311geometry(geometry IN VARCHAR2, srsNameSpace IN varchar2)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION from_GML311geometry(geometry IN CLOB,
 FUNCTION from_GML311geometry(geometry IN CLOB,
                              coordOrder IN number)
                              coordOrder IN number)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION from_GML311geometry(geometry IN CLOB, srsNameSpace IN varchar2,
 FUNCTION from_GML311geometry(geometry IN CLOB, srsNameSpace IN varchar2,
                              coordOrder IN number)
                              coordOrder IN number)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION from_GML311geometry(geometry IN VARCHAR2,
 FUNCTION from_GML311geometry(geometry IN VARCHAR2,
                              coordOrder IN number)
                              coordOrder IN number)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION from_GML311geometry(geometry IN VARCHAR2, srsNameSpace IN varchar2,
 FUNCTION from_GML311geometry(geometry IN VARCHAR2, srsNameSpace IN varchar2,
                              coordOrder IN number)
                              coordOrder IN number)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION from_KMLgeometry(geometry IN CLOB)
 FUNCTION from_KMLgeometry(geometry IN CLOB)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION from_KMLgeometry(geometry IN VARCHAR2)
 FUNCTION from_KMLgeometry(geometry IN VARCHAR2)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION from_geojson(geometry IN VARCHAR2, crs IN VARCHAR2 DEFAULT NULL,
 FUNCTION from_geojson(geometry IN VARCHAR2, crs IN VARCHAR2 DEFAULT NULL,
                       srid IN NUMBER DEFAULT 4326)
                       srid IN NUMBER DEFAULT 4326)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION from_geojson(geometry IN CLOB, crs IN VARCHAR2 DEFAULT NULL,
 FUNCTION from_geojson(geometry IN CLOB, crs IN VARCHAR2 DEFAULT NULL,
                       srid IN NUMBER DEFAULT 4326)
                       srid IN NUMBER DEFAULT 4326)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION to_geojson(geometry IN MDSYS.SDO_GEOMETRY)
 FUNCTION to_geojson(geometry IN MDSYS.SDO_GEOMETRY)
 RETURN CLOB DETERMINISTIC  PARALLEL_ENABLE;
 RETURN CLOB DETERMINISTIC  PARALLEL_ENABLE;


 FUNCTION extrude(geometry IN MDSYS.SDO_GEOMETRY,
 FUNCTION extrude(geometry IN MDSYS.SDO_GEOMETRY,
                  grdHeight IN MDSYS.SDO_NUMBER_ARRAY,
                  grdHeight IN MDSYS.SDO_NUMBER_ARRAY,
                  height IN MDSYS.SDO_NUMBER_ARRAY,
                  height IN MDSYS.SDO_NUMBER_ARRAY,
                  cond IN VARCHAR2,
                  cond IN VARCHAR2,
                  tol IN NUMBER)
                  tol IN NUMBER)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION extrude(geometry IN MDSYS.SDO_GEOMETRY,
 FUNCTION extrude(geometry IN MDSYS.SDO_GEOMETRY,
                  grdHeight IN MDSYS.SDO_NUMBER_ARRAY,
                  grdHeight IN MDSYS.SDO_NUMBER_ARRAY,
                  height IN MDSYS.SDO_NUMBER_ARRAY,
                  height IN MDSYS.SDO_NUMBER_ARRAY,
                  tol IN NUMBER,
                  tol IN NUMBER,
                  optional3dSrid IN NUMBER DEFAULT NULL)
                  optional3dSrid IN NUMBER DEFAULT NULL)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;




 FUNCTION affinetransforms(geometry IN MDSYS.SDO_GEOMETRY,
 FUNCTION affinetransforms(geometry IN MDSYS.SDO_GEOMETRY,
                           translation IN VARCHAR2 DEFAULT 'FALSE', tx IN NUMBER DEFAULT 0.0, ty IN NUMBER DEFAULT 0.0, tz IN NUMBER DEFAULT 0.0,
                           translation IN VARCHAR2 DEFAULT 'FALSE', tx IN NUMBER DEFAULT 0.0, ty IN NUMBER DEFAULT 0.0, tz IN NUMBER DEFAULT 0.0,
                           scaling IN VARCHAR2 DEFAULT 'FALSE', Psc1 IN MDSYS.SDO_GEOMETRY DEFAULT NULL, sx IN NUMBER DEFAULT 0.0, sy IN NUMBER DEFAULT 0.0, sz IN NUMBER DEFAULT 0.0,
                           scaling IN VARCHAR2 DEFAULT 'FALSE', Psc1 IN MDSYS.SDO_GEOMETRY DEFAULT NULL, sx IN NUMBER DEFAULT 0.0, sy IN NUMBER DEFAULT 0.0, sz IN NUMBER DEFAULT 0.0,
                           rotation IN VARCHAR2 DEFAULT 'FALSE', P1 IN MDSYS.SDO_GEOMETRY DEFAULT NULL, line1 IN MDSYS.SDO_GEOMETRY DEFAULT NULL, angle IN NUMBER DEFAULT 0.0, dir IN NUMBER DEFAULT -1,
                           rotation IN VARCHAR2 DEFAULT 'FALSE', P1 IN MDSYS.SDO_GEOMETRY DEFAULT NULL, line1 IN MDSYS.SDO_GEOMETRY DEFAULT NULL, angle IN NUMBER DEFAULT 0.0, dir IN NUMBER DEFAULT -1,
                           shearing IN VARCHAR2 DEFAULT 'FALSE', SHxy IN NUMBER DEFAULT 0.0, SHyx IN NUMBER DEFAULT 0.0, SHxz IN NUMBER DEFAULT 0.0, SHzx IN NUMBER DEFAULT 0.0, SHyz IN NUMBER DEFAULT 0.0, SHzy IN NUMBER DEFAULT 0.0,
                           shearing IN VARCHAR2 DEFAULT 'FALSE', SHxy IN NUMBER DEFAULT 0.0, SHyx IN NUMBER DEFAULT 0.0, SHxz IN NUMBER DEFAULT 0.0, SHzx IN NUMBER DEFAULT 0.0, SHyz IN NUMBER DEFAULT 0.0, SHzy IN NUMBER DEFAULT 0.0,
                           reflection IN VARCHAR2 DEFAULT 'FALSE', Pref IN MDSYS.SDO_GEOMETRY DEFAULT NULL, lineR IN MDSYS.SDO_GEOMETRY DEFAULT NULL, dirR IN NUMBER DEFAULT -1, planeR IN VARCHAR2 DEFAULT 'FALSE', n IN MDSYS.SDO_NUMBER_ARRAY DEFAULT NULL, bigD IN MDSYS.SDO_NUMBER_ARRAY DEFAULT NULL)
                           reflection IN VARCHAR2 DEFAULT 'FALSE', Pref IN MDSYS.SDO_GEOMETRY DEFAULT NULL, lineR IN MDSYS.SDO_GEOMETRY DEFAULT NULL, dirR IN NUMBER DEFAULT -1, planeR IN VARCHAR2 DEFAULT 'FALSE', n IN MDSYS.SDO_NUMBER_ARRAY DEFAULT NULL, bigD IN MDSYS.SDO_NUMBER_ARRAY DEFAULT NULL)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION extract3d(geometry IN MDSYS.SDO_GEOMETRY, label IN VARCHAR2)
 FUNCTION extract3d(geometry IN MDSYS.SDO_GEOMETRY, label IN VARCHAR2)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION getlabelbyelement(sourceGeometry IN MDSYS.SDO_GEOMETRY, queryElement IN MDSYS.SDO_GEOMETRY, tol IN NUMBER)
 FUNCTION getlabelbyelement(sourceGeometry IN MDSYS.SDO_GEOMETRY, queryElement IN MDSYS.SDO_GEOMETRY, tol IN NUMBER)
 RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;
 RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION validate_wkbgeometry(geometry IN BLOB)
 FUNCTION validate_wkbgeometry(geometry IN BLOB)
 RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;
 RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION validate_wktgeometry(geometry IN CLOB)
 FUNCTION validate_wktgeometry(geometry IN CLOB)
 RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;
 RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION validate_wktgeometry(geometry IN VARCHAR2)
 FUNCTION validate_wktgeometry(geometry IN VARCHAR2)
 RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;
 RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION concat_lines (geometry1 IN MDSYS.SDO_GEOMETRY,
 FUNCTION concat_lines (geometry1 IN MDSYS.SDO_GEOMETRY,
                        geometry2 IN MDSYS.SDO_GEOMETRY)
                        geometry2 IN MDSYS.SDO_GEOMETRY)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 PROCEDURE internal_ordinate_copy(src IN MDSYS.SDO_ORDINATE_ARRAY,
 PROCEDURE internal_ordinate_copy(src IN MDSYS.SDO_ORDINATE_ARRAY,
                            src_position IN INTEGER,
                            src_position IN INTEGER,
                            dst IN OUT NOCOPY MDSYS.SDO_ORDINATE_ARRAY,
                            dst IN OUT NOCOPY MDSYS.SDO_ORDINATE_ARRAY,
                            dst_position IN INTEGER,
                            dst_position IN INTEGER,
                            length IN INTEGER);
                            length IN INTEGER);


 FUNCTION reverse_linestring(geometry IN MDSYS.SDO_GEOMETRY)
 FUNCTION reverse_linestring(geometry IN MDSYS.SDO_GEOMETRY)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION internal_merge_linestrings(geometry IN MDSYS.SDO_GEOMETRY)
 FUNCTION internal_merge_linestrings(geometry IN MDSYS.SDO_GEOMETRY)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC;


 FUNCTION internal_merge_linestrings(geomArr IN MDSYS.SDO_GEOMETRY_ARRAY)
 FUNCTION internal_merge_linestrings(geomArr IN MDSYS.SDO_GEOMETRY_ARRAY)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC;


 FUNCTION internal_make_line_out_of_elem(
 FUNCTION internal_make_line_out_of_elem(
     multilinestring IN MDSYS.SDO_GEOMETRY, element_index IN INTEGER)
     multilinestring IN MDSYS.SDO_GEOMETRY, element_index IN INTEGER)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 PROCEDURE internal_reverse_line_points(
 PROCEDURE internal_reverse_line_points(
       ordinates IN OUT NOCOPY MDSYS.SDO_ORDINATE_ARRAY);
       ordinates IN OUT NOCOPY MDSYS.SDO_ORDINATE_ARRAY);


------------------------------------------------------------------
------------------------------------------------------------------
-- Name
-- Name
--   Partition_Table
--   Partition_Table
-- Purpose
-- Purpose
--   Partitions the input "schema.tablename" into buckets of at
--   Partitions the input "schema.tablename" into buckets of at
--   most ptn_capacity each. The partitioning is based on the
--   most ptn_capacity each. The partitioning is based on the
--   spatial extent or MBR stored as the intervals <min_di, max_di>
--   spatial extent or MBR stored as the intervals <min_di, max_di>
--   in each dimension di.  The data is written back with
--   in each dimension di.  The data is written back with
--   the ptn_id into the "output_table" which is assumed to be
--   the ptn_id into the "output_table" which is assumed to be
--   be pre-created by the user.
--   be pre-created by the user.
--   The input <tablename> table is expected to have the following columns:
--   The input <tablename> table is expected to have the following columns:
--      "rid" -- unique id for each row (e.g., the table rowid)
--      "rid" -- unique id for each row (e.g., the table rowid)
--      min_d1, max_d1 -- minimum and maximum values in dimension 1
--      min_d1, max_d1 -- minimum and maximum values in dimension 1
--      min_d2, max_d2 -- minimum and maximum values in dimension 2
--      min_d2, max_d2 -- minimum and maximum values in dimension 2
--      ..
--      ..
--      min_dn, max_dn -- minimum and maximum values in dimension n
--      min_dn, max_dn -- minimum and maximum values in dimension n
--      where n is the dimensionality specified by inp arg "numdim"
--      where n is the dimensionality specified by inp arg "numdim"
--   The input "wrk_tblspc" specifies the tablespace where "scratch-pad"
--   The input "wrk_tblspc" specifies the tablespace where "scratch-pad"
--      tables are created and dropped. Keep this tablespace different from
--      tables are created and dropped. Keep this tablespace different from
--      the tablespace in which the input <tablename> and output_table are.
--      the tablespace in which the input <tablename> and output_table are.
--      (typical usage: create wrk_tblspc and drop after this procedure)
--      (typical usage: create wrk_tblspc and drop after this procedure)
--   The arg "output_table" specifies where to write the output partitions
--   The arg "output_table" specifies where to write the output partitions
--     This routine assumes the output_table is pre-created and has the
--     This routine assumes the output_table is pre-created and has the
--     following columns:
--     following columns:
--     ptn_id number, rid varchar2(24), min_d1 number, max_d1 number,
--     ptn_id number, rid varchar2(24), min_d1 number, max_d1 number,
--     min_d2, max_d2, ...., min_dn, max_dn (all number columns).
--     min_d2, max_d2, ...., min_dn, max_dn (all number columns).
--     This routine writes the rows from <tablename> back to <output_table>
--     This routine writes the rows from <tablename> back to <output_table>
--       with the ptn_id set.
--       with the ptn_id set.
--  The arg <output_ptn_table> specifies where to write ptn extent information
--  The arg <output_ptn_table> specifies where to write ptn extent information
--     This table should have the following numeric columns:
--     This table should have the following numeric columns:
--     ptn_id, min_d1, max_d1, min_d2, max_d2, ...., min_dn, max_dn.
--     ptn_id, min_d1, max_d1, min_d2, max_d2, ...., min_dn, max_dn.
--  Parameter "numdim" specifies the number of dimensions.
--  Parameter "numdim" specifies the number of dimensions.
--  Parameter "commit_interval" "n" specifies that commits happen
--  Parameter "commit_interval" "n" specifies that commits happen
--  after every batch of n rows that are written to the <output_table>.
--  after every batch of n rows that are written to the <output_table>.
--  Parameter "packed_ptns" tries to pack the partitions.
--  Parameter "packed_ptns" tries to pack the partitions.


 PROCEDURE partition_table(schemaname in varchar2, tablename in varchar2,
 PROCEDURE partition_table(schemaname in varchar2, tablename in varchar2,
                           output_data_table in varchar2,
                           output_data_table in varchar2,
                           output_ptn_table in varchar2,
                           output_ptn_table in varchar2,
                           ptn_capacity in number default 100,
                           ptn_capacity in number default 100,
                           numdim in number default 2,
                           numdim in number default 2,
                           wrk_tblspc in varchar2 default null,
                           wrk_tblspc in varchar2 default null,
                           ptn_type in varchar2 default null,
                           ptn_type in varchar2 default null,
                           dop in number default 1);
                           dop in number default 1);




------------------------------------------------------------------
------------------------------------------------------------------
-- Name
-- Name
--   DROP_WORK_TABLES
--   DROP_WORK_TABLES
-- Purpose
-- Purpose
--   This function drops any work tables and views in the current schema
--   This function drops any work tables and views in the current schema
--   created as part of partition_table, index creation, or
--   created as part of partition_table, index creation, or
--   TIN/Point Cloud utilities.
--   TIN/Point Cloud utilities.
--
--
--   DROPS all tables/views that match 'M%_<oidstr>$$%'
--   DROPS all tables/views that match 'M%_<oidstr>$$%'
--   Input oidstr has to contain only hexadecimal numbers w/o spaces
--   Input oidstr has to contain only hexadecimal numbers w/o spaces


 PROCEDURE DROP_WORK_TABLES(oidstr varchar2);
 PROCEDURE DROP_WORK_TABLES(oidstr varchar2);


 FUNCTION remove_inner_rings(inpgeom MDSYS.SDO_GEOMETRY, inptol number)
 FUNCTION remove_inner_rings(inpgeom MDSYS.SDO_GEOMETRY, inptol number)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION quad_tiles(geom MDSYS.SDO_GEOMETRY, sdo_level number, tol number:=0.0000000005)
 FUNCTION quad_tiles(geom MDSYS.SDO_GEOMETRY, sdo_level number, tol number:=0.0000000005)
 RETURN mdsys.F81_index_obj_array DETERMINISTIC;
 RETURN mdsys.F81_index_obj_array DETERMINISTIC;


 /* This function generates hybrid tiles for a given Geometry.
 /* This function generates hybrid tiles for a given Geometry.
    Only 2D Geometry is supported.
    Only 2D Geometry is supported.
    The SDO_META values are appended to the SDO_CODE to make it easier
    The SDO_META values are appended to the SDO_CODE to make it easier
    for use with other HHCODE functions. */
    for use with other HHCODE functions. */
 FUNCTION hybrid_tiles(geom MDSYS.SDO_GEOMETRY, sdo_level number := 4,
 FUNCTION hybrid_tiles(geom MDSYS.SDO_GEOMETRY, sdo_level number := 4,
                       sdo_ntiles number := 100, tol number:=0.0000000005)
                       sdo_ntiles number := 100, tol number:=0.0000000005)
 RETURN mdsys.H81_index_obj_array DETERMINISTIC;
 RETURN mdsys.H81_index_obj_array DETERMINISTIC;


 FUNCTION interior_point (geom MDSYS.SDO_GEOMETRY, tol number := 0.00000000005)
 FUNCTION interior_point (geom MDSYS.SDO_GEOMETRY, tol number := 0.00000000005)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION number_of_components(geometry MDSYS.SDO_GEOMETRY, requested_type varchar2)
 FUNCTION number_of_components(geometry MDSYS.SDO_GEOMETRY, requested_type varchar2)
 RETURN NUMBER PARALLEL_ENABLE;
 RETURN NUMBER PARALLEL_ENABLE;


 FUNCTION get_2d_footprint(geometry MDSYS.SDO_GEOMETRY, tolerance number := 0.05)
 FUNCTION get_2d_footprint(geometry MDSYS.SDO_GEOMETRY, tolerance number := 0.05)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION convert3007to3008(geometry mdsys.sdo_geometry)
 FUNCTION convert3007to3008(geometry mdsys.sdo_geometry)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 -- Returns coordinate of a single element geometry.
 -- Returns coordinate of a single element geometry.
 -- If coord_index is 0 (or too large), returns the last point in
 -- If coord_index is 0 (or too large), returns the last point in
 -- the single element geometry.
 -- the single element geometry.
 FUNCTION get_coordinate(geometry in mdsys.sdo_geometry,
 FUNCTION get_coordinate(geometry in mdsys.sdo_geometry,
                         coord_index in number)
                         coord_index in number)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION get_boundary(geometry  in mdsys.sdo_geometry)
 FUNCTION get_boundary(geometry  in mdsys.sdo_geometry)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
-------------------------------------------------------------------------
-------------------------------------------------------------------------


  function validate_3dtheme(
  function validate_3dtheme(
    theme_name varchar2)
    theme_name varchar2)
      return varchar2;
      return varchar2;


  function validate_scene(
  function validate_scene(
    scene_name varchar2)
    scene_name varchar2)
      return varchar2;
      return varchar2;


  function validate_viewframe(
  function validate_viewframe(
    viewframe_name varchar2)
    viewframe_name varchar2)
      return varchar2;
      return varchar2;


  function theme3d_has_lod(
  function theme3d_has_lod(
    theme_name varchar2)
    theme_name varchar2)
      return number;
      return number;


  procedure theme3d_create_texture_tables(
  procedure theme3d_create_texture_tables(
    texture_table_base_name varchar2);
    texture_table_base_name varchar2);


  procedure theme3d_add_ref_to_tex_tables(
  procedure theme3d_add_ref_to_tex_tables(
    feature_table           varchar2,
    feature_table           varchar2,
    feature_table_tex_col   varchar2,
    feature_table_tex_col   varchar2,
    texture_table_base_name varchar2);
    texture_table_base_name varchar2);


  procedure theme3d_add_face_texture(
  procedure theme3d_add_face_texture(
    texture_table_base_name varchar2,
    texture_table_base_name varchar2,
    texture_id              varchar2,
    texture_id              varchar2,
    theme                   varchar2,
    theme                   varchar2,
    face_num                integer,
    face_num                integer,
    color_rgb_hex           varchar2,
    color_rgb_hex           varchar2,
    texture_bitmap_id       varchar2,
    texture_bitmap_id       varchar2,
    texture_coord_array_id  varchar2);
    texture_coord_array_id  varchar2);


  procedure theme3d_add_face_textures(
  procedure theme3d_add_face_textures(
    texture_table_base_name varchar2,
    texture_table_base_name varchar2,
    texture_id              varchar2,
    texture_id              varchar2,
    theme                   varchar2,
    theme                   varchar2,
    colors_rgb_hex          mdsys.sdo_string_array,
    colors_rgb_hex          mdsys.sdo_string_array,
    texture_bitmap_ids      mdsys.sdo_ordinate_array,
    texture_bitmap_ids      mdsys.sdo_ordinate_array,
    texture_coord_array_ids mdsys.sdo_ordinate_array);
    texture_coord_array_ids mdsys.sdo_ordinate_array);


  procedure theme3d_add_bitmap(
  procedure theme3d_add_bitmap(
    texture_table_base_name varchar2,
    texture_table_base_name varchar2,
    texture_bitmap_id       varchar2,
    texture_bitmap_id       varchar2,
    bitmap                  blob,
    bitmap                  blob,
    url                     varchar2);
    url                     varchar2);


  procedure theme3d_add_texture_coords(
  procedure theme3d_add_texture_coords(
    texture_table_base_name varchar2,
    texture_table_base_name varchar2,
    texture_coord_array_id  varchar2,
    texture_coord_array_id  varchar2,
    texture_coord_array     mdsys.sdo_ordinate_array);
    texture_coord_array     mdsys.sdo_ordinate_array);


  function theme3d_has_texture(
  function theme3d_has_texture(
    theme_name varchar2)
    theme_name varchar2)
      return number;
      return number;


  function theme3d_get_block_table(
  function theme3d_get_block_table(
    theme_name varchar2)
    theme_name varchar2)
      return varchar2;
      return varchar2;


 FUNCTION ToGnomonic(geom in mdsys.sdo_geometry, longitude in number,
 FUNCTION ToGnomonic(geom in mdsys.sdo_geometry, longitude in number,
                     latitude in number)
                     latitude in number)
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;
 RETURN MDSYS.SDO_GEOMETRY DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION getNurbsApprox(geometry  IN mdsys.sdo_geometry,
 FUNCTION getNurbsApprox(geometry  IN mdsys.sdo_geometry,
                         tolerance IN number)
                         tolerance IN number)
 RETURN mdsys.sdo_geometry DETERMINISTIC PARALLEL_ENABLE;
 RETURN mdsys.sdo_geometry DETERMINISTIC PARALLEL_ENABLE;
 PRAGMA restrict_references(getNurbsApprox, rnds, wnds, rnps, wnps, trust);
 PRAGMA restrict_references(getNurbsApprox, rnds, wnds, rnps, wnps, trust);


 FUNCTION jsph_getnurbsapprox(geometry  IN mdsys.sdo_geometry)
 FUNCTION jsph_getnurbsapprox(geometry  IN mdsys.sdo_geometry)
 RETURN mdsys.sdo_geometry DETERMINISTIC PARALLEL_ENABLE;
 RETURN mdsys.sdo_geometry DETERMINISTIC PARALLEL_ENABLE;
 PRAGMA restrict_references(jsph_getnurbsapprox, rnds, wnds, rnps, wnps, trust);
 PRAGMA restrict_references(jsph_getnurbsapprox, rnds, wnds, rnps, wnps, trust);


 FUNCTION linear_key(geometry  IN mdsys.sdo_geometry,
 FUNCTION linear_key(geometry  IN mdsys.sdo_geometry,
                     diminfo mdsys.sdo_dim_array,
                     diminfo mdsys.sdo_dim_array,
                     lvl IN NUMBER := 8)
                     lvl IN NUMBER := 8)
 RETURN RAW DETERMINISTIC PARALLEL_ENABLE;
 RETURN RAW DETERMINISTIC PARALLEL_ENABLE;


 FUNCTION linear_key(geometry  IN mdsys.sdo_geometry,
 FUNCTION linear_key(geometry  IN mdsys.sdo_geometry,
                     min_x IN NUMBER, min_y IN NUMBER,
                     min_x IN NUMBER, min_y IN NUMBER,
                     max_x IN NUMBER, max_y IN NUMBER,
                     max_x IN NUMBER, max_y IN NUMBER,
                     lvl IN NUMBER := 8)
                     lvl IN NUMBER := 8)
 RETURN RAW DETERMINISTIC PARALLEL_ENABLE;
 RETURN RAW DETERMINISTIC PARALLEL_ENABLE;


 /* documented metadata management routines.
 /* documented metadata management routines.
    Assumption is that anyone can create the metadata for anyone
    Assumption is that anyone can create the metadata for anyone
    else. We can assume that this is not a risk as data is created,
    else. We can assume that this is not a risk as data is created,
    and can always be changed by the owner of the table if the metadata
    and can always be changed by the owner of the table if the metadata
    is not correct.
    is not correct.
 */
 */
 procedure insert_sdo_geom_metadata(owner IN VARCHAR2,
 procedure insert_sdo_geom_metadata(owner IN VARCHAR2,
                                    table_name IN VARCHAR2,
                                    table_name IN VARCHAR2,
                                    column_name IN VARCHAR2,
                                    column_name IN VARCHAR2,
                                    diminfo IN mdsys.sdo_dim_array,
                                    diminfo IN mdsys.sdo_dim_array,
                                    srid IN number);
                                    srid IN number);


 /* We only allow the OWNER, or any user with DBA privs, or
 /* We only allow the OWNER, or any user with DBA privs, or
    any user who has SELECT or INDEX privis on the table_name
    any user who has SELECT or INDEX privis on the table_name
    can delete the metadata from a difference schema.
    can delete the metadata from a difference schema.
    This is done so that a disruptive user cannot do denial of service
    This is done so that a disruptive user cannot do denial of service
    by continously removing metadata for other tables, there by disabling
    by continously removing metadata for other tables, there by disabling
    spatial functionality like operators and indexes on these tables.
    spatial functionality like operators and indexes on these tables.
 */
 */
 procedure delete_sdo_geom_metadata(owner IN VARCHAR2,
 procedure delete_sdo_geom_metadata(owner IN VARCHAR2,
                                    table_name IN VARCHAR2,
                                    table_name IN VARCHAR2,
                                    column_name IN VARCHAR2);
                                    column_name IN VARCHAR2);






--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
-- Calculate 3D Geodetic Triangle area with LTP.
-- Calculate 3D Geodetic Triangle area with LTP.
-- When the input geometry is 3D Geodetic triangle without inner ring(s),
-- When the input geometry is 3D Geodetic triangle without inner ring(s),
-- prefer to use this function instead of sdo_area function since it is more
-- prefer to use this function instead of sdo_area function since it is more
-- simplified algorithm due to considering only 3D Geodetic triangle geometry.
-- simplified algorithm due to considering only 3D Geodetic triangle geometry.
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
 function sdo_3dtriangle_area
 function sdo_3dtriangle_area
 (
 (
    geom IN MDSYS.SDO_GEOMETRY,
    geom IN MDSYS.SDO_GEOMETRY,
    dim  IN MDSYS.SDO_DIM_ARRAY,
    dim  IN MDSYS.SDO_DIM_ARRAY,
    unit IN VARCHAR2 DEFAULT NULL
    unit IN VARCHAR2 DEFAULT NULL
 )
 )
 return NUMBER DETERMINISTIC PARALLEL_ENABLE;
 return NUMBER DETERMINISTIC PARALLEL_ENABLE;




--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
-- Calculate 3D Geodetic Triangle area with LTP.
-- Calculate 3D Geodetic Triangle area with LTP.
-- When the input geometry is 3D Geodetic triangle without inner ring(s),
-- When the input geometry is 3D Geodetic triangle without inner ring(s),
-- prefer to use this function instead of sdo_area function since it is more
-- prefer to use this function instead of sdo_area function since it is more
-- simplified algorithm due to considering only 3D Geodetic triangle geometry.
-- simplified algorithm due to considering only 3D Geodetic triangle geometry.
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
 function sdo_3dtriangle_area
 function sdo_3dtriangle_area
 (
 (
    geom IN MDSYS.SDO_GEOMETRY,
    geom IN MDSYS.SDO_GEOMETRY,
    tol  IN NUMBER,
    tol  IN NUMBER,
    unit IN VARCHAR2 DEFAULT NULL
    unit IN VARCHAR2 DEFAULT NULL
 )
 )
 return NUMBER DETERMINISTIC PARALLEL_ENABLE;
 return NUMBER DETERMINISTIC PARALLEL_ENABLE;


 PROCEDURE process_auxiliary_info(
 PROCEDURE process_auxiliary_info(
   auxiliary_info IN     varchar2,
   auxiliary_info IN     varchar2,
   input_type     IN OUT varchar2,
   input_type     IN OUT varchar2,
   srsNameSpace   IN OUT varchar2,
   srsNameSpace   IN OUT varchar2,
   coordOrder     IN OUT number,
   coordOrder     IN OUT number,
   srid           IN OUT integer);
   srid           IN OUT integer);




--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
-- Validate XML instance against its schema
-- Validate XML instance against its schema
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
 FUNCTION validate_xml_record
 FUNCTION validate_xml_record
 (
 (
    xml IN CLOB,
    xml IN CLOB,
    schema IN varchar2
    schema IN varchar2
 )
 )
 return VARCHAR2 DETERMINISTIC  PARALLEL_ENABLE;
 return VARCHAR2 DETERMINISTIC  PARALLEL_ENABLE;






--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
-- Validate all XML instances in a table with XMLType column against its schema
-- Validate all XML instances in a table with XMLType column against its schema
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
 PROCEDURE validate_xml_layer
 PROCEDURE validate_xml_layer
 (
 (
    table_name        IN varchar2,
    table_name        IN varchar2,
    column_name       IN varchar2,
    column_name       IN varchar2,
    schema            IN varchar2,
    schema            IN varchar2,
    result_table_name IN varchar2,
    result_table_name IN varchar2,
    commit_interval   IN number := -1,
    commit_interval   IN number := -1,
    owner             IN varchar2 DEFAULT NULL
    owner             IN varchar2 DEFAULT NULL
 ) ;
 ) ;


-- used for functional cbtree index on point
-- used for functional cbtree index on point
 FUNCTION get_point_ordinate
 FUNCTION get_point_ordinate
 (
 (
    geometry IN mdsys.sdo_geometry,
    geometry IN mdsys.sdo_geometry,
    pos      IN number
    pos      IN number
 )
 )
 return number DETERMINISTIC  PARALLEL_ENABLE;
 return number DETERMINISTIC  PARALLEL_ENABLE;


-- used to densify a geometry with default interval=5000, for geodetic
-- used to densify a geometry with default interval=5000, for geodetic
-- geometry, it will be 5000 meters.
-- geometry, it will be 5000 meters.
 FUNCTION densify_geometry
 FUNCTION densify_geometry
 (
 (
    geometry IN mdsys.sdo_geometry,
    geometry IN mdsys.sdo_geometry,
    interval IN number default 5000
    interval IN number default 5000
 )
 )
 return mdsys.sdo_geometry DETERMINISTIC  PARALLEL_ENABLE;
 return mdsys.sdo_geometry DETERMINISTIC  PARALLEL_ENABLE;


-- Geo Search API
-- Geo Search API
 FUNCTION GEO_SEARCH
 FUNCTION GEO_SEARCH
 (
 (
    name  in varchar2,
    name  in varchar2,
    fuzzy   in number default null
    fuzzy   in number default null
 )
 )
 return MDSYS.sdo_geo_search_table PIPELINED;
 return MDSYS.sdo_geo_search_table PIPELINED;


 -- HHCELL BOUNDARY
 -- HHCELL BOUNDARY
 FUNCTION HHCELL_BOUNDARY
 FUNCTION HHCELL_BOUNDARY
 (
 (
    linear_key in raw,
    linear_key in raw,
    min_x      in number,
    min_x      in number,
    min_y      in number,
    min_y      in number,
    max_x      in number,
    max_x      in number,
    max_y      in number
    max_y      in number
 )
 )
 return mdsys.sdo_geometry DETERMINISTIC  PARALLEL_ENABLE;
 return mdsys.sdo_geometry DETERMINISTIC  PARALLEL_ENABLE;


  FUNCTION is_simple_file_name(file_name IN VARCHAR2)
  FUNCTION is_simple_file_name(file_name IN VARCHAR2)
    RETURN VARCHAR2;
    RETURN VARCHAR2;


  FUNCTION SPLIT_180_MERIDIAN
  FUNCTION SPLIT_180_MERIDIAN
  (
  (
    geometry IN mdsys.sdo_geometry
    geometry IN mdsys.sdo_geometry
  )
  )
  RETURN mdsys.sdo_geometry  DETERMINISTIC PARALLEL_ENABLE;
  RETURN mdsys.sdo_geometry  DETERMINISTIC PARALLEL_ENABLE;


  function simplify_to_extruded(
  function simplify_to_extruded(
    solid3d MDSYS.sdo_geometry)
    solid3d MDSYS.sdo_geometry)
      return extruded_geom_array DETERMINISTIC PARALLEL_ENABLE;
      return extruded_geom_array DETERMINISTIC PARALLEL_ENABLE;


  procedure simplify_to_extruded(
  procedure simplify_to_extruded(
    table_in_with_3dsolids    varchar2,
    table_in_with_3dsolids    varchar2,
    column_in_with_3dsolids   varchar2,
    column_in_with_3dsolids   varchar2,
    table_out_with_2dpolygons varchar2) DETERMINISTIC PARALLEL_ENABLE;
    table_out_with_2dpolygons varchar2) DETERMINISTIC PARALLEL_ENABLE;


END sdo_util;END sdo_util;
/

