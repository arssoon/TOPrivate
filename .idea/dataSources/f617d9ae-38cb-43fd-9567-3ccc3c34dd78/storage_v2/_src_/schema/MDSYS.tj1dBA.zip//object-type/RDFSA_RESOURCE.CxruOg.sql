create type       rdfsa_resource as object (
  res_id      VARCHAR2(100),
  res_type    NUMBER,
  res_labels  MDSYS.INT_ARRAY,
  constructor function rdfsa_resource (res_id VARCHAR2, res_type number)
                                            return self as result,
  constructor function rdfsa_resource (res_id VARCHAR2,
         res_type number, res_label number) return self as result,
  constructor function rdfsa_resource (res_id VARCHAR2, res_type number,
                res_labels mdsys.int_array) return self as result,
  member function getResource return VARCHAR2,
  member function getLabelCount return number,
  member function getLabel(idx number default 1) return number
)
/

