create TYPE SDO_SMPL_GEOMETRY
TYPE SDO_SMPL_GEOMETRY
                                                                      
                                                                      
AS OBJECT (
AS OBJECT (
        orig_area number,
        orig_area number,
        cur_area number,
        cur_area number,
        orig_len number,
        orig_len number,
        cur_len number,
        cur_len number,
        geometry mdsys.sdo_geometry)         geometry mdsys.sdo_geometry)
/

