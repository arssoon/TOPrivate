create view USER_SDO_INDEX_HISTOGRAM as
select OBJECT_NAME SDO_INDEX_NAME,
        BKT_ID, NUM_MBRS,
        START1, END1, AVGMBRLEN1,
        START2, END2, AVGMBRLEN2,
        START3, END3, AVGMBRLEN3
 from MDSYS.SDO_INDEX_HISTOGRAM_TABLE a, SYS.ALL_OBJECTS b
 where a.sdo_index_objno = b.object_id
   and b.owner = sys_context('userenv', 'CURRENT_USER')
 order by SDO_INDEX_NAME, BKT_ID
/

