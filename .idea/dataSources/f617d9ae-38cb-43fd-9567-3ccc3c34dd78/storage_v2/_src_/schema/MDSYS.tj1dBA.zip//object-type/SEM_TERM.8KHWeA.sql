create type sem_term wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
b2 d6
QpbcmVWO1SCjl3wxqvoMPh0MdcQwgypKmMsVfHTpWPiUv1kaywIkWtbVrJtnStbbiSYLH4+1
6eY4wuLQEPVDUu80PDu8scE5t/eL1ZM3q6ZJpGGIAaLZv4aZXL9gVjgbGb/f7GeQLe0EIiaG
Id5wfoXodQJtjdtU8qAGCaLoaQJXTUz5XLV2qgJInaa3jrn+PykNo/+V2Q4oLAZdVtY=
/

