create TYPE       SDO_INTERACTION AS OBJECT (
        lines             MDSYS.SDO_INTERACT_LINE_FEAT_ARRAY,
        points            MDSYS.SDO_INTERACT_POINT_FEAT_ARRAY,
        intersect_pt_geom MDSYS.SDO_GEOMETRY
       )
/

