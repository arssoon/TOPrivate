create package sem_rdfctx authid current_user as

  procedure create_policy (
              policy_name        VARCHAR2,
              extractor          mdsys.rdfctx_extractor,
              preferences        sys.XMLType default null);

  procedure create_policy (
              policy_name        VARCHAR2,
              base_policy        VARCHAR2);

  procedure create_policy (
              policy_name        VARCHAR2,
              base_policy        VARCHAR2,
              user_models        mdsys.rdf_models,
              rulebases          mdsys.rdf_rulebases default null);

  procedure create_policy (
              policy_name        VARCHAR2,
              base_policy        VARCHAR2,
              user_models        mdsys.rdf_models,
              user_entailments   mdsys.rdf_models,
              rulebases          mdsys.rdf_rulebases default null);

  procedure drop_policy (
              policy_name        VARCHAR2);

  procedure set_default_policy (
              index_name         VARCHAR2,
              policy_name        VARCHAR2);

  procedure add_dependent_policy (
              index_name           VARCHAR2,
              policy_name          VARCHAR2,
              partition_name       VARCHAR2 default NULL);

  function extract_rdfxml (
              doc                CLOB,
              ext_type           mdsys.rdfctx_extractor) return CLOB;

  procedure maintain_triples (
              index_name         VARCHAR2,
              where_clause       VARCHAR2,
              rdfxml_content     sys.XMLType,
              policy_name        VARCHAR2 default NULL,
              action             VARCHAR2 default 'ADD');

  procedure set_extractor_param (
              param_key         VARCHAR2,
              param_value       VARCHAR2,
              param_desc        VARCHAR2);

end sem_rdfctx;
/

