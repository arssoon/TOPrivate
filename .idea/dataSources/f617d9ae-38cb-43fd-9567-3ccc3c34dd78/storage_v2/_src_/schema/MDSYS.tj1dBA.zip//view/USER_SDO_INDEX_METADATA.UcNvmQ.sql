create view USER_SDO_INDEX_METADATA as
select SDO_INDEX_OWNER, SDO_INDEX_TYPE,
        SDO_LEVEL, SDO_NUMTILES, SDO_MAXLEVEL,
        SDO_COMMIT_INTERVAL, SDO_INDEX_TABLE,
        SDO_INDEX_NAME,  SDO_INDEX_PRIMARY,
        SDO_TSNAME, SDO_COLUMN_NAME,
        SDO_RTREE_HEIGHT, SDO_RTREE_NUM_NODES,
        SDO_RTREE_DIMENSIONALITY, SDO_RTREE_FANOUT,
        SDO_RTREE_ROOT, SDO_RTREE_SEQ_NAME,
        SDO_FIXED_META, SDO_TABLESPACE,
        SDO_INITIAL_EXTENT, SDO_NEXT_EXTENT,
        SDO_PCTINCREASE, SDO_MIN_EXTENTS,
        SDO_MAX_EXTENTS, SDO_INDEX_DIMS,
        SDO_LAYER_GTYPE, SDO_RTREE_PCTFREE,
        SDO_INDEX_PARTITION, SDO_PARTITIONED,
        SDO_RTREE_QUALITY, SDO_INDEX_VERSION,
        SDO_INDEX_GEODETIC, SDO_INDEX_STATUS,
        SDO_NL_INDEX_TABLE,
        SDO_DML_BATCH_SIZE, SDO_RTREE_ENT_XPND,
        SDO_NUM_ROWS,                                           --- bug9743250
        SDO_NUM_BLKS,
        SDO_OPTIMIZED_NODES,
        SDO_TABLE_NAME,                                         --- bug21925692
        SDO_ROOT_MBR                                            --- bug2719909
 from MDSYS.SDO_INDEX_METADATA_TABLE
 where
 (exists
   (select index_name from sys.user_indexes
    where index_name=sdo_index_name and
          sdo_index_owner = sys_context('userenv', 'CURRENT_USER')))
/

