create Type proc_msg_pkd as object(arr proc_msg_arr)
/

