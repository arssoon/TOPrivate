create PACKAGE       opg_rank authid current_user
AS
  /**
   * This procedure calculates Page Rank values of the vertices of a given graph (edge table).
   * The page rank values of vertices of the graph will be stored in
   * the table with a name provided in wt_node_pr.
   * This procedure will make use of serveral intermediate working tables including
   * wt_node_nextpr, wt_edge_tab_deg, and wt_delta.
   * The working tables wt_edge_tab_deg, and wt_delta will not be dropped because they
   * can be used to conduct more iterations of PR calculation, if necessary.
   */
  procedure pr(edge_tab_name    varchar2,
               d                number   default 0.85,
               num_iterations   number   default 10,
               convergence      number   default 0.001,
               dop              integer  default 4,
               wt_node_pr       in out varchar2,
               wt_node_nextpr   in out varchar2,
               wt_edge_tab_deg  in out varchar2,
               wt_delta         in out varchar2,
               reuse            integer  default 0,
               tablespace       varchar2 default null,
               options          varchar2 default null,
               num_vertices out number
              );

  procedure ppr(
               graph_name       varchar2,
               d                number   default 0.85,
               nIterations      number   default 10,
               dop              integer  default 4,
               skipInitialStats integer  default 0,
               tablespace       varchar2 default null,
               workingTab       varchar2 default 'pr',
               reuse            integer  default 0,
               preferredBound    number  default 0.1,
               preferredTab     ora_mining_number_nt,
               tabuBound         number  default 0.1,
               tabuTab         ora_mining_number_nt,
               options          varchar2 default null,
               nVertices    out number
              );
END opg_rank;
/

