create package       opg_path  authid current_user
is
  function init_mincost(cost number) return number;
  function set_mincost(cost number) return number;
  function get_mincost return number;
  function set_flag(rid rowid, weight number, flag integer)
           return integer;
  function set_flag(rid rowid, weight number, flag integer, p2s number)
           return integer;
  function get_flag   return integer;
  function get_rowid  return rowid;
  function get_p2s    return number;
  function get_weight return number;
  function get_strategy return varchar2;
  procedure set_strategy (s varchar2);

  procedure find_sp(
                    nSrc             number,
                    nDest            number,
                    expTab           varchar2,
                    guide            number    default null,
                    dop              integer   default 4,
                    skipInitialStats integer   default 1,
                    statsFreq        integer   default 20000,
                    numGraph         varchar2  default null,
                    vcPath       out varchar2,
                    vcWeights    out varchar2,
                    options       in varchar2  default null,
                    scn           in number    default null
                    );
end;
/

