create TYPE       SDO_INTERACT_POINT_FEAT AS OBJECT (
        feature_layer_id   NUMBER,
        feature_id         NUMBER,
        feature_class_id   NUMBER,
        node_id            NUMBER,
        node_geom          MDSYS.SDO_GEOMETRY,
        available_in_conn  MDSYS.SDO_NUMBER_ARRAYSET,
        available_out_conn MDSYS.SDO_NUMBER_ARRAYSET,
        runtime_created CHAR(1),
        MAP MEMBER FUNCTION get_id RETURN VARCHAR2
        )
/

