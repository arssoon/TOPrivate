create type AggrConcavehull AUTHID current_user as Object
(
  context raw(4),
  static function odciaggregateinitialize(sctx IN OUT AggrConcavehull)
                     return number,
  member function odciaggregateiterate(self IN OUT AggrConcavehull,
               geom IN mdsys.SDOAggrType) return number,
  member function odciaggregateterminate(self IN AggrConcavehull,
                                 returnValue OUT mdsys.sdo_geometry,
                                 flags IN number)
                     return number,
  member function odciaggregatemerge(self IN OUT AggrConcavehull,
                    sctx2 IN  AggrConcavehull) return number,
  member function sdoaggregateiterate(self IN OUT AggrConcavehull,
               geom IN mdsys.sdo_geometry, dim IN mdsys.SDO_DIM_ARRAY)
  return number);
/

