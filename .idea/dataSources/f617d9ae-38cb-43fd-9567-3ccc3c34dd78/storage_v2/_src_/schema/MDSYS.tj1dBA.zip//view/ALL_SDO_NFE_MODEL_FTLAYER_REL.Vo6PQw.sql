create view ALL_SDO_NFE_MODEL_FTLAYER_REL as
SELECT sdo_owner owner, model_id, feature_layer_id, hierarchy_level, z_order, path_layer
  FROM MDSYS.SDO_NFE_MODEL_FTLAYER_REL
/

