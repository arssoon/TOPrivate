create TYPE ST_LINESTRING
                                      
UNDER ST_CURVE (
  CONSTRUCTOR FUNCTION ST_LINESTRING(apointarray ST_Point_Array)
               RETURN SELF AS RESULT,
  CONSTRUCTOR FUNCTION ST_LINESTRING(apointarray ST_Point_Array, asrid INTEGER)
 RETURN SELF AS RESULT,
  OVERRIDING MEMBER FUNCTION ST_IsSimple RETURN Integer DETERMINISTIC,
  MEMBER FUNCTION ST_Points(apointarray ST_Point_Array) RETURN ST_LineString)
/

