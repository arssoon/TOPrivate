create TYPE sdo_rdf_triple
      AS OBJECT
        (subject VARCHAR2(4000),
         property VARCHAR2(4000),
         object VARCHAR2(10000))
/

