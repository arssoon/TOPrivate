create TYPE sdo_rdf_term
                                                                                  
      authid current_user
      AS OBJECT
        (
         value_type    VARCHAR2(10),
         value_name    VARCHAR2(4000),
         vname_prefix  VARCHAR2(4000),
         vname_suffix  VARCHAR2(512),
         literal_type  VARCHAR2(1000),
         language_type VARCHAR2(80),
         long_value    CLOB,
         ctx1          VARCHAR2(4000),

         CONSTRUCTOR FUNCTION sdo_rdf_term(
           value_type    VARCHAR2,
           value_name    VARCHAR2,
           literal_type  VARCHAR2,
           language_type VARCHAR2,
           long_value    CLOB)
         RETURN SELF AS RESULT DETERMINISTIC PARALLEL_ENABLE,

         CONSTRUCTOR FUNCTION sdo_rdf_term(
           value_type    VARCHAR2,
           value_name    VARCHAR2,
           literal_type  VARCHAR2,
           language_type VARCHAR2,
           long_value    CLOB,
           check_null    PLS_INTEGER)
         RETURN SELF AS RESULT DETERMINISTIC PARALLEL_ENABLE,

         CONSTRUCTOR FUNCTION sdo_rdf_term(
           value_type    VARCHAR2,
           value_name    VARCHAR2,
           literal_type  VARCHAR2,
           language_type VARCHAR2,
           long_value    CLOB,
           ctx1          VARCHAR2)
         RETURN SELF AS RESULT DETERMINISTIC PARALLEL_ENABLE,

         CONSTRUCTOR FUNCTION sdo_rdf_term(
           rdf_term_str  VARCHAR2)
         RETURN SELF AS RESULT DETERMINISTIC PARALLEL_ENABLE,

         MAP MEMBER FUNCTION compare
         RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE,

         MEMBER FUNCTION setValueName (
           vnameStr      VARCHAR2,
           value_type    VARCHAR2,
           return_typ    NUMBER)
         RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE,

         MEMBER FUNCTION nonCanonTermStr
         RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE,

         MEMBER FUNCTION canonTermStr
         RETURN VARCHAR2 DETERMINISTIC PARALLEL_ENABLE,

         MEMBER FUNCTION toCanonTerm
         RETURN SDO_RDF_TERM DETERMINISTIC PARALLEL_ENABLE
         )
/

