create view USER_SDO_NETWORK_JAVA_OBJECTS as
SELECT  constraint name, description, class_name, class,java_interface
    FROM  mdsys.sdo_network_constraints
    WHERE sdo_owner = sys_context('USERENV', 'CURRENT_USER')
/

