create type rdfctx_ws_extractor under rdfctx_extractor (

      ws_end_point VARCHAR2(1024),
      ws_soap_act  VARCHAR2(1024),
      ws_envelope  CLOB,
      ws_xsltrans  sys.XMLType,

      overriding member function getDescription return VARCHAR2,

      overriding member function rdfReturnType return VARCHAR2,

      -- sets the proxy server for the current instance --
      overriding member procedure startDriver,

      -- post the http request to the web service end-point and
      -- returns the response --
      overriding member function extractRdf(document CLOB,
                                            docId    VARCHAR2) return CLOB,

      -- closes the driver --
      overriding member procedure closeDriver

    ) not instantiable not final
/

