create type ctx_entity_extractor under rdfctx_extractor (

      epl_policy  VARCHAR2(30),
      xsl_trans   sys.XMLtype,

      constructor function ctx_entity_extractor (
                     epl_policy  VARCHAR2,
                     base_url    VARCHAR2 default null) return self as result,

      constructor function ctx_entity_extractor (
                     epl_policy  VARCHAR2,
                     xsl_trans   sys.xmltype) return self as result,

      overriding member function getDescription return VARCHAR2,

      overriding member function rdfReturnType return VARCHAR2,

      overriding member function extractRdf(document CLOB,
                                            docId    VARCHAR2) return CLOB

    )
 alter type ctx_entity_extractor
    add overriding member function extractRdf(document CLOB,
                                              docId    VARCHAR2,
                                              params   VARCHAR2,
                                              options  VARCHAR2 default NULL) return CLOB
    cascade
/

