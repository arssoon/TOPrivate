create Package       sdo_trkr AUTHID current_user
AS
  Procedure create_tracking_set(tracking_set_name IN VARCHAR2,
                                num_trkr_queues IN INTEGER DEFAULT 4,
                                num_loc_queues IN INTEGER DEFAULT 1);

  Procedure start_tracking_set(tracking_set_name IN VARCHAR2);

  Procedure stop_tracking_set(tracking_set_name IN VARCHAR2);

  Procedure drop_tracking_set(tracking_set_name IN VARCHAR2);

  Procedure run_loc_deq(tracking_set_name IN VARCHAR2,
                        qNo IN INTEGER,
                        num_trkr_queues IN INTEGER);

  Procedure run_trkr_deq(tracking_set_name IN VARCHAR2,
                         qNo IN INTEGER,
                         num_trkr_queues IN INTEGER);

  Procedure get_notification_msg(tracking_set_name  IN VARCHAR2,
                                 deq_wait         IN INTEGER DEFAULT DBMS_AQ.NO_WAIT,
                                 message          OUT MDSYS.NOTIFICATION_MSG);

  Procedure send_tracking_msg(tracking_set_name IN VARCHAR2,
                              tracking_msg      IN MDSYS.TRACKER_MSG);

  Procedure send_location_msgs(tracking_set_name IN VARCHAR2,
                               location_msgs     IN MDSYS.LOCATION_MSG_ARR);

END sdo_trkr;
/

