create TYPE SDO_REGAGGR
TYPE SDO_REGAGGR
AS OBJECT (
AS OBJECT (
        region_id varchar2(24),
        region_id varchar2(24),
        geometry mdsys.sdo_geometry,
        geometry mdsys.sdo_geometry,
        aggregate_value number)         aggregate_value number)
/

